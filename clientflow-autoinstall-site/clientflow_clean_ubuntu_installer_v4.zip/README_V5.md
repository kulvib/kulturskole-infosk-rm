# ClientFlow Clean Ubuntu Installer v5

V5 bruger kun enrollment/client-secret-flow.

Nyheder:

- Konfigurerer GDM til automatisk login på Xorg-session (`Ubuntu on Xorg`) via `scripts/configure_xorg_autologin.sh`.
- Kører fuld Ubuntu-/app-opdatering ved installation og geninstallation/opdatering.
- Konfigurerer kiosk-hardening via `scripts/configure_kiosk_hardening.sh`, så system-popups, crash-dialoger, update-notifier, skærmlås og sleep reduceres/deaktiveres.
- Understøtter re-registrering med ny installationskode via `scripts/claim_enrollment_env.sh`, hvis klienten er slettet i backend.
- Understøtter geninstallation/opdatering fra Render uden at skifte client credentials via `CLIENTFLOW_SKIP_ENROLLMENT=1 CLIENTFLOW_REINSTALL_MODE=1`.
- GUI viser tydeligt `Pending / Venter på godkendelse`, `Approved / Godkendt` og `Kalender: Off`/venter på aktiv visningstid.
- Efter installation er Enter ved reboot-spørgsmålet også et ja.

Den gamle manuelle client-secret-installation er fjernet.
