# ClientFlow Clean Ubuntu Installer v4

V4 bruger kun enrollment/client-secret-flow.

Nyheder:

- Konfigurerer GDM til automatisk login på Xorg-session (`Ubuntu on Xorg`) via `scripts/configure_xorg_autologin.sh`.
- Understøtter re-registrering med ny installationskode via `scripts/claim_enrollment_env.sh`, hvis klienten er slettet i backend.
- Understøtter geninstallation/opdatering fra Render uden at skifte client credentials via `CLIENTFLOW_SKIP_ENROLLMENT=1 CLIENTFLOW_REINSTALL_MODE=1`.
- GUI viser tydeligt `Pending / Venter på godkendelse` og `Approved / Godkendt`.

Den gamle manuelle client-secret-installation er fjernet.
