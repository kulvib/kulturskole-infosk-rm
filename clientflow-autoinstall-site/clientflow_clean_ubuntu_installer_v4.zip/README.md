# ClientFlow Clean Ubuntu Installer v3

Denne pakke installerer ClientFlow på Ubuntu-klienter med det nye enrollment/client-secret-flow.

## Flow

1. Opret en installationskode i ClientFlow admin.
2. Kør installeren på Ubuntu-klienten.
3. Indtast installationskoden, eller sæt `CLIENTFLOW_ENROLLMENT_CODE`.
4. Installeren kalder backend `/api/enrollment/claim`.
5. Backend opretter klienten og returnerer `client_id` + `client_secret`.
6. Installeren skriver credentials til `/etc/clientflow/clientflow.env`.
7. Godkend klienten i admin, hvis den står som `pending`.

## Interaktiv brug

```bash
sudo bash scripts/install_clientflow_clean_ubuntu.sh "$USER" https://kulturskole-infosk-rm.onrender.com
```

## Non-interaktiv brug

```bash
sudo CLIENTFLOW_ENROLLMENT_CODE='CF-XXXX-XXXX-XXXX' \
  CLIENTFLOW_CLIENT_NAME="$(hostname)" \
  bash scripts/install_clientflow_clean_ubuntu.sh "$USER" https://kulturskole-infosk-rm.onrender.com
```

Den gamle manuelle `client_id/client_secret` efter-installation er fjernet fra v3-flowet.
