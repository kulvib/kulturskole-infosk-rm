# ClientFlow Clean Ubuntu Installer v1

Denne pakke er bygget ud fra den fungerende klient-snapshot fra 2026-05-17.

## Vigtigt

Snapshot'et havde fået redigeret secrets ud af Python-koden, så to linjer i `clientflow_service.py` og én linje i `clientflow_calendar.py` var syntaktisk ødelagt. De er repareret i denne installer, og secrets indlæses stadig udelukkende fra `/etc/clientflow/clientflow.env`.

Snapshot'et manglede også tre helper-moduler (`config_utils.py`, `status_utils.py`, `status_map.py`). De er inkluderet fra de seneste uploadede ClientFlow helper-filer i samtalen.

## Installation på ren klient

```bash
cd /home/<bruger>/Hentet
unzip -o clientflow_clean_ubuntu_installer_v1.zip -d clientflow_clean_ubuntu_installer_v1
cd clientflow_clean_ubuntu_installer_v1
sudo bash scripts/install_clientflow_clean_ubuntu.sh <bruger> https://kulturskole-infosk-rm.onrender.com
```

Eksempel:

```bash
sudo bash scripts/install_clientflow_clean_ubuntu.sh kulturskolenviborg-info1 https://kulturskole-infosk-rm.onrender.com
```

## Installer client secret

Når klienten er oprettet/godkendt i backend, installer client credentials:

```bash
sudo bash scripts/install_client_secret_env.sh
```

eller:

```bash
sudo CLIENTFLOW_CLIENT_ID=1370 CLIENTFLOW_CLIENT_SECRET='...' bash scripts/install_client_secret_env.sh
```

## Verificering

```bash
bash scripts/verify_clientflow_install.sh <bruger>
```

Forventet efter credentials og kiosk-start:

```text
active
active
active
active
active
active
127.0.0.1:9222 LISTEN
marker=1.2.0
overlay={'display': 'none', 'visibility': 'hidden', 'opacity': '0'}
```

## Indeholder

- ClientFlow API/client scripts
- `clientflow_gui.py` med no-scroll/autofit, top-left, 7 kalenderdage
- `chrome_kiosk.py` med remote debugging flags og Chrome extension fallback
- `clientflow_browser_guard.py` v1.2
- `clientflow-clean-chrome-restore-state.sh`
- `clientflow-kiosk-x11-guard.sh`
- Chrome extension fallback
- systemd services/drop-ins
- post-install verification
