#!/usr/bin/env python3
"""
chrome_kiosk.py

Opdateret Chrome kiosk helper — strengere watchdog som poller flere gange og logger beslutningsårsag.

FIX: STATUS_MAP og format_message importeres nu fra status_map.py (single source of truth).
     Den lokale kopi af STATUS_MAP og format_message er fjernet.
FIX: direct_written flag i chrome_expected_stop — watchdogen kan nu skelne mellem
     "aldrig sat" (manuel lukning) og "sat og nulstillet af shutdown_chrome" (programmatisk lukning).
     Løser bug hvor manuel lukning af Chrome ikke blev registreret.
FIX: Watchdog startup skriver IKKE chrome_opened_manual/manual hvis der allerede
     ligger et programmatisk start-step i chrome_status.json (fx start_chrome med
     trigger="backend"). Løser bug hvor status viste "startet fra GUI" selvom
     handlingen kom fra backend.
"""
from pathlib import Path
import subprocess
import time
import os
import shutil
import signal
import psutil
import json
import threading
import datetime
import sys
import glob
import uuid
from typing import Any, Dict, Tuple

# BASE_DIR = mappen hvor dette script ligger
BASE_DIR = Path(__file__).resolve().parent

API_DIR = Path(os.environ.get("CLIENTFLOW_API_DIR", str(BASE_DIR))).resolve()

CHROME_PROFILE_PATH = str(API_DIR / "chrome_profile" / "Default")
CHROME_STATUS_PATH = str(API_DIR / "chrome_status.json")

# X11 display used for window-based Chrome detection.
# Process detection alene er ikke nok: Chrome kan efterlade helper/crashpad
# processer, selvom selve browser-vinduet er lukket med X.
DISPLAY = os.environ.get("DISPLAY", ":0")
XAUTHORITY = os.environ.get("XAUTHORITY", "/run/user/1000/gdm/Xauthority")

# ClientFlow local Chrome extension
CHROME_EXTENSION_PATH = os.environ.get("CLIENTFLOW_CHROME_EXTENSION_PATH", "/opt/clientflow/chrome_extensions/clientflow-kiosk-protection")
CHROME_WINDOW_CLASSES = (
    "google-chrome",
    "google-chrome-stable",
    "chromium",
    "chromium-browser",
    "chrome",
)

CHROME_KIOSK_CMD = [
    "/usr/bin/google-chrome",
    "--start-fullscreen",
    "--noerrdialogs",
    "--disable-infobars",
    "--disable-session-crashed-bubble",
    "--remote-debugging-address=127.0.0.1",
    "--remote-debugging-port=9222",
    "--remote-allow-origins=*",
    f"--load-extension={CHROME_EXTENSION_PATH}",
    f"--disable-extensions-except={CHROME_EXTENSION_PATH}",
    "--disable-features=TranslateUI",
    "--no-first-run",
    "--disable-pinch",
    "--overscroll-history-navigation=0",
    "--autoplay-policy=no-user-gesture-required",
    f"--user-data-dir={str(Path(CHROME_PROFILE_PATH).parent)}",
    "--profile-directory=Default"
]

chrome_expected_start = threading.Event()
# FIX: Tilføjet "direct_written" key — sættes True af shutdown_chrome når den
# selv skriver terminal-step direkte, så watchdogen kan springe over uden at
# fejlfortolke situationen som en manuel lukning.
chrome_expected_stop = {"set": False, "trigger": None, "ts": None, "direct_written": False, "direct_written_ts": None}
FORCE_SEND_CALLBACK = None
system_is_shutting_down = False

def _reset_expected_stop(reason: str = "") -> None:
    # Nulstil expected-stop state, så gamle programmatic stop ikke påvirker næste manuelle X-luk.
    try:
        chrome_expected_stop["set"] = False
        chrome_expected_stop["trigger"] = None
        chrome_expected_stop["ts"] = None
        chrome_expected_stop["direct_written"] = False
        chrome_expected_stop["direct_written_ts"] = None
        if reason:
            log(f"Reset chrome_expected_stop: {reason}")
    except Exception:
        pass

def _direct_written_age_seconds() -> float:
    # Returnerer alder på direct_written flag. Ukendt timestamp behandles som stale.
    try:
        ts = chrome_expected_stop.get("direct_written_ts") or chrome_expected_stop.get("ts")
        if not ts:
            return 999999.0
        return max(0.0, time.time() - float(ts))
    except Exception:
        return 999999.0


def set_system_shutdown_flag():
    global system_is_shutting_down
    system_is_shutting_down = True

# ---------------------------------------------------------------------------
# FIX: Importér fra status_map.py — single source of truth.
# Den lokale STATUS_MAP og format_message er fjernet fra denne fil.
# ---------------------------------------------------------------------------
try:
    from status_map import STATUS_MAP, format_message, fallback_status_message  # type: ignore
except ImportError as e:
    raise RuntimeError(
        f"chrome_kiosk.py kræver status_map.py i samme mappe ({API_DIR}): {e}"
    )


def log(msg: str) -> None:
    print(f"[chrome_kiosk] {msg}")
    sys.stdout.flush()

def ensure_status_file_exists() -> None:
    try:
        p = Path(CHROME_STATUS_PATH)
        if not p.exists():
            p.parent.mkdir(parents=True, exist_ok=True)
            p.write_text(json.dumps({"steps": [], "chrome_running": False}, ensure_ascii=False, indent=2), encoding="utf-8")
            try:
                p.chmod(0o664)
            except Exception:
                pass
    except Exception as e:
        log(f"FEJL ved ensure_status_file_exists: {e}")

ensure_status_file_exists()

def _atomic_write_json(path: str, obj: Any) -> None:
    try:
        p = Path(path)
        p.parent.mkdir(parents=True, exist_ok=True)
        tmp = p.with_name(f"{p.name}.tmp.{os.getpid()}.{uuid.uuid4().hex[:8]}")
        tmp.write_text(json.dumps(obj, ensure_ascii=False, indent=2), encoding="utf-8")
        try:
            tmp.chmod(0o664)
        except Exception:
            pass
        tmp.replace(p)
        try:
            p.chmod(0o664)
        except Exception:
            pass
    except Exception as e:
        log(f"FEJL ved atomic write af {path}: {e}")

def clear_status_file() -> None:
    status = {"steps": [], "chrome_running": False}
    try:
        _atomic_write_json(CHROME_STATUS_PATH, status)
        log(f"Statusfil ryddet: {CHROME_STATUS_PATH}")
    except Exception as e:
        log(f"FEJL ved rydning af statusfil: {e}")

def handle_shutdown(signum, frame) -> None:
    clear_status_file()
    sys.exit(0)

signal.signal(signal.SIGTERM, handle_shutdown)
signal.signal(signal.SIGINT, handle_shutdown)

def _x11_env() -> Dict[str, str]:
    env = {**os.environ}
    env["DISPLAY"] = env.get("DISPLAY", DISPLAY)
    env["XAUTHORITY"] = env.get("XAUTHORITY", XAUTHORITY)
    return env


def _run_quiet(cmd: list, timeout: float = 2.0) -> tuple[int, str, str]:
    try:
        res = subprocess.run(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            timeout=timeout,
            env=_x11_env(),
        )
        return res.returncode, res.stdout or "", res.stderr or ""
    except FileNotFoundError:
        return 127, "", f"command not found: {cmd[0]}"
    except Exception as e:
        return 1, "", str(e)


def _visible_chrome_window_exists() -> tuple[bool | None, str]:
    """
    Returnerer (True/False, reason) hvis X11-vinduer kan undersøges.
    Returnerer (None, reason) hvis værktøjerne ikke er tilgængelige eller X11
    ikke kan tilgås fra systemd-servicen.

    Det er denne funktion der gør manuel lukning med musens X pålidelig:
    vi måler om browser-vinduet findes, ikke om Chrome har efterladt processer.
    """

    # 1) xdotool: bedst til "synlige" vinduer.
    xdotool_found = False
    for cls in CHROME_WINDOW_CLASSES:
        rc, out, err = _run_quiet(["xdotool", "search", "--onlyvisible", "--class", cls])
        if rc == 0 and out.strip():
            return True, f"xdotool visible class={cls}"
        if rc in (0, 1):
            # rc=1 betyder typisk: kommando OK, ingen match.
            xdotool_found = True
            continue
        if rc != 127:
            # xdotool findes men kan fx ikke åbne DISPLAY.
            return None, f"xdotool failed rc={rc}: {err.strip()[:160]}"

    if xdotool_found:
        return False, "xdotool: no visible chrome window"

    # 2) wmctrl fallback. Kræver ikke --onlyvisible, men er god som fallback.
    rc, out, err = _run_quiet(["wmctrl", "-lx"])
    if rc == 0:
        for line in out.splitlines():
            low = line.lower()
            if any(cls in low for cls in CHROME_WINDOW_CLASSES):
                return True, "wmctrl found chrome window"
        return False, "wmctrl: no chrome window"
    if rc != 127:
        return None, f"wmctrl failed rc={rc}: {err.strip()[:160]}"

    return None, "no xdotool/wmctrl available"


def _is_real_chrome_process(proc) -> bool:
    try:
        name = (proc.info.get("name") or "").lower()
        status = proc.info.get("status")
        cmdline = proc.info.get("cmdline") or []
        cmd = " ".join(str(x) for x in cmdline).lower()

        if status in ("zombie", "dead"):
            return False
        if not any(x in name for x in ("chrome", "chromium")) and not any(x in cmd for x in ("google-chrome", "chromium")):
            return False

        # Child/helper-processer må ikke tælle som åben browser.
        ignored_markers = (
            "--type=",
            "crashpad",
            "nacl_helper",
            "zygote",
            "renderer",
            "gpu-process",
            "utility",
        )
        if any(marker in cmd for marker in ignored_markers):
            return False

        return True
    except (psutil.NoSuchProcess, psutil.AccessDenied):
        return False
    except Exception:
        return False


def _chrome_browser_process_exists() -> bool:
    for proc in psutil.process_iter(["name", "status", "cmdline"]):
        if _is_real_chrome_process(proc):
            return True
    return False


def is_chrome_running() -> bool:
    """
    Sandheden for status/GUI: er kiosk-browseren reelt åben?

    Prioritet:
      1. Synligt Chrome/Chromium-vindue i X11-sessionen.
      2. Fallback til hovedprocesser, hvis X11-vinduer ikke kan læses.

    Det løser manuel lukning med musens X, hvor Chrome kan efterlade
    crashpad/helper-processer, mens vinduet er væk.
    """
    win, reason = _visible_chrome_window_exists()
    if win is not None:
        return bool(win)
    return _chrome_browser_process_exists()


def get_chrome_pids() -> list:
    """Returnerer alle Chrome/Chromium-relaterede pids til kill-flowet."""
    pids = []
    for proc in psutil.process_iter(["name", "status", "cmdline"]):
        try:
            name = (proc.info.get("name") or "").lower()
            cmd = " ".join(str(x) for x in (proc.info.get("cmdline") or [])).lower()
            if proc.info.get("status") in ("zombie", "dead"):
                continue
            if any(x in name for x in ("chrome", "chromium")) or any(x in cmd for x in ("google-chrome", "chromium")):
                pids.append(proc.pid)
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            continue
    return pids

def status_message_and_color(step: str, trigger: str, extra: Any = None) -> Tuple[str, str]:
    if step in ("countdown", "system_reboot_countdown"):
        return format_message(step, trigger, X=extra)
    return format_message(step, trigger, detail=extra)

def _utc_now_iso() -> str:
    return datetime.datetime.utcnow().isoformat() + "Z"

def write_step(step: str, trigger: str, extra: Any = None, status: str = None, url: str = None) -> None:
    message, color = status_message_and_color(step, trigger, extra)
    step_data: Dict[str, Any] = {
        "step": step,
        "message": message,
        "status": status if status else "",
        "trigger": trigger,
        "color": color,
        "timestamp": _utc_now_iso(),
        "id": str(uuid.uuid4())
    }
    if extra is not None:
        step_data["extra"] = extra
    if url:
        step_data["url"] = url
    write_status_append([step_data])

def write_system_status(step: str, trigger: str, extra: Any = None) -> None:
    message, color = status_message_and_color(step, trigger, extra)
    step_data = {
        "step": step,
        "message": message,
        "status": step,
        "trigger": trigger,
        "color": color,
        "timestamp": _utc_now_iso(),
        "id": str(uuid.uuid4())
    }
    if extra is not None:
        step_data["extra"] = extra
    write_status_append([step_data])

def mark_system_sleep(trigger="backend") -> None:
    try:
        write_system_status("system_sleep", trigger)
    except Exception as e:
        log(f"FEJL i mark_system_sleep: {e}")

def mark_system_wake(trigger="backend") -> None:
    try:
        write_system_status("system_wake", trigger)
    except Exception as e:
        log(f"FEJL i mark_system_wake: {e}")

def clear_cookies_and_profile(trigger="ukendt") -> bool:
    try:
        if os.path.exists(CHROME_PROFILE_PATH):
            for f in os.listdir(CHROME_PROFILE_PATH):
                if f in ["Cookies", "Cookies-journal", "Cache", "History"]:
                    file_path = os.path.join(CHROME_PROFILE_PATH, f)
                    try:
                        if os.path.isdir(file_path):
                            shutil.rmtree(file_path, ignore_errors=True)
                            log(f"Fjernede mappe: {file_path}")
                        elif os.path.exists(file_path):
                            os.remove(file_path)
                            log(f"Fjernede: {file_path}")
                        else:
                            log(f"Fil ikke fundet (OK): {file_path}")
                    except FileNotFoundError:
                        log(f"Fil ikke fundet (OK): {file_path}")
                    except Exception as e:
                        log(f"Uventet fejl ved sletning af {file_path}: {e}")
                        write_step("error", trigger, status="error")
        write_step("clear_cookies", trigger, status="ok")
        return True
    except Exception as e:
        log(f"FEJL i clear_cookies_and_profile: {e}")
        write_step("error", trigger, status="error")
        return False

def clear_chrome_session_crash_files() -> None:
    if os.path.exists(CHROME_PROFILE_PATH):
        patterns = [
            "Session_*", "Tabs_*", "Current Session", "Current Tabs",
            "Last Session", "Last Tabs", "Preferences.lock", "Safe Browsing Cookies",
            "Singleton*", "LOCK", "Crashpad"
        ]
        for pat in patterns:
            for file in glob.glob(os.path.join(CHROME_PROFILE_PATH, pat)):
                try:
                    if os.path.isdir(file):
                        shutil.rmtree(file, ignore_errors=True)
                        log(f"Fjernede session/crash-mappe: {file}")
                    else:
                        os.remove(file)
                        log(f"Fjernede session/crash-fil: {file}")
                except Exception as e:
                    log(f"Kunne ikke fjerne session/crash-fil {file}: {e}")

def kill_all_chrome(trigger="ukendt") -> None:
    pids = get_chrome_pids()
    if not pids:
        log("Ingen Chrome-processer at lukke.")
        return
    for pid in pids:
        try:
            os.kill(pid, signal.SIGTERM)
            log(f"Sendte SIGTERM til Chrome (pid={pid})")
            write_step("terminate_chrome", trigger, status="terminated")
        except ProcessLookupError:
            log(f"Chrome-proces {pid} fandtes ikke ved SIGTERM.")
        except Exception as e:
            log(f"Uventet fejl ved SIGTERM til Chrome (pid={pid}): {e}")
            write_step("error", trigger, status="error")
    time.sleep(0.5)
    for pid in get_chrome_pids():
        try:
            os.kill(pid, signal.SIGKILL)
            log(f"Sendte SIGKILL til Chrome (pid={pid})")
            write_step("kill_chrome", trigger, status="killed")
        except ProcessLookupError:
            log(f"Chrome-proces {pid} fandtes ikke ved SIGKILL.")
        except Exception as e:
            log(f"Uventet fejl ved SIGKILL til Chrome (pid={pid}): {e}")
            write_step("error", trigger, status="error")

def shutdown_chrome(trigger="ukendt", wait_for_exit=True, max_wait=5, after_system_status=False) -> None:
    global chrome_expected_stop
    chrome_expected_stop["set"] = True
    chrome_expected_stop["trigger"] = trigger
    chrome_expected_stop["ts"] = time.time()
    chrome_expected_stop["direct_written"] = False  # nulstil ved start af shutdown_chrome
    chrome_expected_stop["direct_written_ts"] = None
    try:
        if not is_chrome_running():
            log("Chrome kører ikke – ingen grund til kill.")
            write_step("shutdown_chrome", trigger, status="closed")
        else:
            kill_all_chrome(trigger)
            if wait_for_exit:
                start = time.time()
                while is_chrome_running() and (time.time() - start < max_wait):
                    time.sleep(0.2)
            write_step("shutdown_chrome", trigger, status="closed")

        # FIX: Skriv terminal-step direkte så frontend-polling ikke hænger.
        # after_system_status=True bruges ved reboot/shutdown — terminal-step er
        # der system_rebooting/system_shutting_down, ikke chrome_closed_programmatically.
        if not after_system_status:
            write_step("chrome_closed_programmatically", trigger, status="closed")
            log(f"shutdown_chrome: skrev terminal-step chrome_closed_programmatically (trigger={trigger})")
            # FIX: Sæt direct_written=True FØR vi nulstiller set/trigger/ts —
            # watchdogen tjekker direct_written når den opdager Chrome er stoppet.
            chrome_expected_stop["direct_written"] = True
            chrome_expected_stop["direct_written_ts"] = time.time()
            chrome_expected_stop["set"] = False
            chrome_expected_stop["trigger"] = None
            chrome_expected_stop["ts"] = None

        if after_system_status and trigger == "pending_reboot":
            write_system_status("system_rebooting", "pending_reboot")
        elif after_system_status and trigger == "pending_shutdown":
            write_system_status("system_shutting_down", "pending_shutdown")
    except Exception as e:
        log(f"FEJL i shutdown_chrome: {e}")
        write_step("error", trigger, status="error")

def start_chrome(url: str, trigger="ukendt") -> None:
    # VIGTIGT:
    # En tidligere programmatisk shutdown kan have sat direct_written=True.
    # Når vi starter Chrome igen, må det flag ikke leve videre og blokere
    # en senere manuel X-lukning.
    _reset_expected_stop("start_chrome")
    clear_chrome_session_crash_files()
    if system_is_shutting_down:
        log("system_is_shutting_down=True - SKIPPER start_chrome!")
        return
    try:
        cmd = CHROME_KIOSK_CMD + [url]
        log(f"Starter Chrome med kommando: {' '.join(cmd)}")
        subprocess.Popen(cmd)
        write_step("start_chrome", trigger, status="running", url=url)
        if FORCE_SEND_CALLBACK:
            log("FORCE_SEND_CALLBACK: kalder callback pga. start_chrome")
            try:
                FORCE_SEND_CALLBACK()
            except Exception as e:
                log(f"FEJL i FORCE_SEND_CALLBACK: {e}")
    except Exception as e:
        log(f"FEJL ved start_chrome: {e}")
        write_step("error", trigger, status="error")

def write_status(steps: list) -> None:
    max_steps = 200
    if len(steps) > max_steps:
        steps = steps[-max_steps:]
    data = {"steps": steps, "chrome_running": is_chrome_running()}
    try:
        _atomic_write_json(CHROME_STATUS_PATH, data)
    except Exception as e:
        log(f"FEJL ved write_status: {e}")

def write_status_append(new_steps: list) -> None:
    try:
        if os.path.exists(CHROME_STATUS_PATH):
            with open(CHROME_STATUS_PATH, "r", encoding="utf-8") as f:
                data = json.load(f)
            steps = data.get("steps", [])
        else:
            steps = []
        if not isinstance(steps, list):
            steps = []
        existing_ids = {str(s.get("id")) for s in steps if isinstance(s, dict) and s.get("id")}
        for step in new_steps:
            if not isinstance(step, dict):
                continue
            step.setdefault("timestamp", _utc_now_iso())
            step.setdefault("id", str(uuid.uuid4()))
            # Deduplikér kun på id. Gentagne ens steps skal registreres hver gang.
            if str(step.get("id")) not in existing_ids:
                steps.append(step)
                existing_ids.add(str(step.get("id")))
        write_status(steps)
        if FORCE_SEND_CALLBACK:
            log("FORCE_SEND_CALLBACK: kalder callback pga. write_status_append")
            try:
                FORCE_SEND_CALLBACK()
            except Exception as e:
                log(f"FEJL i FORCE_SEND_CALLBACK efter write_status_append: {e}")
    except Exception as e:
        log(f"FEJL ved write_status_append: {e}")
        try:
            write_status(new_steps)
        except Exception as e2:
            log(f"FEJL ved fallback write_status: {e2}")

def append_external_step(step_obj: dict) -> None:
    try:
        if not isinstance(step_obj, dict):
            log("append_external_step: modtog ikke dict, ignorerer.")
            return
        step = dict(step_obj)
        step.setdefault("timestamp", _utc_now_iso())
        if "id" not in step:
            step["id"] = str(uuid.uuid4())
        step.setdefault("trigger", step.get("trigger", "backend"))
        step.setdefault("color", step.get("color", "black"))
        write_status_append([step])
        log(f"append_external_step: appended external step '{step.get('step')}' id={step.get('id')}")
        if FORCE_SEND_CALLBACK:
            try:
                FORCE_SEND_CALLBACK()
                log("append_external_step: kaldte FORCE_SEND_CALLBACK()")
            except Exception as e:
                log(f"append_external_step: FEJL i FORCE_SEND_CALLBACK: {e}")
    except Exception as e:
        log(f"FEJL i append_external_step: {e}")

def scenario_system_start(url: str, countdown=12, trigger="system_start") -> None:
    global chrome_expected_start
    chrome_expected_start.set()
    try:
        if system_is_shutting_down:
            log("system_is_shutting_down=True - SKIPPER hele browserstart-flowet!")
            return
        if not url or not str(url).startswith("http"):
            raise ValueError(f"Ugyldig eller manglende URL: {url}")
        write_status([])
        clear_cookies_and_profile(trigger=trigger)
        shutdown_chrome(trigger=trigger)
        if is_chrome_running():
            kill_all_chrome(trigger=f"{trigger}_doublecheck")
        for i in range(countdown, 0, -1):
            write_step("countdown", trigger, extra=i, status="waiting")
            time.sleep(1)
        if not system_is_shutting_down:
            start_chrome(url, trigger=trigger)
    except Exception as e:
        log(f"FEJL i scenario_system_start: {e}")
        write_step("error", trigger, status="error")

def scenario_url_change(new_url: str, countdown=15, trigger="url_change") -> None:
    global chrome_expected_start
    chrome_expected_start.set()
    try:
        if system_is_shutting_down:
            return
        if not new_url or not str(new_url).startswith("http"):
            raise ValueError(f"Ugyldig eller manglende URL: {new_url}")
        write_status([])
        clear_cookies_and_profile(trigger=trigger)
        shutdown_chrome(trigger=trigger)
        if is_chrome_running():
            kill_all_chrome(trigger=f"{trigger}_doublecheck")
        for i in range(countdown, 0, -1):
            write_step("countdown", trigger, extra=i, status="waiting")
            time.sleep(1)
        if not system_is_shutting_down:
            start_chrome(new_url, trigger=trigger)
    except Exception as e:
        log(f"FEJL i scenario_url_change: {e}")
        write_step("error", trigger, status="error")

def scenario_manual_shutdown(trigger="manual") -> None:
    global chrome_expected_stop
    chrome_expected_stop["set"] = True
    chrome_expected_stop["trigger"] = trigger
    chrome_expected_stop["ts"] = time.time()
    chrome_expected_stop["direct_written"] = False
    try:
        write_status([])
        clear_cookies_and_profile(trigger=trigger)
        shutdown_chrome(trigger=trigger)
        if is_chrome_running():
            kill_all_chrome(trigger=f"{trigger}_doublecheck")
    except Exception as e:
        log(f"FEJL i scenario_manual_shutdown: {e}")
        write_step("error", trigger, status="error")

def scenario_manual_start(url: str, countdown=12, trigger="manual_start") -> None:
    scenario_system_start(url, countdown, trigger=trigger)

def scenario_backend_shutdown() -> None:
    scenario_manual_shutdown(trigger="backend")

def scenario_backend_start(url: str, countdown=12, trigger="backend") -> None:
    if system_is_shutting_down:
        log("system_is_shutting_down=True - SKIPPER backend start!")
        return
    scenario_system_start(url, countdown, trigger=trigger)

def scenario_gui_start(url: str, countdown=12, trigger="gui") -> None:
    if system_is_shutting_down:
        log("system_is_shutting_down=True - SKIPPER GUI start!")
        return
    write_status([])
    clear_cookies_and_profile(trigger=trigger)
    shutdown_chrome(trigger=trigger)
    if is_chrome_running():
        kill_all_chrome(trigger=f"{trigger}_doublecheck")
    for i in range(countdown, 0, -1):
        write_step("countdown", trigger, extra=i, status="waiting")
        time.sleep(1)
    start_chrome(url, trigger=trigger)

# ---------------------------------------------------------------------------
# Hjælpefunktion: udled trigger fra eksisterende steps ved watchdog-opstart
# ---------------------------------------------------------------------------
def _infer_startup_trigger_from_steps(steps: list) -> str | None:
    """
    Gennemgå de seneste steps (nyeste først) og returnér triggeren fra det
    seneste START-relaterede step hvis det er yngre end 60 sekunder.
    Bruges til at undgå at watchdog overskriver "backend"/"gui" med "manual".
    """
    START_STEPS = {"start_chrome", "countdown", "clear_cookies", "chrome_opened_manual"}
    now_ts = datetime.datetime.utcnow()
    for s in reversed(steps[-20:]):
        step_name = s.get("step", "")
        if step_name not in START_STEPS:
            continue
        raw_ts = s.get("timestamp")
        if raw_ts:
            try:
                ts_str = str(raw_ts).replace("Z", "")
                dt = datetime.datetime.fromisoformat(ts_str)
                age_secs = (now_ts - dt).total_seconds()
                if age_secs <= 60:
                    trig = s.get("trigger")
                    if trig:
                        return trig
            except Exception:
                pass
    return None


def start_watchdog(on_chrome_stopped=None, poll_interval=2) -> None:
    MAX_WAIT_FOR_EXTERNAL_WRITES = 3.0
    POLL_STEP = 0.12

    def _watchdog_loop():
        global chrome_expected_start, chrome_expected_stop
        was_running = is_chrome_running()

        status_path = CHROME_STATUS_PATH
        status_empty = False
        init_steps = []
        try:
            if os.path.exists(status_path):
                with open(status_path, "r", encoding="utf-8") as f:
                    data = json.load(f)
                init_steps = data.get("steps", []) if isinstance(data, dict) else []
                if not init_steps:
                    status_empty = True
            else:
                status_empty = True
        except Exception:
            status_empty = True

        if was_running:
            # FIX: Tjek om der allerede er et nyligt programmatisk start-step
            # der forklarer hvorfor Chrome kører. Skriv IKKE chrome_opened_manual
            # med trigger="manual" i det tilfælde — det ville overskrive en korrekt
            # trigger (fx "backend" eller "gui") med den forkerte tekst.
            inferred_trigger = _infer_startup_trigger_from_steps(init_steps)
            if inferred_trigger is not None:
                log(
                    f"Watchdog startup: Chrome kører, fandt nyligt start-step "
                    f"med trigger='{inferred_trigger}' — springer chrome_opened_manual over."
                )
                # Chrome kører af en known grund — skriv ikke noget nyt
            else:
                # Ingen nyligt programmatisk step → Chrome åbnet manuelt
                write_step("chrome_opened_manual", "manual", status="running")
                log("Watchdog startup: Chrome kører uden nyligt start-step — skriver chrome_opened_manual/manual.")
        else:
            if status_empty:
                write_step("chrome_closed_programmatically", "system_start", status="closed")
            else:
                # Tjek om det seneste step allerede forklarer hvorfor Chrome ikke kører
                last_stop_step = init_steps[-1].get("step", "") if init_steps else ""
                KNOWN_STOP_STEPS = {
                    "chrome_closed_programmatically", "chrome_closed_manual",
                    "shutdown_chrome", "kill_chrome", "system_sleep",
                    "system_rebooting", "system_shutting_down",
                }
                if last_stop_step in KNOWN_STOP_STEPS:
                    log(f"Watchdog startup: Chrome kører ikke, seneste step='{last_stop_step}' forklarer det — springer over.")
                else:
                    write_step("chrome_closed_manual", "manual", status="closed")
                    log(f"Watchdog startup: Chrome kører ikke, seneste step='{last_stop_step}' — skriver chrome_closed_manual.")

        marker_path = Path(API_DIR) / ".pending_system_sleep"

        while True:
            running = is_chrome_running()
            if not was_running and running:
                # Chrome er nu åben igen. Gamle programmatic stop-flags må ikke
                # påvirke næste manuelle X-luk.
                _reset_expected_stop("watchdog detected chrome running")
                if chrome_expected_start.is_set():
                    chrome_expected_start.clear()
                else:
                    write_step("chrome_opened_manual", "manual", status="running")
            if was_running and not running:
                # FIX: shutdown_chrome sætter direct_written=True når den selv
                # skriver chrome_closed_programmatically direkte — watchdogen
                # springer da over og skriver IKKE et ekstra step.
                if chrome_expected_stop.get("direct_written"):
                    dw_age = _direct_written_age_seconds()

                    # Kun helt friske direct_written-events må forklare en stop-transition.
                    # Hvis flaget er gammelt, er det stale og må IKKE blokere manuel X-luk.
                    if dw_age <= 8.0:
                        _reset_expected_stop(f"fresh direct_written consumed by watchdog age={dw_age:.2f}s")
                        log("Watchdog: direct_written=True — springer over (shutdown_chrome skrev allerede terminal-step).")
                        was_running = running
                        time.sleep(poll_interval)
                        continue

                    # Stale direct_written er præcis den bug, hvor manuel X-luk ikke registreres.
                    _reset_expected_stop(f"stale direct_written ignored age={dw_age:.2f}s")
                    write_step("chrome_closed_manual", "manual", status="closed")
                    log(f"Watchdog: wrote chrome_closed_manual (stale direct_written ignored, age={dw_age:.2f}s)")
                    if on_chrome_stopped:
                        try:
                            on_chrome_stopped()
                        except Exception as e:
                            log(f"FEJL i on_chrome_stopped callback: {e}")
                    was_running = running
                    time.sleep(poll_interval)
                    continue

                if chrome_expected_stop["set"]:
                    elapsed = time.time() - chrome_expected_stop["ts"] if chrome_expected_stop["ts"] else 999
                    my_trigger = chrome_expected_stop.get("trigger", "backend")
                    if elapsed < 10:
                        write_step("chrome_closed_programmatically", my_trigger, status="closed")
                        log(f"Watchdog: wrote chrome_closed_programmatically (elapsed={elapsed:.2f}s, trigger={my_trigger})")
                    else:
                        write_step("chrome_closed_manual", "manual", status="closed")
                        log(f"Watchdog: wrote chrome_closed_manual (expected stop expired, elapsed={elapsed:.2f}s)")
                    chrome_expected_stop["set"] = False
                    chrome_expected_stop["trigger"] = None
                    chrome_expected_stop["ts"] = None
                    chrome_expected_stop["direct_written"] = False
                else:
                    # chrome_expected_stop blev aldrig sat — manuel lukning med mus/tastatur.
                    # Skriv ALTID status her. Gamle shutdown/system-steps må ikke
                    # skjule en ny manuel lukning. Kun aktiv sleep-marker springes over,
                    # fordi kiosk_sleep.py selv skriver system_sleep.
                    try:
                        if marker_path.exists():
                            log("Watchdog: .pending_system_sleep marker findes — kiosk_sleep håndterer status, skriver ikke chrome_closed_manual.")
                        else:
                            write_step("chrome_closed_manual", "manual", status="closed")
                            log("Watchdog: wrote chrome_closed_manual (window/process changed from open to closed)")
                    except Exception as e:
                        log(f"Watchdog: fejl ved manuel close-status: {e}")
                    if on_chrome_stopped:
                        try:
                            on_chrome_stopped()
                        except Exception as e:
                            log(f"FEJL i on_chrome_stopped callback: {e}")
            was_running = running
            time.sleep(poll_interval)

    t = threading.Thread(target=_watchdog_loop, daemon=True)
    t.start()

def set_force_send_callback(cb) -> None:
    global FORCE_SEND_CALLBACK
    FORCE_SEND_CALLBACK = cb

if __name__ == "__main__":
    log("Starter chrome_kiosk watchdog (manuel kørsel)")
