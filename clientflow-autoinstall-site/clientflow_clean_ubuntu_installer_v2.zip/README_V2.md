# ClientFlow Clean Ubuntu Installer v2

Denne v2 er bygget fra v1 og erstatter API-klientfilerne med de seneste filer, der blev uploadet fra den fungerende klient.

## Opdaterede filer

- `chrome_kiosk.py`
- `clientflow_browser_guard.py`
- `clientflow_calendar.py`
- `clientflow_gui.py`
- `clientflow_service.py`
- `client_remote_desktop_agent.py`
- `client_terminal_agent.py`
- `config_utils.py`
- `kiosk_sleep.py`
- `kiosk_wake.py`
- `livestream.py`
- `status_map.py`
- `status_utils.py`
- `ubuntu_update.py`

## Syntax check

OK: Alle kopierede Python-filer kompilerer.

## Installation

```bash
cd /home/<bruger>/Hentet
unzip -o clientflow_clean_ubuntu_installer_v2.zip -d clientflow_clean_ubuntu_installer_v2
cd clientflow_clean_ubuntu_installer_v2

sudo bash scripts/install_clientflow_clean_ubuntu.sh <bruger> https://kulturskole-infosk-rm.onrender.com
```

Eksempel:

```bash
sudo bash scripts/install_clientflow_clean_ubuntu.sh kulturskolenviborg-info1 https://kulturskole-infosk-rm.onrender.com
```

Efter klienten er oprettet/godkendt:

```bash
sudo bash scripts/install_client_secret_env.sh
```

Verificering:

```bash
bash scripts/verify_clientflow_install.sh <bruger>
```
