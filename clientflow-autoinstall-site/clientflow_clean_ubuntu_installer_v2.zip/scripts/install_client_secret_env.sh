#!/usr/bin/env bash
set -euo pipefail

# Installerer / opdaterer /etc/clientflow/clientflow.env med client credentials.
# Brug:
#   sudo bash install_client_secret_env.sh
# eller:
#   sudo CLIENTFLOW_CLIENT_ID=1370 CLIENTFLOW_CLIENT_SECRET='...' bash install_client_secret_env.sh

if [[ "${EUID}" -ne 0 ]]; then
  echo "FEJL: Kør med sudo."
  exit 1
fi

BASE_URL="${CLIENTFLOW_BASE_URL:-https://kulturskole-infosk-rm.onrender.com}"
CLIENT_ID="${CLIENTFLOW_CLIENT_ID:-}"
CLIENT_SECRET="${CLIENTFLOW_CLIENT_SECRET:-}"

if [[ -z "${CLIENT_ID}" ]]; then
  read -rp "Client ID: " CLIENT_ID
fi
if [[ -z "${CLIENT_SECRET}" ]]; then
  read -rsp "Client secret: " CLIENT_SECRET
  echo
fi

if [[ -z "${CLIENT_ID}" || -z "${CLIENT_SECRET}" ]]; then
  echo "FEJL: CLIENT_ID og CLIENT_SECRET skal udfyldes."
  exit 1
fi

mkdir -p /etc/clientflow
umask 077
cat > /etc/clientflow/clientflow.env <<EOF
CLIENTFLOW_BASE_URL=${BASE_URL}
CLIENTFLOW_USERNAME=
CLIENTFLOW_PASSWORD=
CLIENTFLOW_CLIENT_ID=${CLIENT_ID}
CLIENTFLOW_CLIENT_SECRET=${CLIENT_SECRET}
EOF
chown root:root /etc/clientflow/clientflow.env
chmod 600 /etc/clientflow/clientflow.env

systemctl daemon-reload
for s in clientflow_service.service clientflow_calendar.service client_terminal_agent.service client_remote_desktop_agent.service clientflow_browser_guard.service; do
  systemctl restart "$s" 2>/dev/null || true
done

echo "Installeret client-secret env og genstartet services."
echo
echo "Tjek med:"
echo "  systemctl show clientflow_service.service -p EnvironmentFiles --no-pager"
echo
echo "Tjek faktisk proces-env:"
echo "  PID=\$(systemctl show -p MainPID --value clientflow_service.service)"
echo "  sudo tr '\\0' '\\n' < /proc/\$PID/environ | grep CLIENTFLOW | sed -E 's/CLIENTFLOW_CLIENT_SECRET=.*/CLIENTFLOW_CLIENT_SECRET=***/'"
