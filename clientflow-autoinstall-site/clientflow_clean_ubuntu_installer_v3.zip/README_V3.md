# README V3

V3 erstatter det gamle manuelle client-secret-flow med enrollment.

Fjernet:

- Menuvalg: `Installer client-secret efter godkendelse`
- Manuel forventning om at taste client_id/client_secret efter basisinstallation

Tilføjet:

- `scripts/claim_enrollment_env.sh`
- `CLIENTFLOW_ENROLLMENT_CODE`
- automatisk claim mod `/api/enrollment/claim`
- automatisk skrivning af `/etc/clientflow/clientflow.env`
