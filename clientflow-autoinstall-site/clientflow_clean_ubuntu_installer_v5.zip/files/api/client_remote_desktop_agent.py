#!/usr/bin/env python3
"""
client_remote_desktop_agent.py

ClientFlow remote desktop agent, version 2 MVP.

Design:
- outbound WSS til backend, så det virker bag NAT/firewall
- sender JPEG frames fra X11 displayet
- modtager mus/tastatur-events og udfører dem via xdotool

Krav på klient:
- ffmpeg
- xdotool
- google/Ubuntu desktop med X11 DISPLAY=:0
"""

from __future__ import annotations

import asyncio
import base64
import json
import os
import re
import socket
import subprocess
import sys
import time
from pathlib import Path
from typing import Optional

try:
    import websockets
except Exception as e:
    print(f"FEJL: websockets mangler: {e}", file=sys.stderr)
    print("Installer med: ./venv/bin/pip install websockets==12.0", file=sys.stderr)
    raise

import clientflow_service as cfs  # type: ignore

LOG_PATH = str(Path(cfs.API_DIR) / "client_remote_desktop_agent.log")

DISPLAY = os.environ.get("DISPLAY", ":0")
XAUTHORITY = os.environ.get("XAUTHORITY", "/run/user/1000/gdm/Xauthority")

RECONNECT_SECONDS = int(os.environ.get("CLIENTFLOW_REMOTE_DESKTOP_RECONNECT_SECONDS", "5"))
FPS = float(os.environ.get("CLIENTFLOW_REMOTE_DESKTOP_FPS", "2"))
JPEG_QUALITY = int(os.environ.get("CLIENTFLOW_REMOTE_DESKTOP_JPEG_QUALITY", "6"))
CAPTURE_TIMEOUT = float(os.environ.get("CLIENTFLOW_REMOTE_DESKTOP_CAPTURE_TIMEOUT", "4"))
MAX_FRAME_BYTES = int(os.environ.get("CLIENTFLOW_REMOTE_DESKTOP_MAX_FRAME_BYTES", str(2 * 1024 * 1024)))

STREAM_TASKS: dict[str, asyncio.Task] = {}


def log(msg: str) -> None:
    line = f"{time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())} - remote_desktop_agent: {msg}"
    print(line, flush=True)
    try:
        with open(LOG_PATH, "a", encoding="utf-8") as f:
            f.write(line + "\n")
    except Exception:
        pass


def _ws_base_url() -> str:
    base = cfs.BASE_URL.rstrip("/")
    if base.startswith("https://"):
        return "wss://" + base[len("https://"):]
    if base.startswith("http://"):
        return "ws://" + base[len("http://"):]
    return base


def _get_client_id() -> Optional[int]:
    try:
        cid = cfs.get_client_id()
        if cid:
            return int(cid)
    except Exception:
        pass
    try:
        cfg = json.loads(Path(cfs.CONFIG_PATH).read_text(encoding="utf-8"))
        cid = cfg.get("id") or cfg.get("client_id")
        return int(cid) if cid else None
    except Exception:
        return None


def _get_token() -> Optional[str]:
    backend = cfs.BackendAPI(
        cfs.BASE_URL,
        cfs.USERNAME,
        cfs.PASSWORD,
        getattr(cfs, "CLIENT_ID_ENV", ""),
        getattr(cfs, "CLIENT_SECRET", ""),
    )
    return backend._get_token()


def _env() -> dict:
    env = {**os.environ}
    env["DISPLAY"] = DISPLAY
    env["XAUTHORITY"] = XAUTHORITY
    return env


def _detect_screen_size() -> tuple[int, int]:
    # 1) xrandr er typisk mest præcis på X11.
    try:
        r = subprocess.run(
            ["xrandr", "--current"],
            stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
            text=True,
            timeout=2,
            env=_env(),
        )
        for line in (r.stdout or "").splitlines():
            if "*" in line:
                m = re.search(r"(\d+)x(\d+)", line)
                if m:
                    return int(m.group(1)), int(m.group(2))
    except Exception:
        pass

    # 2) fallback til xdpyinfo
    try:
        r = subprocess.run(
            ["xdpyinfo"],
            stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
            text=True,
            timeout=2,
            env=_env(),
        )
        m = re.search(r"dimensions:\s+(\d+)x(\d+)", r.stdout or "")
        if m:
            return int(m.group(1)), int(m.group(2))
    except Exception:
        pass

    # 3) miljø/fallback
    try:
        w = int(os.environ.get("CLIENTFLOW_REMOTE_DESKTOP_WIDTH", "1920"))
        h = int(os.environ.get("CLIENTFLOW_REMOTE_DESKTOP_HEIGHT", "1080"))
        return w, h
    except Exception:
        return 1920, 1080


SCREEN_W, SCREEN_H = _detect_screen_size()


async def _send(ws, payload: dict) -> None:
    await ws.send(json.dumps(payload, ensure_ascii=False))


async def _capture_frame() -> bytes:
    """
    Tager ét JPEG-frame med ffmpeg x11grab.
    MVP'en starter ffmpeg per frame. Det er simpelt og robust, men ikke så
    effektivt som en permanent MJPEG/WebRTC pipeline. Hold FPS lavt.
    """
    cmd = [
        "ffmpeg",
        "-hide_banner",
        "-loglevel", "error",
        "-f", "x11grab",
        "-video_size", f"{SCREEN_W}x{SCREEN_H}",
        "-i", f"{DISPLAY}.0",
        "-frames:v", "1",
        "-q:v", str(JPEG_QUALITY),
        "-f", "image2pipe",
        "-vcodec", "mjpeg",
        "pipe:1",
    ]

    proc = await asyncio.create_subprocess_exec(
        *cmd,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
        env=_env(),
    )

    try:
        stdout, stderr = await asyncio.wait_for(proc.communicate(), timeout=CAPTURE_TIMEOUT)
    except asyncio.CancelledError:
        # Service-restart/stop kan afbryde et aktivt ffmpeg-capture.
        # Luk processen rent, så agenten ikke ender med traceback/status=1.
        try:
            proc.kill()
        except Exception:
            pass
        try:
            await proc.wait()
        except Exception:
            pass
        raise
    except asyncio.TimeoutError:
        try:
            proc.kill()
        except Exception:
            pass
        try:
            await proc.wait()
        except Exception:
            pass
        raise RuntimeError("ffmpeg capture timeout")

    if proc.returncode != 0 or not stdout:
        err = (stderr or b"").decode(errors="replace")[:300]
        raise RuntimeError(f"ffmpeg capture fejlede rc={proc.returncode}: {err}")

    if len(stdout) > MAX_FRAME_BYTES:
        raise RuntimeError(f"frame for stort: {len(stdout)} bytes")

    return stdout


async def _stream_loop(ws, session_id: str) -> None:
    interval = max(0.1, 1.0 / max(FPS, 0.2))
    await _send(ws, {
        "type": "stream_started",
        "session_id": session_id,
        "width": SCREEN_W,
        "height": SCREEN_H,
        "fps": FPS,
    })

    while True:
        started = time.time()
        try:
            frame = await _capture_frame()
            await _send(ws, {
                "type": "frame",
                "session_id": session_id,
                "width": SCREEN_W,
                "height": SCREEN_H,
                "encoding": "jpeg_base64",
                "data": base64.b64encode(frame).decode("ascii"),
                "ts": time.time(),
            })
        except asyncio.CancelledError:
            raise
        except Exception as e:
            await _send(ws, {
                "type": "remote_error",
                "session_id": session_id,
                "message": str(e),
            })
            await asyncio.sleep(1)

        elapsed = time.time() - started
        await asyncio.sleep(max(0.01, interval - elapsed))


def _clamp_xy(x, y) -> tuple[int, int]:
    try:
        ix = max(0, min(SCREEN_W - 1, int(round(float(x)))))
        iy = max(0, min(SCREEN_H - 1, int(round(float(y)))))
        return ix, iy
    except Exception:
        return 0, 0


async def _run_xdotool(args: list[str]) -> None:
    cmd = ["xdotool", *args]
    proc = await asyncio.create_subprocess_exec(
        *cmd,
        stdout=asyncio.subprocess.DEVNULL,
        stderr=asyncio.subprocess.PIPE,
        env=_env(),
    )
    _, stderr = await proc.communicate()
    if proc.returncode != 0:
        err = (stderr or b"").decode(errors="replace")[:200]
        raise RuntimeError(f"xdotool fejlede rc={proc.returncode}: {err}")


async def handle_mouse(msg: dict) -> None:
    action = str(msg.get("action") or "").lower()
    x, y = _clamp_xy(msg.get("x", 0), msg.get("y", 0))

    def _button(default: int = 1) -> str:
        try:
            b = int(msg.get("button") or default)
            if b not in (1, 2, 3):
                b = default
            return str(b)
        except Exception:
            return str(default)

    # Flyt altid musen først for alle position-baserede events.
    if action in ("move", "click", "double_click", "right_click", "down", "up", "mouse_down", "mouse_up"):
        await _run_xdotool(["mousemove", str(x), str(y)])

    if action == "move":
        return

    if action == "click":
        await _run_xdotool(["click", _button(1)])
    elif action == "double_click":
        await _run_xdotool(["click", "--repeat", "2", "--delay", "80", "1"])
    elif action == "right_click":
        await _run_xdotool(["click", "3"])
    elif action in ("down", "mouse_down"):
        await _run_xdotool(["mousedown", _button(1)])
    elif action in ("up", "mouse_up"):
        await _run_xdotool(["mouseup", _button(1)])
    elif action == "scroll":
        delta = int(msg.get("delta") or 0)
        button = "4" if delta > 0 else "5"
        repeat = max(1, min(8, abs(delta)))
        for _ in range(repeat):
            await _run_xdotool(["click", button])


async def handle_key(msg: dict) -> None:
    key = str(msg.get("key") or "").strip()
    if not key:
        return
    # Examples: F5, Escape, Return, BackSpace, ctrl+r, alt+F4
    await _run_xdotool(["key", "--clearmodifiers", key])


async def handle_text(msg: dict) -> None:
    text = str(msg.get("text") or "")
    if not text:
        return
    # Begræns tekst for at undgå fejltryk med meget lange strenge.
    text = text[:500]
    await _run_xdotool(["type", "--clearmodifiers", "--delay", "1", text])


async def handle_shout(msg: dict) -> None:
    """
    Viser shout out på klientens skærm.

    Stabil metode:
    - tager screenshot af aktuel skærm
    - mørkner screenshot 20%
    - tegner stor hvid tekst ovenpå
    - viser billedet fullscreen med feh
    """
    text = str(msg.get("text") or "").strip()
    if not text:
        return

    text = text[:120]
    log(f"SHOUT modtaget: {text!r}")

    try:
        duration = int(msg.get("duration") or 8)
    except Exception:
        duration = 8
    duration = max(3, min(duration, 30))

    env = _env()

    script = """
import os
import sys
import time
import textwrap
import subprocess
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont

message = sys.argv[1].upper()
duration = int(sys.argv[2])
display = sys.argv[3]
xauth = sys.argv[4]
screen_w = int(sys.argv[5])
screen_h = int(sys.argv[6])

tmp = Path("/tmp/clientflow_shout")
tmp.mkdir(parents=True, exist_ok=True)

shot = tmp / "screen.png"
out = tmp / "shout.png"

env = os.environ.copy()
env["DISPLAY"] = display
env["XAUTHORITY"] = xauth

# Screenshot.
subprocess.run(
    [
        "ffmpeg",
        "-hide_banner",
        "-loglevel", "error",
        "-y",
        "-f", "x11grab",
        "-video_size", f"{screen_w}x{screen_h}",
        "-i", f"{display}.0",
        "-frames:v", "1",
        str(shot),
    ],
    env=env,
    timeout=5,
    check=True,
)

img = Image.open(shot).convert("RGB")

# 20% mørk “transparent” effekt.
dark = Image.new("RGB", img.size, (0, 0, 0))
img = Image.blend(img, dark, 0.30)

draw = ImageDraw.Draw(img)

font_path = "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"
max_width = int(screen_w * 0.78)

font_size = 118
while font_size > 38:
    font = ImageFont.truetype(font_path, font_size)

    words = message.split()
    lines = []
    current = ""

    for word in words:
        candidate = word if not current else current + " " + word
        bbox = draw.textbbox((0, 0), candidate, font=font)
        if bbox[2] - bbox[0] <= max_width or not current:
            current = candidate
        else:
            lines.append(current)
            current = word

    if current:
        lines.append(current)

    lines = lines[:4]

    line_heights = []
    line_widths = []
    for line in lines:
        bbox = draw.textbbox((0, 0), line, font=font, stroke_width=5)
        line_widths.append(bbox[2] - bbox[0])
        line_heights.append(bbox[3] - bbox[1])

    total_h = sum(line_heights) + max(0, len(lines) - 1) * int(font_size * 0.25)
    widest = max(line_widths or [0])

    if widest <= max_width and total_h <= int(screen_h * 0.55):
        break

    font_size -= 4

y = int((screen_h - total_h) / 2)

for line, lh in zip(lines, line_heights):
    bbox = draw.textbbox((0, 0), line, font=font, stroke_width=5)
    tw = bbox[2] - bbox[0]
    x = int((screen_w - tw) / 2)

    draw.text(
        (x, y),
        line,
        font=font,
        fill=(255, 255, 255),
        stroke_width=7,
        stroke_fill=(0, 0, 0),
    )

    y += lh + int(font_size * 0.25)

img.save(out)

proc = subprocess.Popen(
    [
        "feh",
        "--fullscreen",
        "--hide-pointer",
        "--borderless",
        "--quiet",
        str(out),
    ],
    env=env,
    stdout=subprocess.DEVNULL,
    stderr=subprocess.DEVNULL,
)

time.sleep(duration)

try:
    proc.terminate()
    proc.wait(timeout=2)
except Exception:
    try:
        proc.kill()
    except Exception:
        pass
"""

    try:
        subprocess.Popen(
            [
                "/usr/bin/python3",
                "-c",
                script,
                text,
                str(duration),
                DISPLAY,
                XAUTHORITY,
                str(SCREEN_W),
                str(SCREEN_H),
            ],
            env=env,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            start_new_session=True,
        )
        log("SHOUT screenshot-overlay startet")
        return
    except Exception as e:
        log(f"Kunne ikke starte shout screenshot-overlay: {e}")

    try:
        subprocess.Popen(
            ["notify-send", "ClientFlow", text],
            env=env,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            start_new_session=True,
        )
        log("SHOUT notify-send fallback startet")
    except Exception as e:
        log(f"Kunne ikke vise shout out fallback: {e}")




async def _stop_session(session_id: str) -> None:
    task = STREAM_TASKS.pop(session_id, None)
    if task and not task.done():
        task.cancel()
        try:
            await task
        except asyncio.CancelledError:
            # Normal afslutning når stream-task stoppes.
            pass
        except Exception:
            pass


async def connect_loop() -> None:
    client_id = _get_client_id()
    if not client_id:
        raise SystemExit("Mangler klient-id i clientflow_config.json")

    while True:
        token = _get_token()
        if not token:
            log("Kunne ikke hente token; prøver igen om lidt")
            await asyncio.sleep(RECONNECT_SECONDS)
            continue

        url = f"{_ws_base_url()}/api/remote-desktop/agent/{client_id}/ws?token={token}"
        try:
            log(f"Forbinder til {url.split('?')[0]}")
            async with websockets.connect(url, ping_interval=20, ping_timeout=20, max_size=2**25) as ws:
                await _send(ws, {
                    "type": "hello",
                    "hostname": socket.gethostname(),
                    "client_id": client_id,
                    "width": SCREEN_W,
                    "height": SCREEN_H,
                    "display": DISPLAY,
                    "fps": FPS,
                })
                log(f"Forbundet til remote desktop-broker ({SCREEN_W}x{SCREEN_H}@{FPS}fps)")

                async for raw in ws:
                    try:
                        msg = json.loads(raw)
                    except Exception:
                        continue

                    msg_type = msg.get("type")
                    session_id = str(msg.get("session_id") or "")

                    try:
                        if msg_type == "browser_connected":
                            log(f"Browser forbundet session={session_id} user={msg.get('username')}")
                            continue

                        if msg_type in ("start_stream", "request_frame"):
                            if not session_id:
                                continue
                            if session_id not in STREAM_TASKS or STREAM_TASKS[session_id].done():
                                STREAM_TASKS[session_id] = asyncio.create_task(_stream_loop(ws, session_id))
                            continue

                        if msg_type == "stop_stream":
                            if session_id:
                                await _stop_session(session_id)
                            continue

                        if msg_type == "mouse":
                            await handle_mouse(msg)
                            continue

                        if msg_type == "key":
                            await handle_key(msg)
                            continue

                        if msg_type == "text":
                            await handle_text(msg)
                            continue

                        if msg_type == "shout":
                            log("SHOUT kommando modtaget fra broker")
                            await handle_shout(msg)
                            continue

                    except Exception as e:
                        if session_id:
                            await _send(ws, {
                                "type": "remote_error",
                                "session_id": session_id,
                                "message": str(e),
                            })

        except Exception as e:
            log(f"WebSocket afbrudt/fejl: {e}")

        for sid in list(STREAM_TASKS.keys()):
            await _stop_session(sid)

        await asyncio.sleep(RECONNECT_SECONDS)


if __name__ == "__main__":
    try:
        asyncio.run(connect_loop())
    except KeyboardInterrupt:
        log("Stopper efter KeyboardInterrupt")
    except asyncio.CancelledError:
        log("Stopper efter CancelledError")
