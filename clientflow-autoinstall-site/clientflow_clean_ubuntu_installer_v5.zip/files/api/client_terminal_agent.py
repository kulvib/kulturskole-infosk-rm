#!/usr/bin/env python3
"""
client_terminal_agent.py

Outbound remote-terminal agent for ClientFlow.

Denne agent er lavet til klienter bag kommune/stat-firewall:
- Den åbner selv en udgående WSS-forbindelse til backend.
- Backend kan derefter brokere kommandoer fra frontend til klienten.

MVP: kommandobaseret terminal, ikke fuld PTY endnu.
"""

from __future__ import annotations

import asyncio
import json
import os
import shlex
import socket
import sys
import time
from pathlib import Path
from typing import Optional

try:
    import websockets
except Exception as e:
    print(f"FEJL: websockets mangler: {e}", file=sys.stderr)
    print("Installer med: ./venv/bin/pip install websockets==12.0", file=sys.stderr)
    raise

# Genbrug klientens eksisterende backend-login/config.
import clientflow_service as cfs  # type: ignore

LOG_PATH = str(Path(cfs.API_DIR) / "client_terminal_agent.log")
DEFAULT_TIMEOUT = int(os.environ.get("CLIENTFLOW_TERMINAL_COMMAND_TIMEOUT", "120"))
RECONNECT_SECONDS = int(os.environ.get("CLIENTFLOW_TERMINAL_RECONNECT_SECONDS", "5"))
MAX_OUTPUT_CHARS = int(os.environ.get("CLIENTFLOW_TERMINAL_MAX_OUTPUT_CHARS", "200000"))

SESSION_CWDS: dict[str, str] = {}


def log(msg: str) -> None:
    line = f"{time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())} - terminal_agent: {msg}"
    print(line, flush=True)
    try:
        with open(LOG_PATH, "a", encoding="utf-8") as f:
            f.write(line + "\n")
    except Exception:
        pass


def _ws_base_url() -> str:
    base = cfs.BASE_URL.rstrip("/")
    if base.startswith("https://"):
        return "wss://" + base[len("https://"):]
    if base.startswith("http://"):
        return "ws://" + base[len("http://"):]
    return base


def _get_client_id() -> Optional[int]:
    try:
        cid = cfs.get_client_id()
        if cid:
            return int(cid)
    except Exception:
        pass
    try:
        cfg = json.loads(Path(cfs.CONFIG_PATH).read_text(encoding="utf-8"))
        cid = cfg.get("id") or cfg.get("client_id")
        return int(cid) if cid else None
    except Exception:
        return None


def _get_token() -> Optional[str]:
    backend = cfs.BackendAPI(
        cfs.BASE_URL,
        cfs.USERNAME,
        cfs.PASSWORD,
        getattr(cfs, "CLIENT_ID_ENV", ""),
        getattr(cfs, "CLIENT_SECRET", ""),
    )
    return backend._get_token()


def _normalize_cwd(path: str) -> str:
    try:
        p = Path(path).expanduser().resolve()
        if p.exists() and p.is_dir():
            return str(p)
    except Exception:
        pass
    return str(Path.home())


async def _send(ws, payload: dict) -> None:
    await ws.send(json.dumps(payload, ensure_ascii=False))


async def run_command(ws, msg: dict) -> None:
    session_id = str(msg.get("session_id") or "")
    request_id = str(msg.get("request_id") or "")
    command = str(msg.get("command") or "").strip()

    if not session_id or not request_id:
        return

    if not command:
        await _send(ws, {"type": "exit", "session_id": session_id, "request_id": request_id, "code": 0})
        return

    cwd = _normalize_cwd(SESSION_CWDS.get(session_id) or str(Path.home()))
    marker = f"__CLIENTFLOW_CWD_{request_id}__"

    # Kør i samme session-cwd. Marker ny cwd til sidst, så `cd /tmp` huskes.
    wrapped = (
        f"cd {shlex.quote(cwd)}; "
        f"{{ {command}; }}; rc=$?; "
        f"printf '\\n{marker}%s\\n' \"$PWD\"; "
        f"exit $rc"
    )

    await _send(ws, {
        "type": "started",
        "session_id": session_id,
        "request_id": request_id,
        "cwd": cwd,
        "command": command,
    })

    try:
        proc = await asyncio.create_subprocess_exec(
            "/bin/bash", "-lc", wrapped,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
            cwd=cwd,
            env={**os.environ, "TERM": "xterm-256color"},
        )

        try:
            stdout_b, stderr_b = await asyncio.wait_for(proc.communicate(), timeout=DEFAULT_TIMEOUT)
        except asyncio.TimeoutError:
            try:
                proc.kill()
            except Exception:
                pass
            await _send(ws, {
                "type": "output",
                "session_id": session_id,
                "request_id": request_id,
                "stream": "stderr",
                "data": f"\n[timeout efter {DEFAULT_TIMEOUT} sekunder]\n",
            })
            await _send(ws, {"type": "exit", "session_id": session_id, "request_id": request_id, "code": 124})
            return

        stdout = stdout_b.decode(errors="replace") if stdout_b else ""
        stderr = stderr_b.decode(errors="replace") if stderr_b else ""

        marker_index = stdout.rfind(marker)
        if marker_index >= 0:
            before = stdout[:marker_index]
            after = stdout[marker_index + len(marker):].strip().splitlines()
            if after:
                SESSION_CWDS[session_id] = _normalize_cwd(after[0].strip())
            stdout = before.rstrip("\n") + ("\n" if before else "")

        if len(stdout) > MAX_OUTPUT_CHARS:
            stdout = stdout[:MAX_OUTPUT_CHARS] + "\n[output forkortet]\n"
        if len(stderr) > MAX_OUTPUT_CHARS:
            stderr = stderr[:MAX_OUTPUT_CHARS] + "\n[stderr forkortet]\n"

        if stdout:
            await _send(ws, {"type": "output", "session_id": session_id, "request_id": request_id, "stream": "stdout", "data": stdout})
        if stderr:
            await _send(ws, {"type": "output", "session_id": session_id, "request_id": request_id, "stream": "stderr", "data": stderr})

        await _send(ws, {
            "type": "exit",
            "session_id": session_id,
            "request_id": request_id,
            "code": int(proc.returncode or 0),
            "cwd": SESSION_CWDS.get(session_id, cwd),
        })

    except Exception as e:
        await _send(ws, {"type": "output", "session_id": session_id, "request_id": request_id, "stream": "stderr", "data": f"FEJL: {e}\n"})
        await _send(ws, {"type": "exit", "session_id": session_id, "request_id": request_id, "code": 1})


async def connect_loop() -> None:
    client_id = _get_client_id()
    if not client_id:
        raise SystemExit("Mangler klient-id i clientflow_config.json")

    while True:
        token = _get_token()
        if not token:
            log("Kunne ikke hente token; prøver igen om lidt")
            await asyncio.sleep(RECONNECT_SECONDS)
            continue

        url = f"{_ws_base_url()}/api/terminal/client/{client_id}/ws?token={token}"
        try:
            log(f"Forbinder til {url.split('?')[0]}")
            async with websockets.connect(url, ping_interval=20, ping_timeout=20, max_size=2**22) as ws:
                await _send(ws, {"type": "hello", "hostname": socket.gethostname(), "client_id": client_id})
                log("Forbundet til terminal-broker")

                async for raw in ws:
                    try:
                        msg = json.loads(raw)
                    except Exception:
                        continue
                    if msg.get("type") == "run":
                        asyncio.create_task(run_command(ws, msg))
        except Exception as e:
            log(f"WebSocket afbrudt/fejl: {e}")
            await asyncio.sleep(RECONNECT_SECONDS)


if __name__ == "__main__":
    asyncio.run(connect_loop())
