#!/usr/bin/env python3
"""
ubuntu_update.py

Udfører Ubuntu system-opdatering sikkert:
 - Tjekker antal tilgængelige opdateringer
 - apt-get update
 - apt-get full-upgrade -y (non-interactive, bevarer eksisterende config-filer)
 - apt-get autoremove -y (rydder op)
 - Rapporterer status løbende til chrome_status.json
 - Afslutter med reboot

Trigger udledes fra env KIOSK_TRIGGER, ellers "backend".

Miljøvariabler:
  KIOSK_TRIGGER           - trigger-kilde (default: "backend")
  OS_UPDATE_TIMEOUT       - max sekunder for apt upgrade (default: 600)
  OS_UPDATE_SKIP_REBOOT   - sæt til "1" for at springe reboot over (test-brug)
"""
from pathlib import Path
import subprocess
import os
import sys
import json
import uuid
import datetime
import time
import shlex
from typing import Optional, Tuple

API_DIR = Path(__file__).resolve().parent
CHROME_STATUS_PATH = API_DIR / "chrome_status.json"
LOG_PATH = API_DIR / "ubuntu_update.log"
LOCK_PATH = API_DIR / "ubuntu_update.lock"

TRIGGER = os.environ.get("KIOSK_TRIGGER", "backend")
OS_UPDATE_TIMEOUT = int(os.environ.get("OS_UPDATE_TIMEOUT", "600"))
OS_UPDATE_SKIP_REBOOT = os.environ.get("OS_UPDATE_SKIP_REBOOT", "0").strip() in ("1", "true", "yes")
# full-upgrade tager også tilbageholdte kernel/HWE-pakker.
# Sæt OS_UPDATE_MODE=upgrade hvis du specifikt vil undgå full-upgrade.
OS_UPDATE_MODE = os.environ.get("OS_UPDATE_MODE", "full-upgrade").strip().lower()
if OS_UPDATE_MODE not in ("upgrade", "full-upgrade", "dist-upgrade"):
    OS_UPDATE_MODE = "full-upgrade"

# Sættes i main(), når opdateringen er gennemført.
# Entry-point bruger denne til kun at genstarte, hvis Ubuntu kræver det.
REBOOT_REQUIRED_AFTER_UPDATE = False


# ---------------------------------------------------------------------------
# Logging
# ---------------------------------------------------------------------------
def now_iso() -> str:
    return datetime.datetime.now(datetime.timezone.utc).strftime(
        "%Y-%m-%dT%H:%M:%S.%f"
    ) + "Z"


def log(msg: str) -> None:
    line = f"{now_iso()} - ubuntu_update: {msg}\n"
    try:
        with open(LOG_PATH, "a", encoding="utf-8") as f:
            f.write(line)
    except Exception:
        pass
    try:
        print(line, end="")
        sys.stdout.flush()
    except Exception:
        pass


def run_command_live(cmd, timeout: int, env=None) -> bool:
    """
    Kør kommando og skriv stdout/stderr løbende til ubuntu_update.log.

    Den tidligere version brugte capture_output=True. Det gør, at apt kan se ud
    som om den fryser, og hvis processen afbrydes, får vi ikke sidste stderr med.
    Denne version logger live, så vi kan se præcis hvor apt/dpkg står.
    """
    started = time.monotonic()
    printable = " ".join(shlex.quote(str(x)) for x in cmd)
    log(f"Kører live: {printable} (timeout={timeout}s)")

    try:
        proc = subprocess.Popen(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            bufsize=1,
            env=env or os.environ.copy(),
        )
    except Exception as e:
        log(f"FEJL: kunne ikke starte kommando: {e}")
        return False

    output_lines = 0

    try:
        while True:
            if proc.stdout is not None:
                line = proc.stdout.readline()
                if line:
                    output_lines += 1
                    clean = line.rstrip()
                    if clean:
                        log(f"apt: {clean}")

            rc = proc.poll()
            if rc is not None:
                # Tøm evt. resterende output
                if proc.stdout is not None:
                    for rest in proc.stdout:
                        clean = rest.rstrip()
                        if clean:
                            output_lines += 1
                            log(f"apt: {clean}")
                log(f"Kommando afsluttet rc={rc}, output_lines={output_lines}")
                return rc == 0

            if time.monotonic() - started > timeout:
                log(f"TIMEOUT efter {timeout}s — terminerer kommando")
                try:
                    proc.terminate()
                    proc.wait(timeout=10)
                except Exception:
                    try:
                        proc.kill()
                    except Exception:
                        pass
                return False

            time.sleep(0.1)
    except Exception as e:
        log(f"FEJL under kommando: {e}")
        try:
            proc.kill()
        except Exception:
            pass
        return False


def acquire_lock() -> bool:
    """Undgå parallelle apt-kørsler fra flere ubuntu_update.py-processer."""
    try:
        if LOCK_PATH.exists():
            try:
                old_pid = int(LOCK_PATH.read_text(encoding="utf-8").strip() or "0")
            except Exception:
                old_pid = 0

            if old_pid > 0 and Path(f"/proc/{old_pid}").exists():
                log(f"En anden ubuntu_update.py kører allerede (pid={old_pid}) — afslutter.")
                return False

            log("Fjerner stale ubuntu_update.lock")
            try:
                LOCK_PATH.unlink()
            except Exception:
                pass

        LOCK_PATH.write_text(str(os.getpid()), encoding="utf-8")
        return True
    except Exception as e:
        log(f"Kunne ikke oprette lock-fil: {e}")
        return False


def release_lock() -> None:
    try:
        if LOCK_PATH.exists() and LOCK_PATH.read_text(encoding="utf-8").strip() == str(os.getpid()):
            LOCK_PATH.unlink()
    except Exception:
        pass


# ---------------------------------------------------------------------------
# Status skrivning til chrome_status.json
# ---------------------------------------------------------------------------
def _atomic_write(path: Path, obj: dict) -> None:
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        tmp = path.with_name(f"{path.name}.tmp.{os.getpid()}.{uuid.uuid4().hex[:8]}")
        tmp.write_text(json.dumps(obj, ensure_ascii=False, indent=2), encoding="utf-8")
        os.replace(str(tmp), str(path))
    except Exception as e:
        log(f"FEJL i _atomic_write: {e}")


def write_status_step(
    step: str,
    message: str,
    color: str = "orange",
    extra: Optional[str] = None,
) -> None:
    """Skriv et status-step til chrome_status.json."""
    step_obj = {
        "step": step,
        "message": message,
        "status": step,
        "trigger": TRIGGER,
        "color": color,
        "timestamp": now_iso(),
        "id": str(uuid.uuid4()),
    }
    if extra is not None:
        step_obj["extra"] = extra

    # Forsøg via chrome_kiosk (id-preserving)
    try:
        import chrome_kiosk  # type: ignore
        if hasattr(chrome_kiosk, "append_external_step"):
            chrome_kiosk.append_external_step(step_obj)
            log(f"write_status_step (chrome_kiosk): {step} — {message}")
            return
    except Exception:
        pass

    # Fallback: skriv direkte
    try:
        data: dict = {"steps": [], "chrome_running": False}
        if CHROME_STATUS_PATH.exists():
            try:
                data = json.loads(CHROME_STATUS_PATH.read_text(encoding="utf-8"))
            except Exception:
                pass
        steps = data.get("steps", [])
        if not isinstance(steps, list):
            steps = []
        steps.append(step_obj)
        data["steps"] = steps[-50:]
        _atomic_write(CHROME_STATUS_PATH, data)
        log(f"write_status_step (fallback): {step} — {message}")
    except Exception as e:
        log(f"FEJL ved write_status_step fallback: {e}")


# ---------------------------------------------------------------------------
# apt helpers
# ---------------------------------------------------------------------------
def count_upgradable() -> Tuple[int, list]:
    """
    Returnerer (antal, liste af pakkenavne) der kan opgraderes.
    Kører UDEN sudo — apt list --upgradable kræver ikke root.
    """
    try:
        result = subprocess.run(
            ["apt", "list", "--upgradable"],
            capture_output=True, text=True, timeout=60,
        )
        lines = [
            line.strip() for line in result.stdout.splitlines()
            if "/" in line and line.strip()
        ]
        packages = [line.split("/")[0] for line in lines]
        return len(packages), packages
    except Exception as e:
        log(f"Fejl ved count_upgradable: {e}")
        return 0, []


def run_apt_update() -> bool:
    """Kør apt-get update for at friske pakkelisten op."""
    log("Kører: sudo -n apt-get update")
    write_status_step(
        "os_update_fetching",
        "Ubuntu: henter pakkeliste fra servere...",
        "orange",
    )
    return run_command_live(["sudo", "-n", "apt-get", "update"], timeout=120)


def run_apt_upgrade() -> bool:
    """Kør apt-get full-upgrade med live logging."""
    apt_action = "dist-upgrade" if OS_UPDATE_MODE == "dist-upgrade" else OS_UPDATE_MODE

    log(f"Kører: sudo -n apt-get {apt_action} -y (timeout={OS_UPDATE_TIMEOUT}s)")
    write_status_step(
        "os_upgrading",
        f"Ubuntu: installerer opdateringer ({apt_action})...",
        "orange",
    )

    env = {
        **os.environ,
        "DEBIAN_FRONTEND": "noninteractive",
        "APT_LISTCHANGES_FRONTEND": "none",
        "NEEDRESTART_MODE": "a",
        "UCF_FORCE_CONFFOLD": "1",
    }

    return run_command_live(
        [
            "sudo", "-n", "apt-get", apt_action, "-y",
            "-o", "Dpkg::Options::=--force-confdef",
            "-o", "Dpkg::Options::=--force-confold",
        ],
        timeout=OS_UPDATE_TIMEOUT,
        env=env,
    )

def run_apt_autoremove() -> bool:
    """Fjern unødvendige pakker efter opdatering."""
    log("Kører: sudo -n apt-get autoremove -y")
    write_status_step(
        "os_cleanup",
        "Ubuntu: rydder op efter opdatering...",
        "orange",
    )
    return run_command_live(
        ["sudo", "-n", "apt-get", "autoremove", "-y"],
        timeout=120,
        env={**os.environ, "DEBIAN_FRONTEND": "noninteractive"},
    )


def needs_reboot() -> bool:
    """Returnerer True hvis /var/run/reboot-required eksisterer."""
    return Path("/var/run/reboot-required").exists()


# ---------------------------------------------------------------------------
# Reboot
# ---------------------------------------------------------------------------
def do_reboot() -> None:
    if OS_UPDATE_SKIP_REBOOT:
        log("OS_UPDATE_SKIP_REBOOT=1 — springer reboot over.")
        return
    log("Genstarter systemet om 5 sekunder...")
    write_status_step(
        "os_rebooting",
        "Ubuntu-opdatering gennemført — genstarter klienten...",
        "green",
    )
    time.sleep(5)
    for cmd in ("sudo -n /sbin/reboot", "sudo -n reboot", "sudo -n systemctl reboot"):
        log(f"Forsøger: {cmd}")
        os.system(cmd)
        time.sleep(5)
    log("ADVARSEL: Reboot-kommandoer fejlede.")


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------
def main() -> int:
    log(f"=" * 60)
    log(f"Starter ubuntu_update.py (trigger={TRIGGER})")
    log(f"OS_UPDATE_TIMEOUT={OS_UPDATE_TIMEOUT}s, SKIP_REBOOT={OS_UPDATE_SKIP_REBOOT}, MODE={OS_UPDATE_MODE}")
    log(f"=" * 60)

    if not acquire_lock():
        write_status_step(
            "os_update_failed",
            "Ubuntu: opdatering kører allerede eller lock kunne ikke oprettes",
            "red",
        )
        return 1

    # 1) Tjek hvad der er tilgængeligt
    count, packages = count_upgradable()
    if count == 0:
        log("Ingen opdateringer tilgængelige — afslutter.")
        write_status_step(
            "os_update_none",
            "Ubuntu: ingen opdateringer tilgængelige",
            "green",
        )
        return 0

    log(f"{count} pakke(r) kan opdateres: {', '.join(packages[:10])}" +
        (f" ... og {count - 10} flere" if count > 10 else ""))

    write_status_step(
        "os_update_started",
        f"Ubuntu-opdatering startet: {count} pakke(r) skal opdateres",
        "orange",
    )

    # 2) apt-get update
    if not run_apt_update():
        write_status_step(
            "os_update_failed",
            "Ubuntu: apt-get update fejlede — opdatering afbrudt",
            "red",
        )
        return 1

    # 3) apt-get upgrade
    if not run_apt_upgrade():
        write_status_step(
            "os_update_failed",
            f"Ubuntu: apt-get {OS_UPDATE_MODE} fejlede — opdatering afbrudt",
            "red",
        )
        return 1

    # 4) autoremove (ikke kritisk)
    run_apt_autoremove()

    # 5) Kontrollér om reboot er påkrævet
    global REBOOT_REQUIRED_AFTER_UPDATE
    reboot_required = needs_reboot()
    REBOOT_REQUIRED_AFTER_UPDATE = reboot_required

    log(f"Reboot påkrævet: {reboot_required}")

    write_status_step(
        "os_update_complete",
        (
            f"Ubuntu-opdatering gennemført ({count} pakke(r)) — "
            f"{'genstarter klienten' if reboot_required else 'ingen genstart nødvendig'}"
        ),
        "green",
    )

    return 0


# ---------------------------------------------------------------------------
# Entry
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    rc = main()

    if rc == 0 and REBOOT_REQUIRED_AFTER_UPDATE:
        do_reboot()
    elif rc == 0:
        log("Ubuntu-opdatering færdig — ingen reboot nødvendig.")
    else:
        log(f"ubuntu_update afsluttede med fejl (rc={rc}) — ingen reboot.")

    sys.exit(rc)
