#!/usr/bin/env python3
"""
clientflow_calendar.py

Henter kalenderdata fra backend og:
  1) Skriver de næste 5 dage til calendar_gui.json til GUI'en.
  2) Kører en scheduler-tråd der i dansk tid (Europe/Copenhagen) automatisk:
       - vækker klienten (kiosk_wake.py + reboot) ved onTime
       - sætter klienten i dvale (kiosk_sleep.py) ved offTime
     Trigger sættes til "calendar" i alle status-events.

Miljøvariabler:
  CLIENTFLOW_BASE_URL   - backend URL
  CLIENTFLOW_CLIENT_ID     - ny client-id auth fra enrollment
  CLIENTFLOW_CLIENT_SECRET - ny client-secret auth fra enrollment
  CLIENTFLOW_USERNAME      - bagudkompatibel backend bruger
  CLIENTFLOW_PASSWORD      - bagudkompatibel backend kode
  CALENDAR_POLL_INTERVAL - sek mellem backend-polls (default 15)
  SCHEDULER_TICK_SECONDS - sek mellem scheduler-checks (default 30)
  WAKE_REBOOT_DELAY     - sek fra wake til reboot (default 15)
  WAKE_REBOOT_COOLDOWN  - min antal sek mellem 2 wake-reboots (default 300)
  CALENDAR_BOOT_GRACE_SECONDS - sek scheduler venter ved opstart (default 90)
"""
from pathlib import Path
import time
import requests
import os
import sys
import json
import subprocess
import threading
import datetime
from typing import Any, Dict, Optional, Tuple

# --- Tidszone (dansk tid) ---
try:
    from zoneinfo import ZoneInfo  # Python 3.9+
    DK_TZ = ZoneInfo("Europe/Copenhagen")
except Exception:
    try:
        import pytz  # type: ignore
        DK_TZ = pytz.timezone("Europe/Copenhagen")
    except Exception:
        DK_TZ = datetime.timezone(datetime.timedelta(hours=1))  # CET fallback

# --- BASE DIR ---
BASE_DIR = Path(__file__).resolve().parent
API_DIR = BASE_DIR
API_DIR.mkdir(parents=True, exist_ok=True)

# --- Konfig via miljø ---
BASE_URL = os.environ.get("CLIENTFLOW_BASE_URL", "https://kulturskole-infosk-rm.onrender.com").rstrip("/")
API_USER = os.environ.get("CLIENTFLOW_USERNAME", os.environ.get("CF_USER", ""))
API_PASS = os.environ.get("CLIENTFLOW_PASSWORD", os.environ.get("CF_PASS", ""))
CLIENT_ID_ENV = os.environ.get("CLIENTFLOW_CLIENT_ID", os.environ.get("CF_CLIENT_ID", "")).strip()
CLIENT_SECRET = os.environ.get("CLIENTFLOW_CLIENT_SECRET", os.environ.get("CF_CLIENT_SECRET", "")).strip()

API_URL = f"{BASE_URL}/api/calendar/marked-days"
SEASON_URL = f"{BASE_URL}/api/calendar/season"
TOKEN_URL = f"{BASE_URL}/auth/token"
CLIENT_TOKEN_URL = f"{BASE_URL}/auth/client-token"

# Filer
CALENDAR_GUI_FILE = str(API_DIR / "calendar_gui.json")
CALENDAR_STATUS_PATH = str(API_DIR / "calendar_status.json")
CONFIG_PATH = str(API_DIR / "clientflow_config.json")
SCHEDULER_STATE_PATH = str(API_DIR / "calendar_scheduler_state.json")
SCHEDULER_DISABLED_FLAG = API_DIR / ".calendar_scheduler_disabled"
KIOSK_SLEEP_SCRIPT = str(API_DIR / "kiosk_sleep.py")
KIOSK_WAKE_SCRIPT = str(API_DIR / "kiosk_wake.py")
KIOSK_SLEEP_LOG = str(API_DIR / "kiosk_sleep_stdout.log")
KIOSK_WAKE_LOG = str(API_DIR / "kiosk_wake_stdout.log")

# Python-binær (venv hvis tilgængelig)
VENV_PY = API_DIR / "venv" / "bin" / "python"
PYTHON_BIN = str(VENV_PY) if VENV_PY.exists() else sys.executable

# Intervaller
POLL_INTERVAL = int(os.environ.get("CALENDAR_POLL_INTERVAL", "15"))
SCHEDULER_TICK_SECONDS = int(os.environ.get("SCHEDULER_TICK_SECONDS", "30"))
WAKE_REBOOT_DELAY = int(os.environ.get("WAKE_REBOOT_DELAY", "15"))
WAKE_REBOOT_COOLDOWN = int(os.environ.get("WAKE_REBOOT_COOLDOWN", "300"))
BOOT_GRACE_SECONDS = int(os.environ.get("CALENDAR_BOOT_GRACE_SECONDS", "90"))

# --- Forsøg at importere utils ---
try:
    from config_utils import read_config, get_client_id, get_status  # type: ignore
except Exception:
    read_config = None
    get_client_id = None
    get_status = None

try:
    from status_utils import log as status_log  # type: ignore
except Exception:
    status_log = None


# ---------------------------------------------------------------------------
# Logging
# ---------------------------------------------------------------------------
def _utc_now_iso() -> str:
    return datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%f") + "Z"


def log(msg: str) -> None:
    line = f"{_utc_now_iso()} - {msg}"
    try:
        print(line)
        sys.stdout.flush()
    except Exception:
        pass
    try:
        if status_log:
            status_log(msg)
    except Exception:
        pass


# ---------------------------------------------------------------------------
# Atomic write
# ---------------------------------------------------------------------------
def atomic_write(path: str, data: Any) -> None:
    import uuid
    try:
        p = Path(path)
        p.parent.mkdir(parents=True, exist_ok=True)
        tmp = p.with_name(f"{p.name}.tmp.{os.getpid()}.{uuid.uuid4().hex[:8]}")
        tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
        os.replace(str(tmp), str(p))
    except Exception as e:
        log(f"FEJL ved atomic_write til {path}: {e}")


# ---------------------------------------------------------------------------
# Ensure files
# ---------------------------------------------------------------------------
def ensure_files():
    try:
        for path, default in [
            (CALENDAR_GUI_FILE, []),
            (CALENDAR_STATUS_PATH, {"steps": []}),
            (CONFIG_PATH, {}),
            (SCHEDULER_STATE_PATH, {"last_applied_state": None, "last_applied_at": None, "last_wake_reboot_ts": 0}),
        ]:
            p = Path(path)
            p.parent.mkdir(parents=True, exist_ok=True)
            if not p.exists():
                p.write_text(json.dumps(default, ensure_ascii=False, indent=2), encoding="utf-8")
    except Exception as e:
        log(f"FEJL ved ensure_files: {e}")


ensure_files()


# ---------------------------------------------------------------------------
# Config helpers (fallbacks)
# ---------------------------------------------------------------------------
def _read_config_fallback():
    try:
        p = Path(CONFIG_PATH)
        if p.exists():
            return json.loads(p.read_text(encoding="utf-8"))
    except Exception as e:
        log(f"FEJL ved read_config fallback: {e}")
    return {}


def _get_client_id_fallback():
    cfg = _read_config_fallback()
    return cfg.get("id") or cfg.get("client_id") or None


def _get_status_fallback():
    cfg = _read_config_fallback()
    return cfg.get("status")


if read_config is None:
    read_config = _read_config_fallback
if get_client_id is None:
    get_client_id = _get_client_id_fallback
if get_status is None:
    get_status = _get_status_fallback


# ---------------------------------------------------------------------------
# Backend HTTP
# ---------------------------------------------------------------------------
def get_token() -> Optional[str]:
    # Foretræk client-secret auth for nye klienter.
    if CLIENT_ID_ENV and CLIENT_SECRET:
        try:
            resp = requests.post(
                CLIENT_TOKEN_URL,
                json={"client_id": int(CLIENT_ID_ENV), "client_secret": CLIENT_SECRET},
                timeout=10,
            )
            if resp.status_code == 200:
                token = resp.json().get("access_token")
                if token:
                    log("[INFO] Fik client-token fra backend.")
                    return token
            log(f"[ERROR] Fejl ved client-token: {resp.status_code} {resp.text[:200]}")
        except Exception as e:
            log(f"[ERROR] Fejl ved client-token: {e}")

    # Bagudkompatibel fallback til user-token.
    if not API_USER or not API_PASS:
        log("API_USER/API_PASS ikke sat, og client-token virker ikke.")
        return None
    data = {"username": API_USER, "password": API_PASS}
    try:
        resp = requests.post(TOKEN_URL, data=data, timeout=10)
        if resp.status_code != 200:
            log(f"[ERROR] Fejl ved hentning af token: {resp.status_code} {resp.text[:200]}")
            return None
        token = resp.json().get("access_token")
        if not token:
            log("[ERROR] access_token ikke fundet i svar.")
            return None
        log("[INFO] Fik user-token fra backend.")
        return token
    except Exception as e:
        log(f"[ERROR] Fejl ved hentning af token: {e}")
        return None


def hent_season(token: Optional[str]) -> Optional[Any]:
    headers = {"Authorization": f"Bearer {token}"} if token else {}
    try:
        r = requests.get(SEASON_URL, headers=headers, timeout=8)
        if r.status_code == 401:
            log("[WARN] SEASON returnerede 401 — token udløbet?")
            return None
        if r.status_code != 200:
            log(f"[ERROR] SEASON fetch fejlede: {r.status_code} {r.text[:200]}")
            return None
        season_id = r.json().get("id")
        log(f"[INFO] Hentet season id: {season_id}")
        return season_id
    except Exception as e:
        log(f"[ERROR] Fejl ved hentning af season: {e}")
        return None


def hent_markeringer(client_id: Any, season: Any, token: Optional[str]) -> Dict[str, Dict[str, Any]]:
    headers = {"Authorization": f"Bearer {token}"} if token else {}
    params = {"client_id": client_id, "season": season}
    try:
        r = requests.get(API_URL, params=params, headers=headers, timeout=10)
        if r.status_code == 401:
            log("[WARN] API_URL returnerede 401 — token udløbet?")
            return {}
        if r.status_code != 200:
            log(f"[ERROR] API response: {r.status_code} {r.text[:200]}")
            return {}
        payload = r.json()
        marked_days = payload.get("markedDays", {}) or {}
        normalized: Dict[str, Dict[str, Any]] = {}
        for k, v in marked_days.items():
            short_key = str(k)[:10]  # YYYY-MM-DD
            normalized[short_key] = v
        log(f"[INFO] Hentet {len(normalized)} markedDays.")
        return normalized
    except Exception as e:
        log(f"[ERROR] Fejl ved hentning af kalender: {e}")
        return {}


# ---------------------------------------------------------------------------
# GUI fil
# ---------------------------------------------------------------------------
def skriv_gui_json(marked_days: Dict[str, Dict[str, Any]], now_dk: datetime.datetime) -> None:
    out = []
    for i in range(5):
        day = now_dk + datetime.timedelta(days=i)
        date_key = day.strftime("%Y-%m-%d")
        mk = marked_days.get(date_key, {}) if isinstance(marked_days, dict) else {}
        out.append({
            "date": date_key,
            "status": mk.get("status", "off"),
            "onTime": mk.get("onTime"),
            "offTime": mk.get("offTime"),
        })
    try:
        atomic_write(CALENDAR_GUI_FILE, out)
        log(f"[INFO] Skrev {len(out)} kalenderdage til {CALENDAR_GUI_FILE}")
    except Exception as e:
        log(f"[ERROR] Fejl ved skrivning til {CALENDAR_GUI_FILE}: {e}")


# ---------------------------------------------------------------------------
# Scheduler logic
# ---------------------------------------------------------------------------
def _parse_hhmm(value: Any) -> Optional[Tuple[int, int]]:
    """Parse tid i format 'HH:MM', 'HH:MM:SS', 'HH.MM', eller 'HH'."""
    if value is None:
        return None
    s = str(value).strip()
    if not s:
        return None
    s = s.replace(".", ":")
    parts = s.split(":")
    try:
        h = int(parts[0])
        m = int(parts[1]) if len(parts) > 1 else 0
        if 0 <= h <= 23 and 0 <= m <= 59:
            return h, m
    except (ValueError, IndexError):
        pass
    log(f"[SCHED] Kunne ikke parse tid: {value!r}")
    return None


def _now_dk() -> datetime.datetime:
    return datetime.datetime.now(DK_TZ)


def determine_expected_state(marked_days: Dict[str, Dict[str, Any]], now_dk: datetime.datetime) -> str:
    """
    Returner "on" eller "off" baseret på dagens kalender og aktuelle tid (dansk).
    """
    date_key = now_dk.strftime("%Y-%m-%d")
    day = marked_days.get(date_key)
    if not day or not isinstance(day, dict):
        return "off"
    if str(day.get("status", "off")).lower() != "on":
        return "off"

    on_t = _parse_hhmm(day.get("onTime"))
    off_t = _parse_hhmm(day.get("offTime"))
    if not on_t or not off_t:
        log(f"[SCHED] Dag {date_key} markeret 'on' men onTime/offTime ugyldige: on={day.get('onTime')!r}, off={day.get('offTime')!r}")
        return "off"

    on_dt = now_dk.replace(hour=on_t[0], minute=on_t[1], second=0, microsecond=0)
    off_dt = now_dk.replace(hour=off_t[0], minute=off_t[1], second=0, microsecond=0)

    if off_dt <= on_dt:
        return "off"

    if on_dt <= now_dk < off_dt:
        return "on"
    return "off"


def _read_scheduler_state() -> Dict[str, Any]:
    try:
        p = Path(SCHEDULER_STATE_PATH)
        if p.exists():
            data = json.loads(p.read_text(encoding="utf-8"))
            if isinstance(data, dict):
                return data
    except Exception as e:
        log(f"[SCHED] Fejl ved læs af state: {e}")
    return {"last_applied_state": None, "last_applied_at": None, "last_wake_reboot_ts": 0}


def _write_scheduler_state(state: Dict[str, Any]) -> None:
    atomic_write(SCHEDULER_STATE_PATH, state)


def _run_kiosk_script(script_path: str, name: str, log_path: str, trigger: str = "calendar", timeout: int = 90) -> bool:
    if not Path(script_path).exists():
        log(f"[SCHED] FEJL: script ikke fundet: {script_path}")
        return False
    log(f"[SCHED] Kører {name} (trigger={trigger})")
    try:
        env = {**os.environ, "KIOSK_TRIGGER": trigger}
        env.setdefault("DISPLAY", os.environ.get("DISPLAY", ":0"))
        env.setdefault("XAUTHORITY", os.environ.get("XAUTHORITY", "/run/user/1000/gdm/Xauthority"))
        with open(log_path, "a", encoding="utf-8") as logf:
            logf.write(f"\n--- {_utc_now_iso()} | started by clientflow_calendar (trigger={trigger}) ---\n")
            logf.flush()
            proc = subprocess.Popen(
                [PYTHON_BIN, script_path],
                cwd=str(API_DIR),
                stdout=logf, stderr=logf,
                env=env,
            )
            try:
                rc = proc.wait(timeout=timeout)
            except subprocess.TimeoutExpired:
                log(f"[SCHED] {name} timeout efter {timeout}s, terminerer.")
                try:
                    proc.terminate()
                    proc.wait(timeout=5)
                except Exception:
                    try:
                        proc.kill()
                    except Exception:
                        pass
                rc = -1
        log(f"[SCHED] {name} afsluttet med rc={rc}")
        return rc == 0
    except Exception as e:
        log(f"[SCHED] FEJL ved {name}: {e}")
        return False


def _trigger_reboot_after_wake() -> None:
    log(f"[SCHED] Venter {WAKE_REBOOT_DELAY}s før reboot efter calendar wake.")
    time.sleep(WAKE_REBOOT_DELAY)
    log("[SCHED] Forsøger reboot via systemctl/sudo (calendar wake).")
    for cmd in ("sudo /sbin/reboot", "sudo reboot", "sudo systemctl reboot"):
        try:
            os.system(cmd)
        except Exception as e:
            log(f"[SCHED] Reboot-kommando '{cmd}' fejlede: {e}")
        time.sleep(3)


def calendar_scheduler_loop(get_marked_days_fn) -> None:
    """
    Baggrundstråd der hvert SCHEDULER_TICK_SECONDS bestemmer current expected state
    og udfører wake/sleep-handlinger ved transitions.
    """
    log("[SCHED] Calendar scheduler tråd startet.")
    state = _read_scheduler_state()

    # VIGTIGT: Vi nulstiller IKKE last_applied_state ved opstart.
    # Den gamle "startup reset" var årsagen til at kiosk_wake/kiosk_sleep blev
    # kørt unødvendigt ved hver genstart — hvilket dræbte Chrome der netop var
    # startet af clientflow_service.py.
    # clientflow_service.py håndterer selv Chrome-start ved opstart (via status=="approved").
    # Vi husker i stedet tilstanden på tværs af reboots via scheduler_state.json.
    log(f"[SCHED] Indlæst state: last_applied_state='{state.get('last_applied_state')}' (bevares på tværs af reboots).")

    # Boot grace period: Vent BOOT_GRACE_SECONDS inden vi udfører nogen handlinger.
    # Dette giver clientflow_service.py tid til at starte Chrome og sætte sig selv op,
    # inden kalenderen potentielt griber ind.
    boot_time = time.time()
    log(f"[SCHED] Boot grace period på {BOOT_GRACE_SECONDS}s startet — ingen kalenderhandlinger i denne periode.")

    while True:
        try:
            if SCHEDULER_DISABLED_FLAG.exists():
                log("[SCHED] .calendar_scheduler_disabled findes — scheduler venter.")
                time.sleep(SCHEDULER_TICK_SECONDS)
                continue

            # Boot grace period check
            elapsed_since_boot = time.time() - boot_time
            if elapsed_since_boot < BOOT_GRACE_SECONDS:
                remaining = BOOT_GRACE_SECONDS - elapsed_since_boot
                log(f"[SCHED] Boot grace period aktiv: {remaining:.0f}s tilbage — venter.")
                time.sleep(min(SCHEDULER_TICK_SECONDS, remaining + 1))
                continue

            marked_days = get_marked_days_fn() or {}

            # Spring over hvis marked_days er tom — backend har endnu ikke svaret
            # (Render free tier sover). Uden dette vil en tom cache give
            # expected="off" og maskinen sættes i dvale ved boot.
            if not marked_days:
                log("[SCHED] marked_days er tom — venter på data fra backend før scheduler kører.")
                time.sleep(SCHEDULER_TICK_SECONDS)
                continue

            now_dk = _now_dk()
            expected = determine_expected_state(marked_days, now_dk)
            last_applied = state.get("last_applied_state")

            if expected != last_applied:
                log(f"[SCHED] Transition opdaget: {last_applied} -> {expected} (dansk tid {now_dk.strftime('%Y-%m-%d %H:%M:%S')})")

                if expected == "on":
                    ok = _run_kiosk_script(KIOSK_WAKE_SCRIPT, "kiosk_wake", KIOSK_WAKE_LOG, trigger="calendar", timeout=60)
                    state["last_applied_state"] = "on"
                    state["last_applied_at"] = _utc_now_iso()

                    now_ts = time.time()
                    last_reboot_ts = float(state.get("last_wake_reboot_ts", 0) or 0)
                    if now_ts - last_reboot_ts < WAKE_REBOOT_COOLDOWN:
                        log(f"[SCHED] Springer reboot over (cooldown: {now_ts - last_reboot_ts:.0f}s < {WAKE_REBOOT_COOLDOWN}s).")
                        _write_scheduler_state(state)
                    else:
                        state["last_wake_reboot_ts"] = now_ts
                        _write_scheduler_state(state)
                        if ok:
                            threading.Thread(target=_trigger_reboot_after_wake, daemon=False).start()
                        else:
                            log("[SCHED] kiosk_wake returnerede fejl — springer reboot over.")

                else:  # expected == "off"
                    _run_kiosk_script(KIOSK_SLEEP_SCRIPT, "kiosk_sleep", KIOSK_SLEEP_LOG, trigger="calendar", timeout=60)
                    state["last_applied_state"] = "off"
                    state["last_applied_at"] = _utc_now_iso()
                    _write_scheduler_state(state)
            else:
                pass  # ingen transition

        except Exception as e:
            log(f"[SCHED] Uventet fejl i scheduler-loop: {e}")

        time.sleep(SCHEDULER_TICK_SECONDS)


# ---------------------------------------------------------------------------
# Main poll-loop
# ---------------------------------------------------------------------------
class MarkedDaysCache:
    """Tråd-sikker cache af seneste markedDays."""

    def __init__(self):
        self._lock = threading.Lock()
        self._data: Dict[str, Dict[str, Any]] = {}
        self._last_update: Optional[float] = None

    def set(self, data: Dict[str, Dict[str, Any]]) -> None:
        with self._lock:
            self._data = dict(data) if data else {}
            self._last_update = time.time()

    def get(self) -> Dict[str, Dict[str, Any]]:
        with self._lock:
            return dict(self._data)


def main():
    cache = MarkedDaysCache()

    # Start scheduler tråd
    threading.Thread(
        target=calendar_scheduler_loop,
        args=(cache.get,),
        daemon=True,
        name="calendar_scheduler",
    ).start()

    token: Optional[str] = None
    last_token_time: float = 0
    token_ttl = 60 * 30  # 30 min

    while True:
        log("[DEBUG] Starter poll-loop iteration")

        # Token refresh
        if token is None or (time.time() - last_token_time) > token_ttl:
            token = get_token()
            last_token_time = time.time() if token else 0
            if token is None:
                log("[ERROR] Kunne ikke hente token. Venter 30s.")
                time.sleep(30)
                continue

        # Læs config
        try:
            cfg = read_config() or {}
            client_id = get_client_id() if callable(get_client_id) else cfg.get("id")
            status = get_status() if callable(get_status) else cfg.get("status")
            log(f"[DEBUG] client_id={client_id} status={status}")
        except Exception as e:
            log(f"[ERROR] Fejl ved læsning af config/status: {e}")
            client_id = None
            status = None

        if client_id is None or str(status).lower() != "approved":
            log("[DEBUG] Ikke godkendt eller mangler client_id - springer over.")
            time.sleep(POLL_INTERVAL)
            continue

        season = hent_season(token)
        if not season:
            log("[DEBUG] Ingen season - nulstiller token og prøver senere.")
            token = None
            time.sleep(POLL_INTERVAL)
            continue

        marked_days = hent_markeringer(client_id, season, token)
        cache.set(marked_days)

        now_dk = _now_dk()
        skriv_gui_json(marked_days, now_dk)

        time.sleep(POLL_INTERVAL)


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        log("clientflow_calendar stoppet af bruger.")
