#!/usr/bin/env python3
"""
clientflow_gui.py

GUI til ClientFlow status og kontrol.

FIX: Lokal fallback STATUS_MAP og format_message er fjernet.
     Importeres nu udelukkende fra status_map.py (single source of truth).
"""
from pathlib import Path
import tkinter as tk
from tkinter import ttk
import json
import os
import subprocess
from datetime import datetime, timedelta
import locale
import re
from typing import Any, Tuple, Dict

# BASE_DIR = mappen hvor dette script ligger
BASE_DIR = Path(__file__).resolve().parent
API_DIR = BASE_DIR
API_DIR.mkdir(parents=True, exist_ok=True)

# Stier relative til API_DIR
CONFIG_PATH = str(API_DIR / "clientflow_config.json")
CHROME_STATUS_PATH = str(API_DIR / "chrome_status.json")
CALENDAR_PATH = str(API_DIR / "calendar_gui.json")
GUI_EVENT_PATH = str(API_DIR / "gui_event.json")

# UI-konstanter
COLOR_GREEN = "#218739"
COLOR_RED = "#cc3333"
COLOR_ORANGE = "#ffa500"
COLOR_GRAY = "#888888"
COLOR_BG = "#f4f6fa"
COLOR_BLUE = "#1E88E5"
BIG_FONT = ("Arial", 13)
LABEL_FONT = ("Arial", 12, "normal")
VALUE_FONT = ("Arial", 12, "normal")
HEADING_FONT = ("Arial", 14, "bold")
SECTION_PAD = {"padx": 10, "pady": 6}
SECTION_PAD_KALENDER = {"padx": 10, "pady": 4}

try:
    locale.setlocale(locale.LC_TIME, "da_DK.UTF-8")
except Exception:
    pass

# ---------------------------------------------------------------------------
# FIX: Importér fra status_map.py — single source of truth.
# Den lokale fallback-kopi af STATUS_MAP og format_message er fjernet.
# ---------------------------------------------------------------------------
try:
    from status_map import format_message, STATUS_MAP  # type: ignore
except ImportError as e:
    raise RuntimeError(
        f"clientflow_gui.py kræver status_map.py i samme mappe ({API_DIR}): {e}"
    )

# Ensure files exist with sane defaults
def ensure_files():
    try:
        API_DIR.mkdir(parents=True, exist_ok=True)
        p = Path(CONFIG_PATH)
        if not p.exists():
            p.write_text(json.dumps({}, ensure_ascii=False, indent=2), encoding="utf-8")
        s = Path(CHROME_STATUS_PATH)
        if not s.exists():
            s.write_text(json.dumps({"steps": [], "chrome_running": False}, ensure_ascii=False, indent=2), encoding="utf-8")
        c = Path(CALENDAR_PATH)
        if not c.exists():
            c.write_text("[]", encoding="utf-8")
        g = Path(GUI_EVENT_PATH)
        if not g.exists():
            g.write_text("{}", encoding="utf-8")
    except Exception:
        pass

ensure_files()

# --- Utility functions ---
def read_json(path):
    try:
        if os.path.exists(path):
            with open(path, "r", encoding="utf-8") as f:
                return json.load(f)
    except Exception:
        pass
    return {}

def atomic_write(path, obj):
    try:
        p = Path(path)
        p.parent.mkdir(parents=True, exist_ok=True)
        import uuid as _uuid
        tmp = p.with_name(f"{p.name}.tmp.{os.getpid()}.{_uuid.uuid4().hex[:8]}")
        tmp.write_text(json.dumps(obj, ensure_ascii=False, indent=2), encoding="utf-8")
        tmp.replace(p)
    except Exception:
        try:
            with open(path, "w", encoding="utf-8") as f:
                json.dump(obj, f, ensure_ascii=False, indent=2)
        except Exception:
            pass

def format_uptime(seconds):
    try:
        s = int(float(seconds))
        h = s // 3600
        m = (s % 3600) // 60
        s = s % 60
        return f"{h}:{m:02d}:{s:02d}"
    except Exception:
        return "-"

def format_calendar_date(date_str):
    try:
        dt = datetime.strptime(date_str[:10], "%Y-%m-%d")
        dk_weekdays = ["Mandag", "Tirsdag", "Onsdag", "Torsdag", "Fredag", "Lørdag", "Søndag"]
        weekday = dt.strftime("%A")
        if weekday not in dk_weekdays:
            weekday = dk_weekdays[dt.weekday()]
        return f"{weekday} d. {dt.strftime('%d.%m %Y')}"
    except Exception:
        return date_str

def get_systemd_status(service):
    try:
        result = subprocess.run(
            ["systemctl", "is-active", service],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            timeout=2
        )
        status = result.stdout.strip()
        if status == "active":
            return ("Kører", COLOR_GREEN)
        elif status == "inactive":
            return ("Stop", COLOR_RED)
        else:
            return (status, COLOR_ORANGE)
    except Exception:
        return ("Ukendt", "black")

def get_livestream_process_status():
    """
    Livestream styres ikke længere af livestream.service.
    Den startes/stoppes af clientflow_service.py via backend-action
    livestream_start/livestream_stop.

    Derfor viser GUI'en her den faktiske processtatus i stedet for en
    forældet systemd-service:
      - Aktiv: livestream.py eller ffmpeg-segmentering kører
      - Stoppet: ingen livestream-processer
    """
    try:
        result = subprocess.run(
            ["pgrep", "-af", "livestream.py|ffmpeg .*segment_"],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            timeout=2,
        )
        output = (result.stdout or "").strip()
        if output:
            return ("Aktiv", COLOR_GREEN)
        return ("Stoppet", COLOR_GRAY)
    except Exception:
        return ("Ukendt", COLOR_ORANGE)


def get_active_network_info(config: Dict[str, Any]) -> Dict[str, str]:
    """Find aktiv forbindelse via default route og returnér bruger-venlige felter.

    Fallback bruger LAN/WiFi-værdier fra backend-config, hvis ip-kommandoen
    ikke kan bruges endnu under opstart.
    """
    def clean(value: Any) -> str:
        value = str(value or "").strip()
        return value if value and value != "-" else "-"

    info = {
        "Aktiv forbindelse": "-",
        "Aktiv IP": "-",
        "Aktivt interface": "-",
        "Aktiv MAC": "-",
    }

    try:
        result = subprocess.run(
            ["ip", "route", "get", "1.1.1.1"],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            timeout=2,
        )
        line = (result.stdout or "").strip().splitlines()[0] if result.stdout else ""
        parts = line.split()
        iface = ""
        ip_addr = ""
        if "dev" in parts:
            iface = parts[parts.index("dev") + 1]
        if "src" in parts:
            ip_addr = parts[parts.index("src") + 1]

        if iface:
            if iface.startswith("wl"):
                kind = "WiFi"
            elif iface.startswith(("en", "eth")):
                kind = "LAN"
            else:
                kind = iface
            info["Aktiv forbindelse"] = kind
            info["Aktivt interface"] = iface
            if ip_addr:
                info["Aktiv IP"] = ip_addr
            try:
                mac = Path(f"/sys/class/net/{iface}/address").read_text(encoding="utf-8").strip()
                if mac:
                    info["Aktiv MAC"] = mac
            except Exception:
                pass
    except Exception:
        pass

    # Fallback, hvis default route ikke gav noget brugbart.
    if info["Aktiv IP"] == "-":
        lan_ip = clean(config.get("lan_ip_address"))
        wifi_ip = clean(config.get("wifi_ip_address"))
        if lan_ip != "-":
            info["Aktiv forbindelse"] = "LAN"
            info["Aktiv IP"] = lan_ip
            info["Aktiv MAC"] = clean(config.get("lan_mac_address"))
        elif wifi_ip != "-":
            info["Aktiv forbindelse"] = "WiFi"
            info["Aktiv IP"] = wifi_ip
            info["Aktiv MAC"] = clean(config.get("wifi_mac_address"))

    return info

# COLOR map for names returned from status_map
COLOR_MAP = {
    "green": COLOR_GREEN,
    "red": COLOR_RED,
    "orange": COLOR_ORANGE,
    "black": "black",
    "blue": COLOR_BLUE,
}

OS_UPDATE_STEPS = {
    "os_update_started",
    "os_update_fetching",
    "os_upgrading",
    "os_cleanup",
    "os_update_complete",
    "os_update_failed",
    "os_update_none",
}

# Lokal GUI har kun Start/Stop kiosk browser.
# Knapperne skal være konservative, fordi GUI'en kan åbnes på en offentlig skærm.
GUI_BUSY_STEPS = {
    "clear_cookies",
    "terminate_chrome",
    "kill_chrome",
    "countdown",
    "system_reboot_countdown",
}

GUI_SYSTEM_LOCK_STEPS = {
    "system_rebooting",
    "system_shutting_down",
    "system_wake",
}

def _is_os_update_step(step_obj) -> bool:
    """
    Ubuntu/OS-update steps skrives til chrome_status.json, så backend og logs
    kan se dem. De må bare ikke vises i feltet "Kiosk browser status" i GUI'en.
    """
    if not isinstance(step_obj, dict):
        return False

    step = str(step_obj.get("step", "")).strip().lower()
    status = str(step_obj.get("status", "")).strip().lower()
    message = str(step_obj.get("message", "")).strip().lower()

    return (
        step in OS_UPDATE_STEPS
        or status in OS_UPDATE_STEPS
        or step.startswith("os_update")
        or status.startswith("os_update")
        or message.startswith("ubuntu:")
        or "ubuntu-opdatering" in message
        or "ingen opdateringer" in message
        or "installerer opdateringer" in message
        or "henter pakkeliste" in message
        or "rydder op efter opdatering" in message
    )

def _latest_browser_relevant_step(steps):
    """
    Find seneste step, som faktisk handler om kiosk/browser/status.
    OS-update steps springes over, så de ikke overtager browserstatusfeltet.
    """
    for step_obj in reversed(steps or []):
        if not _is_os_update_step(step_obj):
            return step_obj
    return None


CHROME_RUNNING_STEPS = {
    "start_chrome",
    "chrome_opened_manual",
}

CHROME_STOPPED_STEPS = {
    "chrome_closed_programmatically",
    "chrome_closed_manual",
    "shutdown_chrome",
    "kill_chrome",
    "system_sleep",
    "system_sleep_complete",
    "system_rebooting",
    "system_shutting_down",
}


def _bool_or_none(value):
    """
    chrome_status.json kan i praksis indeholde bool, tal eller tekst.
    Returnér True/False hvis værdien kan tolkes sikkert, ellers None.
    """
    if isinstance(value, bool):
        return value

    if value is None:
        return None

    if isinstance(value, (int, float)):
        return bool(value)

    s = str(value).strip().lower()
    if s in {"true", "1", "yes", "y", "on", "running", "kører", "koerer"}:
        return True
    if s in {"false", "0", "no", "n", "off", "stopped", "stop", "stoppet"}:
        return False

    return None


def infer_chrome_running(chrome_data, steps):
    """
    Robust afgørelse af om kiosk browseren kører.

    Tidligere brugte GUI'en kun chrome_data["chrome_running"].
    Hvis det felt manglede, var stale, eller blev skrevet som tekst, kunne
    "Start kiosk browser" være aktiv, selvom browseren faktisk var åben.

    Prioritet:
      1. Entydigt seneste browser-step, fx start_chrome/chrome_opened_manual.
      2. Entydigt chrome_running-felt.
      3. Fallback: False.
    """
    latest = _latest_browser_relevant_step(steps)
    if latest:
        step_name = str(latest.get("step", "")).strip().lower()
        if step_name in CHROME_RUNNING_STEPS:
            return True
        if step_name in CHROME_STOPPED_STEPS:
            return False

    parsed = _bool_or_none(chrome_data.get("chrome_running", None))
    if parsed is not None:
        return parsed

    return False

def browser_status_human(steps, chrome_running=False):
    """
    Returnerer human-readable browserstatus og farve for GUI.

    Vigtigt:
    chrome_status.json bruges også til Ubuntu/OS-update steps. De skal sendes
    til backend/log, men feltet "Kiosk browser status" i klient-GUI'en skal kun
    vise browser/kiosk-relevante beskeder.
    """
    if not steps:
        return "Ingen status.", "black"

    last = _latest_browser_relevant_step(steps)
    if not last:
        return "Ingen aktiv browserstatus.", COLOR_GRAY

    step = last.get("step", "")
    trigger = str(last.get("trigger", "")).lower()

    try:
        if step in ("countdown", "system_reboot_countdown"):
            extra = last.get("extra", None)
            if extra is None:
                msg_text = last.get("message", "")
                m = re.search(r"om (\d+)", msg_text)
                extra = int(m.group(1)) if m else 0
            msg, color_name = format_message(step, trigger, X=extra)
        else:
            detail = last.get("detail", last.get("message", ""))
            msg, color_name = format_message(step, trigger, detail=detail)
    except Exception:
        msg = last.get("message", "Ingen status.")
        color_name = "black"

    resolved = "black"
    try:
        if isinstance(color_name, str) and color_name.startswith("#"):
            resolved = color_name
        elif isinstance(color_name, str) and color_name.lower() in COLOR_MAP:
            resolved = COLOR_MAP[color_name.lower()]
        elif isinstance(color_name, str):
            resolved = color_name
    except Exception:
        resolved = "black"

    return msg, resolved


def _is_client_sleeping(steps) -> bool:
    """
    Returnerer True hvis det seneste relevante strøm-step er system_sleep.
    system_wake, start_chrome og chrome_opened_manual ophæver dvale-tilstand.
    """
    WAKE_STEPS = {"system_wake", "start_chrome", "chrome_opened_manual", "system_wake_complete"}
    SLEEP_STEPS = {"system_sleep", "system_sleep_complete"}
    for s in reversed(steps):
        step_name = s.get("step", "")
        if step_name in SLEEP_STEPS:
            return True
        if step_name in WAKE_STEPS:
            return False
    return False


def set_label_value(label_widget, value, copy_lbl=None, ok_lbl=None, root=None):
    if not value or value in ["-", "None", None, "", "Ikke tilgængelig"]:
        label_widget.config(text="Ikke tilgængelig", foreground=COLOR_GRAY)
        if copy_lbl:
            copy_lbl.grid_remove()
        if ok_lbl:
            ok_lbl.config(text="")
    else:
        label_widget.config(text=value, foreground="black")
        if copy_lbl:
            copy_lbl.grid()
        if ok_lbl:
            ok_lbl.grid()
            ok_lbl.config(text="")
        if copy_lbl and root:
            try:
                copy_lbl.unbind("<Button-1>")
            except Exception:
                pass
            def on_copy(event):
                try:
                    root.clipboard_clear()
                    root.clipboard_append(str(value))
                    root.update()
                    if ok_lbl:
                        ok_lbl.config(text="Kopieret!", fg=COLOR_GREEN)
                        root.after(1500, lambda: ok_lbl.config(text=""))
                except Exception:
                    pass
            copy_lbl.bind("<Button-1>", on_copy)

# --- GUI Klasse ---
class ClientFlowStatusGUI(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("ClientFlow Status")
        self.configure(bg=COLOR_BG)
        self._set_initial_window_size()
        self.setup_styles()
        self.create_scroll_container()
        self.create_sections()
        self.after(50, self._fit_window_to_content)
        self.protocol("WM_DELETE_WINDOW", self.on_close)
        self.startup_disable_until = datetime.now() + timedelta(seconds=10)
        self.after(500, self.auto_update)





    def _set_initial_window_size(self):
        # Start kompakt. _fit_window_to_content sætter endelig størrelse.
        try:
            self.geometry("10x10+20+20")
            self.minsize(1, 1)
            self.resizable(False, False)
        except Exception:
            pass

    def _fit_window_to_content(self):
        # Tilpas GUI-vinduet til faktisk indhold og undgå scrollbars.
        try:
            self.update_idletasks()

            req_w = max(760, self.content_frame.winfo_reqwidth() + 28)
            req_h = max(1, self.content_frame.winfo_reqheight() + 28)

            screen_w = self.winfo_screenwidth()
            screen_h = self.winfo_screenheight()

            max_w = max(760, screen_w - 60)
            max_h = max(600, screen_h - 90)

            width = min(req_w, max_w)
            height = min(req_h, max_h)

            x = 20
            y = 20

            target_geometry = f"{int(width)}x{int(height)}+{x}+{y}"
            if self.geometry() != target_geometry:
                self.geometry(target_geometry)

            self.resizable(False, False)
        except Exception:
            pass

        try:
            self.after(1500, self._fit_window_to_content)
        except Exception:
            pass

    def create_scroll_container(self):
        # No-scroll variant: content_frame pakkes direkte i root-vinduet.
        self.content_frame = tk.Frame(self, bg=COLOR_BG)
        self.content_frame.pack(fill="both", expand=False)
    def setup_styles(self):
        style = ttk.Style()
        style.configure("Red.TButton", background=COLOR_RED, foreground="white", font=BIG_FONT)
        style.configure("Green.TButton", background="#4BB543", foreground="white", font=BIG_FONT)
        style.configure("Blue.TButton", font=BIG_FONT)
        style.configure("Treeview.Heading", font=VALUE_FONT)
        style.configure("Treeview", rowheight=24, font=VALUE_FONT)
        style.configure("TLabel", background=COLOR_BG)
        style.configure("TLabelframe", background=COLOR_BG, borderwidth=1, relief="solid")
        style.configure("TLabelframe.Label", font=HEADING_FONT, background=COLOR_BG)

    def create_sections(self):
        self.create_actions_section()
        self.create_systeminfo_section()
        self.create_kioskinfo_section()
        self.create_networkinfo_section()
        self.create_calendar_section()
        self.create_error_label()

    def create_actions_section(self):
        actions_frame = ttk.LabelFrame(self.content_frame, text="Handlinger")
        actions_frame.pack(fill="x", padx=14, pady=(12, 6))
        actions_frame.columnconfigure((0, 1), weight=1)

        # Logvisning er bevidst fjernet fra den lokale GUI.
        # GUI'en kan åbnes på en offentlig infoskærm, og logs kan indeholde
        # backend-URL'er, brugernavne, tokens, interne stier og fejlbeskeder.
        # Brug i stedet superadmin Remote Terminal i webfrontenden til support.
        self.open_btn = ttk.Button(
            actions_frame,
            text="Start kiosk browser",
            command=self.on_open_browser,
            style="Green.TButton",
        )
        self.open_btn.grid(row=0, column=0, padx=10, pady=10, sticky="ew")

        self.close_btn = ttk.Button(
            actions_frame,
            text="Stop kiosk browser",
            command=self.on_close_browser,
            style="Red.TButton",
        )
        self.close_btn.grid(row=0, column=1, padx=10, pady=10, sticky="ew")

    def create_systeminfo_section(self):
        sys_card = ttk.LabelFrame(self.content_frame, text="Systeminfo")
        sys_card.pack(fill="x", **SECTION_PAD)
        sys_card.grid_columnconfigure(99, weight=1)
        self.sys_labels = {}
        self.sys_fields = [
            ("Klient ID", "id"),
            ("Lokation", "locality"),
            ("Backend-status", "status"),
            ("Systemd kalender service", "clientflow_calendar.service"),
            ("Systemd backend sync", "clientflow_service.service"),
            ("Systemd remote terminal", "client_terminal_agent.service"),
            ("Systemd remote desktop", "client_remote_desktop_agent.service"),
            ("Systemd kiosk guard", "clientflow_kiosk_x11_guard.service"),
            ("Livestream", "livestream_process"),
            ("Oppetid", "uptime"),
        ]
        for i, (label, key) in enumerate(self.sys_fields):
            l = ttk.Label(sys_card, text=f"{label}:", font=LABEL_FONT)
            l.grid(row=i, column=0, sticky="w", padx=8, pady=4)
            val = ttk.Label(sys_card, text="", font=VALUE_FONT)
            val.grid(row=i, column=1, sticky="w", padx=8, pady=4)
            self.sys_labels[label] = val

    def create_kioskinfo_section(self):
        kiosk_card = ttk.LabelFrame(self.content_frame, text="Kioskinfo")
        kiosk_card.pack(fill="x", **SECTION_PAD)
        kiosk_card.grid_columnconfigure(99, weight=1)
        ttk.Label(kiosk_card, text="Kiosk URL:", font=LABEL_FONT).grid(row=0, column=0, sticky="w", padx=8, pady=4)
        self.kiosk_url_label = ttk.Label(kiosk_card, text="", font=VALUE_FONT, wraplength=620, justify="left")
        self.kiosk_url_label.grid(row=0, column=1, sticky="w", padx=8, pady=4)
        self.kopi_kiosk_label = tk.Label(kiosk_card, text="", font=("Arial", 11), fg=COLOR_GREEN, bg=COLOR_BG)
        self.kopi_kiosk_label.grid(row=0, column=98, sticky="e", padx=(0,2), pady=4)
        self.kiosk_url_copy_lbl = tk.Label(kiosk_card, text="⧉", font=("Arial", 11), bg=COLOR_BG, cursor="hand2")
        self.kiosk_url_copy_lbl.grid(row=0, column=99, sticky="e", padx=(0, 14), pady=4)
        ttk.Label(kiosk_card, text="Kiosk browser status:", font=LABEL_FONT).grid(row=1, column=0, sticky="w", padx=8, pady=4)
        self.kiosk_status_label = ttk.Label(kiosk_card, text="", font=VALUE_FONT, justify="left", wraplength=620)
        self.kiosk_status_label.grid(row=1, column=1, sticky="nw", padx=8, pady=4)
        self.sleep_indicator_label = ttk.Label(kiosk_card, text="", font=("Arial", 11, "italic"), foreground=COLOR_BLUE)
        self.sleep_indicator_label.grid(row=2, column=0, columnspan=3, sticky="w", padx=8, pady=(0, 4))

        ttk.Label(kiosk_card, text="Status:", font=LABEL_FONT).grid(row=3, column=0, sticky="nw", padx=8, pady=4)
        self.operational_status_label = ttk.Label(kiosk_card, text="", font=VALUE_FONT, justify="left", wraplength=620)
        self.operational_status_label.grid(row=3, column=1, sticky="nw", padx=8, pady=4)

    def create_networkinfo_section(self):
        net_card = ttk.LabelFrame(self.content_frame, text="Netværksinfo")
        net_card.pack(fill="x", **SECTION_PAD)
        net_card.grid_columnconfigure(99, weight=1)
        net_labels = [
            "Aktiv forbindelse",
            "Aktiv IP",
            "Aktivt interface",
            "Aktiv MAC",
            "WiFi IP",
            "WiFi MAC",
            "LAN IP",
            "LAN MAC",
        ]
        self.net_labels = {}
        self.net_copy_lbls = {}
        self.net_ok_lbls = {}
        for i, label in enumerate(net_labels):
            l = ttk.Label(net_card, text=f"{label}:", font=LABEL_FONT)
            l.grid(row=i, column=0, sticky="w", padx=8, pady=4)
            val = ttk.Label(net_card, text="", font=VALUE_FONT)
            val.grid(row=i, column=1, sticky="w", padx=8, pady=4)
            ok_lbl = tk.Label(net_card, text="", font=("Arial", 11), fg=COLOR_GREEN, bg=COLOR_BG)
            ok_lbl.grid(row=i, column=98, sticky="e", padx=(0,2), pady=4)
            copy_lbl = tk.Label(net_card, text="⧉", font=("Arial", 11), bg=COLOR_BG, cursor="hand2")
            copy_lbl.grid(row=i, column=99, sticky="e", padx=(0, 14), pady=4)
            self.net_labels[label] = val
            self.net_copy_lbls[label] = copy_lbl
            self.net_ok_lbls[label] = ok_lbl

    def create_calendar_section(self):
        cal_frame = ttk.LabelFrame(self.content_frame, text="Kalender")
        cal_frame.pack(fill="x", expand=False, **SECTION_PAD_KALENDER)
        self.cal_tree = ttk.Treeview(cal_frame, columns=("date", "status", "open", "close"), show="headings", height=5)
        for col, txt, width in [
            ("date", "Dato", 160), ("status", "Status", 100), ("open", "Åbner", 100), ("close", "Lukker", 100)
        ]:
            self.cal_tree.heading(col, text=txt)
            self.cal_tree.column(col, width=width, anchor="center")
        self.cal_tree.pack(fill="x", expand=False, pady=8)

    def create_error_label(self):
        self.error_label = ttk.Label(self.content_frame, text="", foreground="red", font=("Arial", 11), anchor="w")
        self.error_label.pack(fill="x", side="bottom", pady=(0, 5), padx=12)

    # --- Button handlers ---

    def _write_gui_event(self, event_obj):
        try:
            import uuid as _uuid
            p = Path(GUI_EVENT_PATH)
            p.parent.mkdir(parents=True, exist_ok=True)
            tmp = p.with_name(f"{p.name}.tmp.{os.getpid()}.{_uuid.uuid4().hex[:8]}")
            tmp.write_text(json.dumps(event_obj, ensure_ascii=False, indent=2), encoding="utf-8")
            tmp.replace(p)
        except Exception:
            try:
                with open(GUI_EVENT_PATH, "w", encoding="utf-8") as f:
                    json.dump(event_obj, f, ensure_ascii=False, indent=2)
            except Exception:
                pass

    def on_open_browser(self):
        # Ingen lokal notify-send: GUI'en kan åbnes på en offentlig infoskærm.
        event = {
            "action": "open",
            "url": self.kiosk_url_label.cget("text"),
            "timestamp": datetime.now().isoformat(),
            "trigger": "gui"
        }
        self._write_gui_event(event)

    def on_close_browser(self):
        # Ingen lokal notify-send: GUI'en kan åbnes på en offentlig infoskærm.
        event = {
            "action": "close",
            "url": self.kiosk_url_label.cget("text"),
            "timestamp": datetime.now().isoformat(),
            "trigger": "gui"
        }
        self._write_gui_event(event)

    def on_close(self):
        self.destroy()

    # --- Auto update loop ---
    def auto_update(self):
        config = read_json(CONFIG_PATH)
        chrome_data = read_json(CHROME_STATUS_PATH)
        steps = chrome_data.get("steps", [])
        is_running = infer_chrome_running(chrome_data, steps)

        # Systeminfo
        backend_status_low = ""
        for label, key in self.sys_fields:
            if key == "status":
                raw_status = config.get(key, "")
                status_val = str(raw_status or "").strip()
                if not status_val:
                    # Nye enrollment-klienter kan have client_id før første backend-poll.
                    # Vis derfor Pending frem for tom/ukendt status, når klienten er registreret lokalt.
                    status_val = "pending" if (config.get("id") or config.get("client_id")) else "ikke registreret"
                sv_low = status_val.lower()
                if sv_low == "approved":
                    fg = COLOR_GREEN
                    display_text = "Approved / Godkendt"
                elif sv_low == "pending":
                    fg = COLOR_ORANGE
                    display_text = "Pending / Venter på godkendelse"
                elif sv_low in ("not approved", "off", "rejected", "revoked", "ikke registreret"):
                    fg = COLOR_RED
                    display_text = "Ikke registreret" if sv_low == "ikke registreret" else status_val.capitalize()
                else:
                    fg = COLOR_ORANGE
                    display_text = status_val.capitalize()
                backend_status_low = sv_low
                self.sys_labels[label].config(text=display_text, foreground=fg)
            elif key == "livestream_process":
                value, col = get_livestream_process_status()
                self.sys_labels[label].config(text=value, foreground=col)
            elif key.endswith(".service"):
                value, col = get_systemd_status(key)
                self.sys_labels[label].config(text=value, foreground=col)
            elif key == "uptime":
                value = format_uptime(config.get("uptime", "0"))
                self.sys_labels[label].config(text=value)
            elif key == "id":
                # Enrollment-klienter kan i korte perioder kun have client_id lokalt.
                value = config.get("id") or config.get("client_id") or "-"
                self.sys_labels[label].config(text=value)
            elif key == "locality":
                value = config.get("locality") or config.get("location") or config.get("note") or "-"
                self.sys_labels[label].config(text=value)
            else:
                value = config.get(key, "-")
                self.sys_labels[label].config(text=value)

        # Kioskinfo
        try:
            wrap_width = max(360, self.winfo_width() - 260)
            self.kiosk_url_label.config(wraplength=wrap_width)
            self.kiosk_status_label.config(wraplength=wrap_width)
        except Exception:
            pass

        self.kopi_kiosk_label.config(text="")
        set_label_value(self.kiosk_url_label, config.get("kiosk_url", "-"),
                        self.kiosk_url_copy_lbl, self.kopi_kiosk_label, self)

        status_txt, status_col = browser_status_human(steps, is_running)
        self.kiosk_status_label.config(text=status_txt, foreground=status_col, justify="left")

        # Beregn dvale-tilstand
        client_is_sleeping = _is_client_sleeping(steps)
        if client_is_sleeping:
            self.sleep_indicator_label.config(
                text="💤 Klienten er i dvale — brug backend eller kalender til at vække den",
                foreground=COLOR_BLUE
            )
        else:
            self.sleep_indicator_label.config(text="")

        # --- Knap-tilstand ---
        # Lokal offentlig GUI har kun to handlinger:
        #   Start kiosk browser
        #   Stop kiosk browser
        #
        # Logik:
        # - Begge knapper låses kort ved GUI-start, så statusfiler når at blive læst.
        # - Begge knapper låses under browser/system-busy steps.
        # - Begge knapper låses ved sleep/reboot/shutdown/wake.
        # - Start er kun aktiv, når Chrome ikke kører.
        # - Stop er kun aktiv, når Chrome kører.
        #
        # OS/Ubuntu-update steps springes over via _latest_browser_relevant_step(),
        # så Ubuntu-opdateringer ikke utilsigtet ændrer kioskknappernes tilstand.
        now = datetime.now()
        disable_open = False
        disable_close = False

        if now < self.startup_disable_until:
            disable_open = True
            disable_close = True

        latest_button_step = _latest_browser_relevant_step(steps)
        if latest_button_step:
            last_trigger = str(latest_button_step.get("trigger", "")).strip().lower()
            last_step_name = str(latest_button_step.get("step", "")).strip().lower()

            if (
                last_step_name in GUI_BUSY_STEPS
                or last_step_name in GUI_SYSTEM_LOCK_STEPS
                or last_trigger in ("pending_reboot", "pending_shutdown")
                or (
                    last_step_name in ("shutdown_chrome", "kill_chrome")
                    and last_trigger in ("pending_reboot", "pending_shutdown")
                )
            ):
                disable_open = True
                disable_close = True

        if client_is_sleeping:
            disable_open = True
            disable_close = True

        # Synkroniser med browserens køretilstand.
        # is_running er robust udledt fra både chrome_running og seneste status-step.
        # Hvis Chrome kører, skal Start ikke kunne trykkes.
        # Hvis Chrome ikke kører, skal Stop ikke kunne trykkes.
        if is_running:
            disable_open = True
        else:
            disable_close = True

        if disable_open:
            self.open_btn.state(["disabled"])
        else:
            self.open_btn.state(["!disabled"])

        if disable_close:
            self.close_btn.state(["disabled"])
        else:
            self.close_btn.state(["!disabled"])

        # Netværksinfo
        active_net = get_active_network_info(config)
        net_map = {
            "Aktiv forbindelse": active_net.get("Aktiv forbindelse", "-"),
            "Aktiv IP": active_net.get("Aktiv IP", "-"),
            "Aktivt interface": active_net.get("Aktivt interface", "-"),
            "Aktiv MAC": active_net.get("Aktiv MAC", "-"),
            "WiFi IP": config.get("wifi_ip_address", "-"),
            "WiFi MAC": config.get("wifi_mac_address", "-"),
            "LAN IP": config.get("lan_ip_address", "-"),
            "LAN MAC": config.get("lan_mac_address", "-")
        }
        for label, value in net_map.items():
            set_label_value(self.net_labels[label], value,
                            self.net_copy_lbls[label], self.net_ok_lbls[label], self)

        # Kalender
        self.cal_tree.delete(*self.cal_tree.get_children())
        marked_days = {}
        cal = read_json(CALENDAR_PATH)
        if isinstance(cal, list):
            for day in cal:
                marked_days[day.get("date", "")] = day
        else:
            marked_days = cal.get("markedDays", {}) if "markedDays" in cal else cal.get("days", {})
            if isinstance(marked_days, list):
                md = {}
                for d in marked_days:
                    md[d.get("date", "")] = d
                marked_days = md

        nu = datetime.now()

        today_str = nu.strftime("%Y-%m-%d")
        today_data = marked_days.get(today_str, {}) if isinstance(marked_days, dict) else {}
        today_calendar_status = str(today_data.get("status", "off") or "off").strip().lower()

        if backend_status_low == "pending":
            op_text = "Pending – venter på godkendelse i ClientFlow admin"
            op_color = COLOR_ORANGE
        elif backend_status_low == "approved":
            if client_is_sleeping:
                op_text = "Dvale – klient online, kiosk lukket og skærm slukket"
                op_color = COLOR_BLUE
            elif today_calendar_status == "on":
                if is_running:
                    op_text = "Approved – kalender On, kiosk aktiv"
                    op_color = COLOR_GREEN
                else:
                    op_text = "Approved – kalender On, kiosk starter/venter"
                    op_color = COLOR_ORANGE
            else:
                op_text = "Approved – kalender Off, klient online og venter på aktiv visningstid"
                op_color = COLOR_BLUE
        elif config.get("id") or config.get("client_id"):
            op_text = "Registreret lokalt – henter backend-status"
            op_color = COLOR_ORANGE
        else:
            op_text = "Ikke registreret – indtast installationskode"
            op_color = COLOR_RED

        # Status-feltet skal være én kort linje.
        # Kiosk browser status bevares uændret og håndteres separat ovenfor.
        try:
            self.operational_status_label.config(text=op_text, foreground=op_color, wraplength=0)
        except Exception:
            self.operational_status_label.config(text=op_text, foreground=op_color)

        for i in range(5):
            day_dt = nu + timedelta(days=i)
            date_str = day_dt.strftime("%Y-%m-%d")
            date_fmt = format_calendar_date(date_str)
            day = marked_days.get(date_str, {})
            status_label = day.get("status", "off")
            if status_label == "on":
                status_val = "On"
                status_fg = COLOR_GREEN
                open_val = day.get("onTime", "–")
                close_val = day.get("offTime", "–")
            else:
                status_val = "Off"
                status_fg = COLOR_RED
                open_val = ""
                close_val = ""
            item_id = self.cal_tree.insert("", "end", values=(date_fmt, status_val, open_val, close_val))
            self.cal_tree.tag_configure(f"row_{item_id}", foreground=status_fg)
            self.cal_tree.item(item_id, tags=(f"row_{item_id}",))

        self.error_label.config(text="")
        self.after(1000, self.auto_update)

if __name__ == "__main__":
    gui = ClientFlowStatusGUI()
    gui.mainloop()
