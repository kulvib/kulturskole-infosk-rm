#!/usr/bin/env python3
"""
clientflow_service.py

Hovedservice der styrer klientens flow:
 - Holder lokal config synkroniseret med backend (poll + heartbeat)
 - Håndterer pending_chrome_action fra backend (start/stop/sleep/wakeup/livestream/os_update)
 - Kører kiosk_wake.py / kiosk_sleep.py som subprocess (med KIOSK_TRIGGER env)
 - Efter wakeup: venter REBOOT_DELAY sekunder og genstarter maskinen
 - Starter og holder GUI'en kørende
 - Lytter på input-enheder for at vække klienten manuelt fra dvale

FIX: pending_chrome_action cleares i backend STRAKS ved modtagelse.
Frontend holder selv låsen via chrome-status polling (BUSY_CHROME_STEPS).
FIX: chrome_step sendes nu med i alle push-updates til backend så
/chrome-status GET kan returnere det korrekt uden at læse lokal fil.
FIX: system_sleep ryddes fra chrome_status.json ved opstart (Fix 1).
FIX: poll-loops ignorerer steps ældre end startup ved state-udledning (Fix 2+3).
FIX: gui_event.json nulstilles ved opstart — forhindrer forældede GUI-events
     fra tidligere sessioner i at forurene trigger-teksten (Fix 4).
FIX: event_writer_loop dræner duplikerede chrome-events fra køen så kun ét
     scenario køres ad gangen (Fix 5).
"""
from pathlib import Path
import os
import sys
import time
import json
import queue
import threading
import subprocess
import requests
import netifaces
import uuid
import datetime
import select
from shutil import which
from typing import Any, Dict, Optional, Tuple

try:
    import evdev  # type: ignore
except Exception:
    evdev = None

try:
    import chrome_kiosk  # type: ignore
    _HAS_CHROME_KIOSK = True
except Exception as _e:
    chrome_kiosk = None  # type: ignore
    _HAS_CHROME_KIOSK = False
    print(f"ADVARSEL: kunne ikke importere chrome_kiosk: {_e}", file=sys.stderr)


# ---------------------------------------------------------------------------
# Konfig
# ---------------------------------------------------------------------------
BASE_URL = os.environ.get("CLIENTFLOW_BASE_URL", "https://kulturskole-infosk-rm.onrender.com").rstrip("/")

# Ny auth-model for installerede Ubuntu-klienter:
#   CLIENTFLOW_CLIENT_ID + CLIENTFLOW_CLIENT_SECRET
# bruges til /auth/client-token og kræver ikke admin-password på klienten.
#
# Bagudkompatibilitet:
#   CLIENTFLOW_USERNAME + CLIENTFLOW_PASSWORD
# virker stadig for eksisterende klienter, indtil de migreres.
USERNAME = os.environ.get("CLIENTFLOW_USERNAME", os.environ.get("CF_USER", ""))
PASSWORD = os.environ.get("CLIENTFLOW_PASSWORD", os.environ.get("CF_PASS", ""))
CLIENT_ID_ENV = os.environ.get("CLIENTFLOW_CLIENT_ID", os.environ.get("CF_CLIENT_ID", "")).strip()
CLIENT_SECRET = os.environ.get("CLIENTFLOW_CLIENT_SECRET", os.environ.get("CF_CLIENT_SECRET", "")).strip()

BASE_DIR = Path(__file__).resolve().parent
API_DIR = Path(os.environ.get("CLIENTFLOW_API_DIR", str(BASE_DIR))).resolve()
API_DIR.mkdir(parents=True, exist_ok=True)

CONFIG_PATH = str(API_DIR / "clientflow_config.json")
LOG_PATH = str(API_DIR / "clientflow_service.log")
CHROME_STATUS_PATH = str(API_DIR / "chrome_status.json")
GUI_EVENT_PATH = str(API_DIR / "gui_event.json")
CALENDAR_GUI_PATH = str(API_DIR / "calendar_gui.json")

LIVESTREAM_SCRIPT_PATH = str(API_DIR / "livestream.py")
LIVESTREAM_STDOUT = str(API_DIR / "livestream_stdout.log")
LIVESTREAM_STDERR = str(API_DIR / "livestream_stderr.log")

KIOSK_WAKE_SCRIPT_PATH = str(API_DIR / "kiosk_wake.py")
KIOSK_WAKE_STDOUT = str(API_DIR / "kiosk_wake_stdout.log")
KIOSK_WAKE_STDERR = str(API_DIR / "kiosk_wake_stderr.log")

KIOSK_SLEEP_SCRIPT_PATH = str(API_DIR / "kiosk_sleep.py")
KIOSK_SLEEP_STDOUT = str(API_DIR / "kiosk_sleep_stdout.log")
KIOSK_SLEEP_STDERR = str(API_DIR / "kiosk_sleep_stderr.log")

OS_UPDATE_SCRIPT_PATH = str(API_DIR / "ubuntu_update.py")
OS_UPDATE_STDOUT = str(API_DIR / "ubuntu_update_service_stdout.log")
OS_UPDATE_STDERR = str(API_DIR / "ubuntu_update_service_stderr.log")

GUI_STDOUT = str(API_DIR / "clientflow_gui_stdout.log")
GUI_STDERR = str(API_DIR / "clientflow_gui_stderr.log")

CONFIG_UPDATE_INTERVAL = int(os.environ.get("CONFIG_UPDATE_INTERVAL", "1"))
BACKEND_POLL_INTERVAL = int(os.environ.get("BACKEND_POLL_INTERVAL", "5"))

REBOOT_DELAY = int(os.environ.get("REBOOT_DELAY", "15"))
REBOOT_COOLDOWN = int(os.environ.get("REBOOT_COOLDOWN", "300"))
WAKE_POST_COUNTDOWN = int(os.environ.get("WAKE_POST_COUNTDOWN", "3"))

VENV_PY = API_DIR / "venv" / "bin" / "python"
PYTHON_BIN = str(VENV_PY) if VENV_PY.exists() else sys.executable
GUI_CMD = [PYTHON_BIN, str(API_DIR / "clientflow_gui.py")]

# ---------------------------------------------------------------------------
# Globals
# ---------------------------------------------------------------------------
status_event_queue: queue.Queue = queue.Queue()
manual_chrome_closed = threading.Event()
countdown_or_starting_event = threading.Event()
gui_process: Optional[subprocess.Popen] = None

LOG_BUFFER: list = []
LOG_LOCK = threading.Lock()
LOG_WINDOW = datetime.timedelta(minutes=10)

UBUNTU_UPDATE_COUNT_CACHE = {"ts": 0.0, "value": None}
UBUNTU_UPDATE_COUNT_TTL = int(os.environ.get("UBUNTU_UPDATE_COUNT_TTL", "300"))

BACKEND_CONTROLLED_FIELDS = [
    "locality", "sort_order", "kiosk_url",
    "pending_reboot", "pending_shutdown", "pending_chrome_action", "pending_os_update", "school_id",
]
CLIENT_UPDATE_FIELDS = [
    "ubuntu_version", "uptime", "ubuntu_updates_available",
    "wifi_ip_address", "wifi_mac_address", "lan_ip_address", "lan_mac_address",
    "chrome_status", "chrome_last_updated", "chrome_color",
    "state", "last_seen", "created_at",
]

LIVESTREAM_PROCESS: Optional[subprocess.Popen] = None
LIVESTREAM_STATUS = "idle"
LIVESTREAM_LAST_SEGMENT: Optional[str] = None
LIVESTREAM_LAST_ERROR: Optional[str] = None

OS_UPDATE_PROCESS: Optional[subprocess.Popen] = None
OS_UPDATE_LOCK = threading.Lock()

system_is_shutting_down = False
shutdown_lock = threading.Lock()
event_handling_blocked = threading.Event()
LAST_WAKE_REBOOT: float = 0.0

# FIX 2+3: Tidsstempel for hvornår servicen startede — bruges til at filtrere
# gamle steps fra chrome_status.json i poll-loops så de ikke kan sætte
# state="sleeping" i backend efter en reboot.
SERVICE_STARTUP_TIME: float = time.time()


# ---------------------------------------------------------------------------
# Logging
# ---------------------------------------------------------------------------
def _utc_now_dt() -> datetime.datetime:
    return datetime.datetime.now(datetime.timezone.utc)


def _utc_now_iso() -> str:
    return _utc_now_dt().strftime("%Y-%m-%dT%H:%M:%S.%f") + "Z"


def log(msg: str) -> None:
    now = _utc_now_dt()
    line = f"{now.isoformat()} - {msg}"
    print(line)
    sys.stdout.flush()

    with LOG_LOCK:
        LOG_BUFFER.append((now, line))
        cutoff = now - LOG_WINDOW
        while LOG_BUFFER and LOG_BUFFER[0][0] < cutoff:
            LOG_BUFFER.pop(0)
        try:
            p = Path(LOG_PATH)
            p.parent.mkdir(parents=True, exist_ok=True)
            tmp = p.with_name(f"{p.name}.tmp.{os.getpid()}.{uuid.uuid4().hex[:8]}")
            with tmp.open("w", encoding="utf-8") as f:
                for _, l in LOG_BUFFER:
                    f.write(l + "\n")
            os.replace(str(tmp), str(p))
        except Exception as e:
            try:
                with open(LOG_PATH, "a", encoding="utf-8") as f:
                    f.write(line + "\n")
            except Exception:
                print(f"Kunne ikke skrive til logfil: {e}", file=sys.stderr)


# ---------------------------------------------------------------------------
# Config / atomic write
# ---------------------------------------------------------------------------
def atomic_write(path: str, obj: Any) -> None:
    try:
        p = Path(path)
        p.parent.mkdir(parents=True, exist_ok=True)
        tmp = p.with_name(f"{p.name}.tmp.{os.getpid()}.{uuid.uuid4().hex[:8]}")
        tmp.write_text(json.dumps(obj, ensure_ascii=False, indent=2), encoding="utf-8")
        os.replace(str(tmp), str(p))
    except Exception as e:
        log(f"FEJL ved atomic_write til {path}: {e}")


def ensure_api_files() -> None:
    try:
        Path(API_DIR).mkdir(parents=True, exist_ok=True)
        for path, default in [
            (CONFIG_PATH, {"backend": "", "client_id": None}),
            (CHROME_STATUS_PATH, {"steps": [], "chrome_running": False}),
            (GUI_EVENT_PATH, {}),
        ]:
            p = Path(path)
            if not p.exists():
                atomic_write(path, default)
        for fp in (LOG_PATH, GUI_STDOUT, GUI_STDERR,
                   KIOSK_WAKE_STDOUT, KIOSK_WAKE_STDERR,
                   KIOSK_SLEEP_STDOUT, KIOSK_SLEEP_STDERR,
                   OS_UPDATE_STDOUT, OS_UPDATE_STDERR):
            try:
                Path(fp).touch(exist_ok=True)
            except Exception:
                pass
    except Exception as e:
        log(f"FEJL ved ensure_api_files: {e}")


try:
    from config_utils import read_config, get_client_id, get_status  # type: ignore
except Exception:
    read_config = None
    get_client_id = None
    get_status = None

try:
    from status_utils import log as status_log, update_status_file  # type: ignore
except Exception:
    status_log = None
    update_status_file = None


def _read_config_fallback() -> Dict[str, Any]:
    try:
        p = Path(CONFIG_PATH)
        if p.exists():
            return json.loads(p.read_text(encoding="utf-8"))
    except Exception as e:
        log(f"FEJL ved read_config fallback: {e}")
    return {}


def _get_client_id_fallback() -> Optional[Any]:
    cfg = _read_config_fallback()
    return cfg.get("id") or cfg.get("client_id") or None


def _get_status_fallback() -> Optional[Any]:
    cfg = _read_config_fallback()
    return cfg.get("status")


if read_config is None:
    read_config = _read_config_fallback
if get_client_id is None:
    get_client_id = _get_client_id_fallback
if get_status is None:
    get_status = _get_status_fallback
if update_status_file is None:
    def update_status_file(status):  # type: ignore
        try:
            atomic_write(CHROME_STATUS_PATH, status)
        except Exception:
            pass


# ---------------------------------------------------------------------------
# Block/unblock event handling
# ---------------------------------------------------------------------------
def block_event_handling() -> None:
    try:
        log("Blokerer event_handling.")
        event_handling_blocked.set()
    except Exception as e:
        log(f"FEJL i block_event_handling: {e}")


def unblock_event_handling() -> None:
    try:
        log("Fjerner blokering af event_handling.")
        event_handling_blocked.clear()
    except Exception as e:
        log(f"FEJL i unblock_event_handling: {e}")


# ---------------------------------------------------------------------------
# Network/system info
# ---------------------------------------------------------------------------
def find_first_interface(prefixes):
    for iface in netifaces.interfaces():
        for prefix in prefixes:
            if iface.startswith(prefix):
                return iface
    return None


def get_ip_address(interface):
    try:
        if interface and interface in netifaces.interfaces():
            addrs = netifaces.ifaddresses(interface)
            if netifaces.AF_INET in addrs:
                return addrs[netifaces.AF_INET][0]["addr"]
    except Exception:
        pass
    return ""


def get_mac_address(interface):
    try:
        if interface and interface in netifaces.interfaces():
            addrs = netifaces.ifaddresses(interface)
            if netifaces.AF_LINK in addrs:
                return addrs[netifaces.AF_LINK][0]["addr"]
    except Exception:
        pass
    return ""


def get_network_info() -> Dict[str, str]:
    wifi_iface = find_first_interface(["wl"])
    lan_iface = find_first_interface(["en", "eth"])
    return {
        "wifi_ip_address": get_ip_address(wifi_iface),
        "wifi_mac_address": get_mac_address(wifi_iface),
        "lan_ip_address": get_ip_address(lan_iface),
        "lan_mac_address": get_mac_address(lan_iface),
    }


def get_ubuntu_version() -> str:
    try:
        with open("/etc/os-release") as f:
            for line in f:
                if line.startswith("PRETTY_NAME="):
                    return line.strip().split("=", 1)[1].strip('"')
    except Exception:
        pass
    return "Unknown"


def get_uptime() -> str:
    try:
        with open("/proc/uptime") as f:
            seconds = float(f.readline().split()[0])
            return str(int(seconds))
    except Exception:
        return ""


def get_ubuntu_updates_available(force: bool = False) -> Optional[int]:
    """
    Returnerer antal tilgængelige Ubuntu-opdateringer.

    Vigtigt:
    - Kører IKKE apt-get update her. ubuntu_update.py gør det, når update køres.
    - Bruger cache, så status_update_loop ikke kalder apt list hvert 3. sekund.
    - Efter ubuntu_update.py er kørt, kaldes denne med force=True, så backend
      straks får 0 i stedet for en gammel værdi som fx 186.
    """
    now = time.time()
    cached_value = UBUNTU_UPDATE_COUNT_CACHE.get("value")
    cached_ts = float(UBUNTU_UPDATE_COUNT_CACHE.get("ts") or 0.0)

    if not force and cached_value is not None and (now - cached_ts) < UBUNTU_UPDATE_COUNT_TTL:
        return int(cached_value)

    try:
        result = subprocess.run(
            ["apt", "list", "--upgradable"],
            capture_output=True,
            text=True,
            timeout=25,
        )
        output = (result.stdout or "") + "\n" + (result.stderr or "")
        count = 0
        for line in output.splitlines():
            line = line.strip()
            if not line:
                continue
            lower = line.lower()
            if lower.startswith("listing") or lower.startswith("oplister"):
                continue
            if "/" in line and ("upgradable" in lower or "kan opgraderes" in lower):
                count += 1

        UBUNTU_UPDATE_COUNT_CACHE["ts"] = now
        UBUNTU_UPDATE_COUNT_CACHE["value"] = count
        return count

    except Exception as e:
        log(f"FEJL ved optælling af Ubuntu-opdateringer: {e}")
        return cached_value if cached_value is not None else None


def collect_client_status() -> Dict[str, Any]:
    netinfo = get_network_info()
    return {
        "ubuntu_version": get_ubuntu_version(),
        "uptime": get_uptime(),
        "ubuntu_updates_available": get_ubuntu_updates_available(),
        "wifi_ip_address": netinfo["wifi_ip_address"],
        "wifi_mac_address": netinfo["wifi_mac_address"],
        "lan_ip_address": netinfo["lan_ip_address"],
        "lan_mac_address": netinfo["lan_mac_address"],
        "last_seen": _utc_now_iso(),
    }


# ---------------------------------------------------------------------------
# GUI
# ---------------------------------------------------------------------------
def start_gui() -> None:
    global gui_process
    try:
        if gui_process and gui_process.poll() is None:
            log("GUI kører allerede.")
            return
        log("Starter GUI...")
        stdout_log = open(GUI_STDOUT, "a", encoding="utf-8")
        stderr_log = open(GUI_STDERR, "a", encoding="utf-8")
        env = {**os.environ}
        env["DISPLAY"] = env.get("DISPLAY", ":0")
        env["XAUTHORITY"] = env.get("XAUTHORITY", "/run/user/1000/gdm/Xauthority")
        gui_process = subprocess.Popen(
            GUI_CMD,
            stdout=stdout_log, stderr=stderr_log,
            env=env, cwd=str(API_DIR),
        )
        log(f"GUI startet med PID {gui_process.pid}")
    except Exception as e:
        log(f"FEJL ved start_gui: {e}")


def gui_watchdog() -> None:
    while not system_is_shutting_down:
        try:
            if not gui_process or gui_process.poll() is not None:
                log("GUI ikke kørende, forsøger genstart...")
                start_gui()
        except Exception as e:
            log(f"FEJL i gui_watchdog: {e}")
        time.sleep(5)


def gui_event_watcher() -> None:
    path = Path(GUI_EVENT_PATH)
    while not system_is_shutting_down:
        try:
            if path.exists() and path.stat().st_size > 0:
                claim_path = path.with_name(f"{path.name}.claim.{os.getpid()}.{uuid.uuid4().hex[:8]}")
                try:
                    os.replace(str(path), str(claim_path))
                except FileNotFoundError:
                    time.sleep(1)
                    continue

                try:
                    text = claim_path.read_text(encoding="utf-8").strip()
                    if not text or text == "{}":
                        claim_path.unlink(missing_ok=True)
                        time.sleep(1)
                        continue
                    event = json.loads(text)
                except Exception as e:
                    log(f"FEJL ved læsning af gui_event: {e}")
                    try:
                        claim_path.unlink(missing_ok=True)
                    except Exception:
                        pass
                    time.sleep(1)
                    continue

                try:
                    claim_path.unlink(missing_ok=True)
                except Exception:
                    pass

                log(f"[GUI_EVENT] Modtog: {event}")
                action = event.get("action")
                if action == "open":
                    status_event_queue.put({
                        "type": "chrome_start",
                        "url": event.get("url"),
                        "countdown": 12,
                        "trigger": event.get("trigger", "gui"),
                        "clear_pca": False,
                    })
                elif action == "close":
                    status_event_queue.put({
                        "type": "chrome_kill",
                        "trigger": event.get("trigger", "gui"),
                        "clear_pca": False,
                    })
        except Exception as e:
            log(f"FEJL i gui_event_watcher: {e}")
        time.sleep(1)


# ---------------------------------------------------------------------------
# Backend API
# ---------------------------------------------------------------------------
class BackendAPI:
    def __init__(
        self,
        base_url: str,
        username: str = "",
        password: str = "",
        client_id: str = "",
        client_secret: str = "",
    ):
        self.base_url = base_url.rstrip("/")
        self.username = username or ""
        self.password = password or ""
        self.client_id = str(client_id or "").strip()
        self.client_secret = str(client_secret or "").strip()
        self.token: Optional[str] = None
        self.token_time: Optional[float] = None
        self._lock = threading.Lock()

    def _get_client_token(self) -> Optional[str]:
        if not self.client_id or not self.client_secret:
            return None

        try:
            client_id_int = int(self.client_id)
        except Exception:
            log(f"FEJL ved client-token-login: CLIENTFLOW_CLIENT_ID er ikke et tal: {self.client_id!r}")
            return None

        url = f"{self.base_url}/auth/client-token"
        payload = {"client_id": client_id_int, "client_secret": self.client_secret}
        try:
            resp = requests.post(url, json=payload, timeout=10)
            if resp.status_code == 200:
                with self._lock:
                    self.token = resp.json().get("access_token")
                    self.token_time = time.time()
                log("Fik nyt client access token fra backend.")
                return self.token
            log(f"FEJL ved client-token-login: {resp.status_code} {resp.text[:200]}")
        except Exception as e:
            log(f"FEJL ved client-token-login: {e}")
        return None

    def _get_user_token(self) -> Optional[str]:
        if not self.username or not self.password:
            return None

        url = f"{self.base_url}/auth/token"
        data = {"username": self.username, "password": self.password}
        headers = {"Content-Type": "application/x-www-form-urlencoded"}
        try:
            resp = requests.post(url, data=data, headers=headers, timeout=10)
            if resp.status_code == 200:
                with self._lock:
                    self.token = resp.json().get("access_token")
                    self.token_time = time.time()
                log("Fik nyt user access token fra backend.")
                return self.token
            log(f"FEJL ved user token-login: {resp.status_code} {resp.text[:200]}")
        except Exception as e:
            log(f"FEJL ved user token-login: {e}")
        return None

    def _get_token(self) -> Optional[str]:
        # Foretræk client-secret auth på nye installationer.
        token = self._get_client_token()
        if token:
            return token

        # Bagudkompatibel fallback til eksisterende klienter med admin/service-login.
        token = self._get_user_token()
        if token:
            return token

        log(
            "FEJL ved token-login: hverken CLIENTFLOW_CLIENT_ID/CLIENTFLOW_CLIENT_SECRET "
            "eller CLIENTFLOW_USERNAME/CLIENTFLOW_PASSWORD er sat korrekt."
        )
        with self._lock:
            self.token = None
        return None

    def _headers(self) -> Optional[Dict[str, str]]:
        token = self.token or self._get_token()
        if not token:
            return None
        return {
            "Authorization": f"Bearer {token}",
            "accept": "application/json",
            "Content-Type": "application/json",
        }

    def _refresh_token_if_needed(self, resp) -> bool:
        if resp.status_code == 401:
            log("Token udløbet eller ugyldigt, forsøger fornyelse...")
            self._get_token()
            return True
        return False

    def create_client(self) -> Optional[Dict[str, Any]]:
        netinfo = get_network_info()
        client_info = {
            "name": os.uname().nodename,
            "locality": "Ukendt",
            **netinfo,
            "sort_order": None,
            "kiosk_url": "",
            "ubuntu_version": get_ubuntu_version(),
            "uptime": get_uptime(),
            "chrome_status": "unknown",
            "chrome_color": "",
            "pending_chrome_action": "none",
            "school_id": None,
            "state": "normal",
            "created_at": _utc_now_iso(),
            "livestream_status": "idle",
            "livestream_last_segment": None,
            "livestream_last_error": None,
        }
        url = f"{self.base_url}/api/clients/"
        headers = self._headers()
        if not headers:
            log("Kan ikke oprette klient: mangler backend-token.")
            return None
        try:
            resp = requests.post(url, json=client_info, headers=headers, timeout=10)
            if self._refresh_token_if_needed(resp):
                headers = self._headers()
                if not headers:
                    return None
                resp = requests.post(url, json=client_info, headers=headers, timeout=10)
            log(f"Opret klient: {resp.status_code}")
            if resp.status_code in (200, 201):
                return resp.json()
            log(f"Fejl ved opret klient: {resp.text[:200]}")
        except Exception as e:
            log(f"FEJL ved create_client: {e}")
        return None

    def fetch_backend_config(self, client_id) -> Any:
        url = f"{self.base_url}/api/clients/{client_id}/"
        headers = self._headers()
        if not headers:
            log("Kan ikke hente config: mangler backend-token.")
            return None
        try:
            resp = requests.get(url, headers=headers, timeout=10)
            if self._refresh_token_if_needed(resp):
                headers = self._headers()
                if not headers:
                    return None
                resp = requests.get(url, headers=headers, timeout=10)
            if resp.status_code == 200:
                return resp.json()
            if resp.status_code == 404:
                return False
            if resp.status_code == 401:
                return None
            log(f"fetch_backend_config returnerede {resp.status_code}")
        except Exception as e:
            log(f"FEJL ved fetch_backend_config: {e}")
        return None

    def send_heartbeat(self, client_id) -> bool:
        """
        Send heartbeat + frisk uptime.

        Lokal GUI får uptime fra clientflow_config.json, som opdateres direkte
        fra /proc/uptime. Webfrontend får uptime fra backend. Hvis heartbeat kun
        opdaterer last_seen, kan webfrontendens uptime blive bagud.

        Derfor sender vi uptime med hvert heartbeat.
        """
        url = f"{self.base_url}/api/clients/{client_id}/heartbeat"
        headers = self._headers()
        if not headers:
            log("Kan ikke sende heartbeat: mangler backend-token.")
            return False
        payload = {
            "uptime": get_uptime(),
            "ubuntu_version": get_ubuntu_version(),
        }

        try:
            resp = requests.post(url, json=payload, headers=headers, timeout=5)
            if self._refresh_token_if_needed(resp):
                headers = self._headers()
                if not headers:
                    return False
                resp = requests.post(url, json=payload, headers=headers, timeout=5)
            return resp.status_code == 200
        except Exception as e:
            log(f"FEJL ved send_heartbeat: {e}")
            return False

    def update_client_status(self, client_id, data: Dict[str, Any]) -> bool:
        url = f"{self.base_url}/api/clients/{client_id}/update"
        send_data = {
            k: v for k, v in data.items()
            if k in CLIENT_UPDATE_FIELDS or k in (
                "pending_reboot", "pending_shutdown",
                "livestream_status", "livestream_last_segment",
                "livestream_last_error", "pending_chrome_action",
                "pending_os_update", "chrome_step",
            )
        }
        try:
            latest_message, latest_color, latest_step = get_latest_chrome_status_color_and_step()
            if latest_message is not None:
                send_data["chrome_status"] = latest_message
                send_data["chrome_color"] = latest_color
                send_data["chrome_last_updated"] = _utc_now_iso()
            if latest_step is not None:
                send_data["chrome_step"] = latest_step
        except Exception as e:
            log(f"FEJL ved hent af seneste chrome_status: {e}")

        try:
            last_step = get_latest_chrome_step_name()
            # FIX 3: Udled kun state fra steps der er skrevet efter servicen startede
            if last_step == "system_sleep" and _latest_step_is_after_startup():
                send_data["state"] = "sleeping"
            elif last_step == "system_wake" and _latest_step_is_after_startup():
                send_data["state"] = "normal"
        except Exception as e:
            log(f"FEJL ved udledning af state: {e}")

        try:
            headers = self._headers()
            if not headers:
                log("Kan ikke opdatere klientstatus: mangler backend-token.")
                return False
            resp = requests.put(url, json=send_data, headers=headers, timeout=5)
            if self._refresh_token_if_needed(resp):
                headers = self._headers()
                if not headers:
                    return False
                resp = requests.put(url, json=send_data, headers=headers, timeout=5)
            return resp.status_code == 200
        except Exception as e:
            log(f"Status update error: {e}")
            return False

    def clear_pending_chrome_action(self, client_id) -> bool:
        try:
            ok = self.update_client_status(client_id, {"pending_chrome_action": "none"})
            if ok:
                log(f"[PCA] pending_chrome_action nulstillet i backend for klient {client_id}")
            else:
                log(f"[PCA] ADVARSEL: kunne ikke nulstille pending_chrome_action for klient {client_id}")
            return ok
        except Exception as e:
            log(f"[PCA] FEJL ved clear_pending_chrome_action: {e}")
            return False


# ---------------------------------------------------------------------------
# Chrome status helpers
# ---------------------------------------------------------------------------
def _read_chrome_steps() -> list:
    """Læs steps fra chrome_status.json. Returnerer [] ved fejl."""
    try:
        p = Path(CHROME_STATUS_PATH)
        if not p.exists():
            return []
        data = json.loads(p.read_text(encoding="utf-8"))
        steps = data.get("steps", []) if isinstance(data, dict) else []
        return steps if isinstance(steps, list) else []
    except Exception as e:
        log(f"FEJL i _read_chrome_steps: {e}")
        return []


def _step_timestamp_as_epoch(step: Dict[str, Any]) -> Optional[float]:
    """
    Konvertér step['timestamp'] (ISO 8601 streng) til float epoch sekunder.
    Returnerer None hvis timestamp mangler eller ikke kan parses.
    """
    ts_raw = step.get("timestamp")
    if not ts_raw:
        return None
    try:
        ts_str = str(ts_raw).replace("Z", "+00:00")
        dt = datetime.datetime.fromisoformat(ts_str)
        return dt.timestamp()
    except Exception:
        return None


def _latest_step_is_after_startup() -> bool:
    """
    FIX 2+3: Returnerer True hvis det seneste step i chrome_status.json
    er skrevet EFTER SERVICE_STARTUP_TIME.
    Forhindrer at gamle (pre-reboot) steps sætter state="sleeping" i backend.
    """
    try:
        steps = _read_chrome_steps()
        if not steps:
            return False
        epoch = _step_timestamp_as_epoch(steps[-1])
        if epoch is None:
            return False
        return epoch >= SERVICE_STARTUP_TIME
    except Exception as e:
        log(f"FEJL i _latest_step_is_after_startup: {e}")
        return False


def get_latest_chrome_status_color_and_step() -> Tuple[Optional[str], Optional[str], Optional[str]]:
    """
    Returnerer (message, color, step_name) fra sidste step.
    """
    try:
        steps = _read_chrome_steps()
        if not steps:
            return None, None, None
        last = steps[-1]
        return last.get("message"), last.get("color"), last.get("step")
    except Exception as e:
        log(f"FEJL i get_latest_chrome_status_color_and_step: {e}")
        return None, None, None


def get_latest_chrome_status_and_color() -> Tuple[Optional[str], Optional[str]]:
    """Bagudkompatibel wrapper — returnerer (message, color)."""
    msg, color, _ = get_latest_chrome_status_color_and_step()
    return msg, color


def get_latest_chrome_step_name() -> Optional[str]:
    try:
        steps = _read_chrome_steps()
        if not steps:
            return None
        return steps[-1].get("step")
    except Exception as e:
        log(f"FEJL i get_latest_chrome_step_name: {e}")
        return None


def update_chrome_status_in_backend(client_id, last_step: Dict[str, Any], backend: BackendAPI) -> bool:
    """
    PUT til /chrome-status med message, color og step_name.

    Vi sender også id/timestamp/trigger som metadata. Den nuværende backend
    ignorerer ukendte felter, men felterne gør kaldet fremtidssikkert hvis
    backend senere skal gemme egentlig status-historik.
    """
    url = f"{BASE_URL}/api/clients/{client_id}/chrome-status"
    headers = backend._headers()
    data = {
        "chrome_status": last_step.get("message", "Ingen status."),
        "chrome_color": last_step.get("color", "black"),
        "chrome_step": last_step.get("step"),
        "chrome_step_id": last_step.get("id"),
        "chrome_step_timestamp": last_step.get("timestamp"),
        "chrome_step_trigger": last_step.get("trigger"),
    }
    try:
        resp = requests.put(url, json=data, headers=headers, timeout=5)
        if resp.status_code != 200:
            log(f"[chrome-status] backend svarede {resp.status_code}: {resp.text[:200]}")
        return resp.status_code == 200
    except Exception as e:
        log(f"[PATCH] Kunne ikke opdatere chrome-status: {e}")
        return False


def send_latest_status_to_backend(client_id, backend: BackendAPI) -> None:
    if not client_id or not backend:
        return
    try:
        steps = _read_chrome_steps()
        if not steps:
            return
        last_step = steps[-1]
        update_chrome_status_in_backend(client_id, last_step, backend)

        step_name = last_step.get("step", "")

        # FIX 2+3: Udled kun state fra steps skrevet efter servicen startede
        derived_state = None
        if _latest_step_is_after_startup():
            if step_name == "system_sleep":
                derived_state = "sleeping"
            elif step_name == "system_wake":
                derived_state = "normal"

        payload = {
            "chrome_status": last_step.get("message", ""),
            "chrome_color": last_step.get("color", "black"),
            "chrome_last_updated": _utc_now_iso(),
            "chrome_step": step_name or None,
        }
        if derived_state is not None:
            payload["state"] = derived_state

        backend.update_client_status(client_id, payload)
    except Exception as e:
        log(f"Fejl ved send_latest_status_to_backend: {e}")


# ---------------------------------------------------------------------------
# Manual wake helpers (input monitor)
# ---------------------------------------------------------------------------
def _append_manual_wake_step(trigger: str = "manual") -> bool:
    step = {
        "step": "system_wake",
        "message": "Klient blev vækket manuelt",
        "status": "running",
        "trigger": trigger,
        "color": "green",
        "timestamp": _utc_now_iso(),
        "id": str(uuid.uuid4()),
    }
    if _HAS_CHROME_KIOSK and hasattr(chrome_kiosk, "append_external_step"):
        try:
            chrome_kiosk.append_external_step(step)
            log("manual_wake: brugte chrome_kiosk.append_external_step")
            return True
        except Exception as e:
            log(f"manual_wake: chrome_kiosk fejl: {e}")
    try:
        p = Path(CHROME_STATUS_PATH)
        data = {"steps": [], "chrome_running": False}
        if p.exists():
            try:
                existing = json.loads(p.read_text(encoding="utf-8"))
                if isinstance(existing, dict):
                    data = existing
            except Exception:
                pass
        steps = data.get("steps", [])
        if not isinstance(steps, list):
            steps = []
        steps.append(step)
        data["steps"] = steps[-50:]
        atomic_write(CHROME_STATUS_PATH, data)
        return True
    except Exception as e:
        log(f"manual_wake fallback fejl: {e}")
        return False


def input_monitor_loop(backend: BackendAPI, backend_data: Dict[str, Any]) -> None:
    log("Starter input_monitor_loop.")
    xprintidle_bin = which("xprintidle")
    POLL_INTERVAL = 1.0

    while not system_is_shutting_down:
        try:
            if get_latest_chrome_step_name() != "system_sleep":
                time.sleep(1.0)
                continue

            log("Klient er i dvale -> aktiverer input-lytning.")
            awakened = False

            if evdev:
                try:
                    devices = []
                    for dev_path in evdev.list_devices():
                        try:
                            d = evdev.InputDevice(dev_path)
                            caps = d.capabilities()
                            if any(t in caps for t in (evdev.ecodes.EV_KEY, evdev.ecodes.EV_REL, evdev.ecodes.EV_ABS)):
                                devices.append(d)
                        except Exception:
                            continue

                    if devices:
                        log(f"input_monitor: overvåger {len(devices)} evdev devices.")
                        fds = {d.fd: d for d in devices}
                        while not system_is_shutting_down and get_latest_chrome_step_name() == "system_sleep" and not awakened:
                            r, _, _ = select.select(list(fds.keys()), [], [], POLL_INTERVAL)
                            if r:
                                for fd in r:
                                    dev = fds.get(fd)
                                    if not dev:
                                        continue
                                    try:
                                        for ev in dev.read():
                                            if ev.type in (evdev.ecodes.EV_KEY, evdev.ecodes.EV_REL, evdev.ecodes.EV_ABS):
                                                log(f"input_monitor: input event type={ev.type} -> vågner manuelt.")
                                                awakened = True
                                                break
                                    except Exception:
                                        awakened = True
                                        break
                                    if awakened:
                                        break
                except Exception as e:
                    log(f"input_monitor evdev fejl: {e}")

            if not awakened and xprintidle_bin:
                try:
                    log("input_monitor: bruger xprintidle fallback.")
                    while not system_is_shutting_down and get_latest_chrome_step_name() == "system_sleep" and not awakened:
                        try:
                            out = subprocess.check_output(
                                [xprintidle_bin], stderr=subprocess.DEVNULL, timeout=2,
                            )
                            idle_ms = int(out.strip())
                            if idle_ms < 1000:
                                log(f"input_monitor (xprintidle): aktivitet (idle={idle_ms}ms)")
                                awakened = True
                                break
                        except Exception:
                            break
                        time.sleep(0.5)
                except Exception as e:
                    log(f"input_monitor xprintidle fejl: {e}")

            if awakened:
                _append_manual_wake_step(trigger="manual")
                try:
                    run_kiosk_script(KIOSK_WAKE_SCRIPT_PATH, "kiosk_wake", timeout=60, trigger="manual")
                except Exception as e:
                    log(f"input_monitor: run_kiosk_script fejl: {e}")
                cid = backend_data.get("id") or read_config().get("id")
                if cid:
                    try:
                        send_latest_status_to_backend(cid, backend)
                    except Exception as e:
                        log(f"input_monitor: backend update fejl: {e}")
                _schedule_reboot_after_wake(trigger="manual", client_id=cid, backend=backend)
                continue

            if not (evdev or xprintidle_bin):
                log("input_monitor: ingen mekanisme tilgængelig (evdev/xprintidle mangler).")
                time.sleep(5)

        except Exception as e:
            log(f"input_monitor_loop fejl: {e}")
            time.sleep(2)


# ---------------------------------------------------------------------------
# Shutdown / reboot
# ---------------------------------------------------------------------------
def try_shutdown() -> None:
    for cmd in (
        "sudo /sbin/shutdown now", "sudo /sbin/poweroff",
        "sudo shutdown now", "sudo poweroff",
        "sudo systemctl poweroff",
    ):
        log(f"Prøver: {cmd}")
        os.system(cmd)
        time.sleep(5)
    time.sleep(10)


def try_reboot() -> None:
    for cmd in ("sudo /sbin/reboot", "sudo reboot", "sudo systemctl reboot"):
        log(f"Prøver: {cmd}")
        os.system(cmd)
        time.sleep(5)
    time.sleep(10)


def run_kiosk_script(script_path: str, name: str, timeout: int = 60, trigger: Optional[str] = None) -> bool:
    log(f"Kører {name}: {script_path} (trigger={trigger})")
    try:
        stdout_path = API_DIR / f"{name}_stdout.log"
        stderr_path = API_DIR / f"{name}_stderr.log"
        stdout_log = open(stdout_path, "a", encoding="utf-8")
        stderr_log = open(stderr_path, "a", encoding="utf-8")
        env = {
            **os.environ,
            "DISPLAY": os.environ.get("DISPLAY", ":0"),
            "XAUTHORITY": os.environ.get("XAUTHORITY", "/run/user/1000/gdm/Xauthority"),
        }
        if trigger:
            env["KIOSK_TRIGGER"] = str(trigger)
        p = subprocess.Popen(
            [PYTHON_BIN, script_path],
            cwd=str(API_DIR), stdout=stdout_log, stderr=stderr_log, env=env,
        )
        try:
            p.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            log(f"{name} timeout ({timeout}s), terminerer.")
            try:
                p.terminate()
                p.wait(timeout=5)
            except Exception:
                try:
                    p.kill()
                except Exception:
                    pass
        rc = p.returncode
        stdout_log.close()
        stderr_log.close()
        log(f"{name} færdig med rc={rc}")
        return rc == 0
    except Exception as e:
        log(f"FEJL ved run_kiosk_script({name}): {e}")
        return False


def _append_os_update_failed_step(message: str, trigger: str = "backend") -> None:
    step = {
        "step": "os_update_failed",
        "message": message,
        "status": "os_update_failed",
        "trigger": trigger,
        "color": "red",
        "timestamp": _utc_now_iso(),
        "id": str(uuid.uuid4()),
    }
    if _HAS_CHROME_KIOSK and hasattr(chrome_kiosk, "append_external_step"):
        try:
            chrome_kiosk.append_external_step(step)
            return
        except Exception as e:
            log(f"os_update_failed: chrome_kiosk append fejl: {e}")
    _fallback_append_status_step(step)


def _set_os_update_flags(
    backend: BackendAPI,
    backend_data: Dict[str, Any],
    client_id: Optional[Any],
    *,
    pending: bool,
    state: str,
) -> None:
    try:
        backend_data["pending_os_update"] = pending
        backend_data["pending_chrome_action"] = None
        backend_data["state"] = state
        atomic_write(CONFIG_PATH, backend_data)
    except Exception as e:
        log(f"[OS_UPDATE] FEJL ved lokal flag-opdatering: {e}")

    if client_id:
        try:
            backend.update_client_status(client_id, {
                "pending_chrome_action": "none",
                "pending_os_update": pending,
                "state": state,
            })
        except Exception as e:
            log(f"[OS_UPDATE] FEJL ved backend flag-opdatering: {e}")


def _sync_ubuntu_update_count_to_backend(
    backend: BackendAPI,
    backend_data: Dict[str, Any],
    client_id: Optional[Any],
) -> None:
    """Force-opdater ubuntu_updates_available lokalt og i backend."""
    if not client_id:
        return

    count = get_ubuntu_updates_available(force=True)
    if count is None:
        log("[OS_UPDATE] Kunne ikke optælle ubuntu_updates_available efter update.")
        return

    try:
        backend_data["ubuntu_updates_available"] = count
        atomic_write(CONFIG_PATH, backend_data)
    except Exception as e:
        log(f"[OS_UPDATE] FEJL ved lokal sync af ubuntu_updates_available: {e}")

    try:
        ok = backend.update_client_status(client_id, {"ubuntu_updates_available": count})
        log(f"[OS_UPDATE] Synkroniserede ubuntu_updates_available={count} til backend (ok={ok})")
    except Exception as e:
        log(f"[OS_UPDATE] FEJL ved backend sync af ubuntu_updates_available: {e}")


def _os_update_worker(
    backend: BackendAPI,
    backend_data: Dict[str, Any],
    client_id: Optional[Any],
    trigger: str,
) -> None:
    global OS_UPDATE_PROCESS

    rc: Optional[int] = None
    try:
        script = Path(OS_UPDATE_SCRIPT_PATH)
        if not script.exists():
            msg = f"Ubuntu-opdatering fejlede: ubuntu_update.py findes ikke ({script})"
            log(f"[OS_UPDATE] {msg}")
            _append_os_update_failed_step(msg, trigger=trigger)
            if client_id:
                send_latest_status_to_backend(client_id, backend)
            _set_os_update_flags(backend, backend_data, client_id, pending=False, state="error")
            return

        log(f"[OS_UPDATE] Starter ubuntu_update.py fra pending_chrome_action (trigger={trigger})")
        env = {
            **os.environ,
            "DISPLAY": os.environ.get("DISPLAY", ":0"),
            "XAUTHORITY": os.environ.get("XAUTHORITY", "/run/user/1000/gdm/Xauthority"),
            "KIOSK_TRIGGER": trigger,
            "CLIENTFLOW_TRIGGER": trigger,
        }

        with open(OS_UPDATE_STDOUT, "a", encoding="utf-8") as stdout_log, \
             open(OS_UPDATE_STDERR, "a", encoding="utf-8") as stderr_log:
            stdout_log.write(f"\n--- {_utc_now_iso()} | ubuntu_update startet af clientflow_service (trigger={trigger}) ---\n")
            stdout_log.flush()
            proc = subprocess.Popen(
                [PYTHON_BIN, OS_UPDATE_SCRIPT_PATH],
                cwd=str(API_DIR),
                stdout=stdout_log,
                stderr=stderr_log,
                env=env,
            )
            with OS_UPDATE_LOCK:
                OS_UPDATE_PROCESS = proc
            rc = proc.wait()

        log(f"[OS_UPDATE] ubuntu_update.py afsluttet med rc={rc}")

        if client_id:
            try:
                send_latest_status_to_backend(client_id, backend)
            except Exception as e:
                log(f"[OS_UPDATE] FEJL ved status-push efter ubuntu_update: {e}")

            # Vigtigt: frontend viser client.ubuntu_updates_available.
            # Efter os_update_none/os_update_complete skal backend ikke blive
            # stående på en gammel værdi som fx 186.
            _sync_ubuntu_update_count_to_backend(backend, backend_data, client_id)

        if rc == 0:
            # Ved normal produktion vil ubuntu_update.py ofte nå at genstarte
            # maskinen lige efter os_update_complete. Hvis OS_UPDATE_SKIP_REBOOT=1
            # bruges til test, rydder vi pending-flag her.
            _set_os_update_flags(backend, backend_data, client_id, pending=False, state="normal")
        else:
            _append_os_update_failed_step(
                f"Ubuntu-opdatering fejlede (exitkode {rc})",
                trigger=trigger,
            )
            if client_id:
                send_latest_status_to_backend(client_id, backend)
            _set_os_update_flags(backend, backend_data, client_id, pending=False, state="error")

    except Exception as e:
        log(f"[OS_UPDATE] FEJL i _os_update_worker: {e}")
        _append_os_update_failed_step(f"Ubuntu-opdatering fejlede: {e}", trigger=trigger)
        if client_id:
            try:
                send_latest_status_to_backend(client_id, backend)
            except Exception:
                pass
        _set_os_update_flags(backend, backend_data, client_id, pending=False, state="error")
    finally:
        with OS_UPDATE_LOCK:
            OS_UPDATE_PROCESS = None


def _handle_pending_os_update(
    backend: BackendAPI,
    backend_data: Dict[str, Any],
    client_id: Optional[Any],
    pca_source: Optional[str],
) -> None:
    trigger = _map_source_to_trigger("os_update", pca_source)

    with OS_UPDATE_LOCK:
        already_running = OS_UPDATE_PROCESS is not None and OS_UPDATE_PROCESS.poll() is None

    if already_running:
        log("[OS_UPDATE] os_update modtaget, men ubuntu_update.py kører allerede — clearer kun pending_chrome_action.")
        _set_os_update_flags(backend, backend_data, client_id, pending=True, state="updating")
        return

    # Clear pending action straks, så backend ikke starter flere opdateringer.
    _set_os_update_flags(backend, backend_data, client_id, pending=True, state="updating")

    t = threading.Thread(
        target=_os_update_worker,
        args=(backend, backend_data, client_id, trigger),
        daemon=True,
        name="os_update_worker",
    )
    t.start()


def reboot_countdown(seconds: int, trigger: str, client_id: Optional[Any], backend: BackendAPI) -> None:
    if seconds <= 0:
        return
    for s in range(seconds, 0, -1):
        try:
            if _HAS_CHROME_KIOSK and hasattr(chrome_kiosk, "write_step"):
                chrome_kiosk.write_step("system_reboot_countdown", trigger, extra=s, status="reboot_countdown")
            else:
                _fallback_append_status_step({
                    "step": "system_reboot_countdown",
                    "message": f"Genstarter om {s} sekund" + ("" if s == 1 else "er"),
                    "status": "reboot_countdown",
                    "trigger": trigger,
                    "color": "orange",
                    "timestamp": _utc_now_iso(),
                    "id": str(uuid.uuid4()),
                })
            if client_id and backend:
                try:
                    send_latest_status_to_backend(client_id, backend)
                except Exception:
                    pass
        except Exception as e:
            log(f"FEJL i reboot_countdown iteration: {e}")
        time.sleep(1)


def _fallback_append_status_step(step: Dict[str, Any]) -> None:
    try:
        path = Path(CHROME_STATUS_PATH)
        data = {"steps": [], "chrome_running": False}
        if path.exists():
            try:
                existing = json.loads(path.read_text(encoding="utf-8"))
                if isinstance(existing, dict):
                    data = existing
            except Exception:
                pass
        steps = data.get("steps", [])
        if not isinstance(steps, list):
            steps = []
        steps.append(step)
        data["steps"] = steps[-50:]
        atomic_write(CHROME_STATUS_PATH, data)
    except Exception as e:
        log(f"_fallback_append_status_step fejl: {e}")


def _schedule_reboot_after_wake(trigger: str, client_id: Optional[Any], backend: BackendAPI) -> None:
    global LAST_WAKE_REBOOT, system_is_shutting_down
    now_ts = time.time()
    if now_ts - LAST_WAKE_REBOOT < REBOOT_COOLDOWN:
        log(f"Springer reboot over (cooldown: {now_ts - LAST_WAKE_REBOOT:.1f}s < {REBOOT_COOLDOWN}s).")
        return
    try:
        log(f"Venter {REBOOT_DELAY}s før reboot (trigger={trigger}).")
        reboot_countdown(REBOOT_DELAY, trigger, client_id, backend)

        if WAKE_POST_COUNTDOWN > 0:
            log(f"Venter {WAKE_POST_COUNTDOWN}s ekstra (post-wake delay).")
            time.sleep(WAKE_POST_COUNTDOWN)

        log("Forbereder reboot. Blokerer events.")
        block_event_handling()
        system_is_shutting_down = True
        if _HAS_CHROME_KIOSK:
            try:
                chrome_kiosk.set_system_shutdown_flag()
            except Exception:
                pass
            try:
                chrome_kiosk.shutdown_chrome(trigger="wakeup", after_system_status=True)
            except Exception:
                pass
            try:
                chrome_kiosk.write_system_status("system_rebooting", "wakeup")
            except Exception:
                pass
        if client_id:
            try:
                send_latest_status_to_backend(client_id, backend)
            except Exception:
                pass
        LAST_WAKE_REBOOT = time.time()
        try_reboot()
    except Exception as e:
        log(f"FEJL i _schedule_reboot_after_wake: {e}")


# ---------------------------------------------------------------------------
# Livestream
# ---------------------------------------------------------------------------
def start_livestream() -> None:
    global LIVESTREAM_PROCESS, LIVESTREAM_STATUS, LIVESTREAM_LAST_ERROR
    if LIVESTREAM_PROCESS is not None and LIVESTREAM_PROCESS.poll() is None:
        log("Livestream kører allerede.")
        return
    log("Starter livestream.py ...")
    LIVESTREAM_STATUS = "starting"
    LIVESTREAM_LAST_ERROR = None
    try:
        stdout_log = open(LIVESTREAM_STDOUT, "a")
        stderr_log = open(LIVESTREAM_STDERR, "a")
        env = {
            **os.environ,
            "DISPLAY": os.environ.get("DISPLAY", ":0"),
            "XAUTHORITY": os.environ.get("XAUTHORITY", "/run/user/1000/gdm/Xauthority"),
        }
        LIVESTREAM_PROCESS = subprocess.Popen(
            [PYTHON_BIN, LIVESTREAM_SCRIPT_PATH],
            cwd=str(API_DIR),
            stdout=stdout_log, stderr=stderr_log,
            env=env,
        )
        LIVESTREAM_STATUS = "running"
        log(f"livestream.py startet med PID {LIVESTREAM_PROCESS.pid}")
    except Exception as e:
        log(f"FEJL ved start_livestream: {e}")
        LIVESTREAM_STATUS = "error"
        LIVESTREAM_LAST_ERROR = str(e)


def stop_livestream() -> None:
    global LIVESTREAM_PROCESS, LIVESTREAM_STATUS
    if LIVESTREAM_PROCESS and LIVESTREAM_PROCESS.poll() is None:
        log("Stopper livestream.py ...")
        LIVESTREAM_STATUS = "stopping"
        try:
            LIVESTREAM_PROCESS.terminate()
            LIVESTREAM_PROCESS.wait(timeout=15)
        except Exception:
            try:
                LIVESTREAM_PROCESS.kill()
            except Exception:
                pass
        LIVESTREAM_PROCESS = None
    LIVESTREAM_STATUS = "idle"


# ---------------------------------------------------------------------------
# Loops
# ---------------------------------------------------------------------------
def status_update_loop(backend: BackendAPI, backend_data: Dict[str, Any], stop_event: threading.Event) -> None:
    last_payload_hash: Optional[str] = None

    while not stop_event.is_set() and not system_is_shutting_down:
        try:
            client_id = backend_data.get("id")
            if client_id:
                backend_data.update(collect_client_status())
                if "created_at" not in backend_data:
                    backend_data["created_at"] = _utc_now_iso()
                data = {k: backend_data.get(k) for k in CLIENT_UPDATE_FIELDS if k in backend_data}
                data["livestream_status"] = LIVESTREAM_STATUS
                data["livestream_last_segment"] = LIVESTREAM_LAST_SEGMENT
                data["livestream_last_error"] = LIVESTREAM_LAST_ERROR

                latest_message, latest_color, latest_step = get_latest_chrome_status_color_and_step()
                if latest_message is not None:
                    data["chrome_status"] = latest_message
                    data["chrome_color"] = latest_color
                    data["chrome_last_updated"] = _utc_now_iso()
                    if latest_step is not None:
                        data["chrome_step"] = latest_step

                    # FIX 3: Udled kun state fra steps der er skrevet efter servicen startede
                    if _latest_step_is_after_startup():
                        if latest_step == "system_sleep":
                            data["state"] = "sleeping"
                        elif latest_step == "system_wake":
                            data["state"] = "normal"
                    else:
                        log(f"[status_update_loop] Ignorerer gammelt step '{latest_step}' ved state-udledning (pre-startup)")

                stable = {k: v for k, v in data.items() if k not in ("last_seen", "uptime", "chrome_last_updated")}
                payload_hash = json.dumps(stable, sort_keys=True, default=str)
                if payload_hash != last_payload_hash:
                    backend.update_client_status(client_id, data)
                    last_payload_hash = payload_hash
            time.sleep(3)
        except Exception as e:
            log(f"Fejl i status_update_loop: {e}")
            time.sleep(2)


def chrome_status_poll_loop(backend: BackendAPI, backend_data: Dict[str, Any]) -> None:
    # Brug id først og timestamp som fallback. Så bliver gentagne ens events
    # stadig sendt, hvis de har forskellige id'er.
    last_sent_key: Optional[str] = None

    while not system_is_shutting_down:
        try:
            steps = _read_chrome_steps()
            if steps:
                last_step = steps[-1]
                step_key = str(last_step.get("id") or last_step.get("timestamp") or "")
                if step_key and step_key != last_sent_key:
                    client_id = backend_data.get("id") or read_config().get("id")
                    if client_id:
                        log(f"[POLL] Sender step={last_step.get('step')} id={last_step.get('id')} -> backend")
                        update_chrome_status_in_backend(client_id, last_step, backend)

                        step_name = last_step.get("step", "")

                        # FIX 2: Udled kun state fra steps skrevet efter servicen startede
                        derived_state = None
                        if _latest_step_is_after_startup():
                            if step_name == "system_sleep":
                                derived_state = "sleeping"
                            elif step_name == "system_wake":
                                derived_state = "normal"
                        else:
                            log(f"[POLL] Ignorerer gammelt step '{step_name}' ved state-udledning (pre-startup)")

                        payload = {
                            "chrome_status": last_step.get("message", ""),
                            "chrome_color": last_step.get("color", "black"),
                            "chrome_last_updated": _utc_now_iso(),
                            "chrome_step": step_name or None,
                        }
                        if derived_state is not None:
                            payload["state"] = derived_state

                        try:
                            backend.update_client_status(client_id, payload)
                        except Exception as e:
                            log(f"[POLL] update_client_status fejl: {e}")
                        last_sent_key = step_key
        except Exception as e:
            log(f"chrome_status_poll_loop fejl: {e}")
        time.sleep(1)


def clear_event_queue(q: queue.Queue) -> None:
    try:
        while not q.empty():
            q.get_nowait()
    except Exception:
        pass


def event_writer_loop(backend: BackendAPI, backend_data: Dict[str, Any]) -> None:
    while True:
        try:
            if event_handling_blocked.is_set():
                time.sleep(0.2)
                continue
            try:
                event = status_event_queue.get(timeout=1)
            except queue.Empty:
                continue
            if system_is_shutting_down and event.get("type") == "chrome_start":
                log("Blokerer chrome_start event under shutdown/reboot.")
                continue
            if not _HAS_CHROME_KIOSK:
                log("chrome_kiosk ikke tilgængelig — kan ikke håndtere event.")
                continue

            etype = event.get("type")
            client_id = event.get("client_id") or backend_data.get("id")
            should_clear_pca = event.get("clear_pca", False)

            # FIX 5: Dræn duplikerede chrome-events fra køen så kun ét scenario
            # køres ad gangen. Løser race condition hvor GUI og backend begge
            # sender chrome_start næsten samtidigt — det sidst udførte scenario
            # vinder og overskriver trigger-teksten med fx "gui" selvom brugeren
            # klikkede "backend".
            if etype in ("chrome_start", "chrome_kill", "chrome_urlchange"):
                drained = 0
                leftover = []
                while True:
                    try:
                        extra = status_event_queue.get_nowait()
                        extra_type = extra.get("type", "")
                        if extra_type in ("chrome_start", "chrome_kill", "chrome_urlchange"):
                            drained += 1
                            log(
                                f"event_writer_loop: drænede duplikat-event "
                                f"type={extra_type} trigger={extra.get('trigger')} "
                                f"(forhindrer dobbelt-kørsel)"
                            )
                        else:
                            leftover.append(extra)
                    except queue.Empty:
                        break
                for lo in leftover:
                    status_event_queue.put(lo)
                if drained:
                    log(f"event_writer_loop: drænede {drained} overflødigt chrome-event(s) fra køen")

            if etype == "chrome_start":
                countdown_or_starting_event.set()
                chrome_kiosk.scenario_system_start(
                    event["url"],
                    countdown=event.get("countdown", 12),
                    trigger=event.get("trigger", "system_start"),
                )
                countdown_or_starting_event.clear()
                if should_clear_pca and client_id:
                    backend.clear_pending_chrome_action(client_id)

            elif etype == "chrome_kill":
                chrome_kiosk.scenario_manual_shutdown(trigger=event.get("trigger", "manual_shutdown"))
                if should_clear_pca and client_id:
                    backend.clear_pending_chrome_action(client_id)

            elif etype == "chrome_urlchange":
                countdown_or_starting_event.set()
                chrome_kiosk.scenario_url_change(
                    event["url"],
                    countdown=event.get("countdown", 12),
                    trigger=event.get("trigger", "url_change"),
                )
                countdown_or_starting_event.clear()
                if should_clear_pca and client_id:
                    backend.clear_pending_chrome_action(client_id)

        except Exception as e:
            log(f"Fejl i event_writer_loop: {e}")
            time.sleep(1)


def chrome_stopped_callback() -> None:
    log("Watchdog: Chrome blev lukket manuelt!")
    manual_chrome_closed.set()


def config_writer_loop(backend_data: Dict[str, Any], stop_event: threading.Event) -> None:
    while not stop_event.is_set() and not system_is_shutting_down:
        backend_data["uptime"] = get_uptime()
        backend_data["last_seen"] = _utc_now_iso()
        try:
            atomic_write(CONFIG_PATH, backend_data)
        except Exception as e:
            log(f"FEJL ved write_config: {e}")
        time.sleep(CONFIG_UPDATE_INTERVAL)


def fetch_and_update_backend_config(backend: BackendAPI, backend_data: Dict[str, Any], client_id) -> None:
    backend_check = backend.fetch_backend_config(client_id)
    if backend_check is None:
        log("Kunne ikke hente config fra backend; beholder client-id.")
    elif backend_check is False:
        log("Klient-id ugyldigt i backend! Sletter id og opretter ny klient.")
        for k in ("id", "status", "kiosk_url", "locality"):
            backend_data.pop(k, None)
        atomic_write(CONFIG_PATH, backend_data)
    else:
        for key, value in backend_check.items():
            backend_data[key] = value
        backend_data["uptime"] = get_uptime()
        backend_data["last_seen"] = _utc_now_iso()
        atomic_write(CONFIG_PATH, backend_data)
        log(f"API-data hentet: location={backend_data.get('locality')}, "
            f"status={backend_data.get('status')}, kiosk_url={backend_data.get('kiosk_url')}")


# ---------------------------------------------------------------------------
# Trigger mapping for sleep/wake fra backend
# ---------------------------------------------------------------------------
def _map_source_to_trigger(action: str, source: Optional[str]) -> str:
    src = (source or "").lower()
    if src == "actionbutton":
        return "actionbutton_backend_sleep_wakeup"
    if src == "calendar":
        return "calendar_backend_sleep_wakeup"
    if action in ("wakeup", "sleep"):
        return "backend"
    return "backend"


def _handle_pending_chrome_action(
    pca: str,
    backend: BackendAPI,
    backend_data: Dict[str, Any],
    client_id: Any,
    pca_source: Optional[str],
    is_startup: bool,
) -> None:
    trigger = _map_source_to_trigger(pca, pca_source)
    log(f"pending_chrome_action='{pca}' (source={pca_source}) -> kører kiosk script (trigger={trigger}, startup={is_startup})")

    if pca == "wakeup":
        run_kiosk_script(KIOSK_WAKE_SCRIPT_PATH, "kiosk_wake", timeout=60, trigger=trigger)
    elif pca == "sleep":
        run_kiosk_script(KIOSK_SLEEP_SCRIPT_PATH, "kiosk_sleep", timeout=60, trigger=trigger)
    else:
        return

    try:
        backend_data["pending_chrome_action"] = None
        if backend_data.get("id"):
            backend.clear_pending_chrome_action(backend_data["id"])
        atomic_write(CONFIG_PATH, backend_data)
    except Exception as e:
        log(f"FEJL ved clearing pending_chrome_action: {e}")

    if pca == "wakeup":
        _schedule_reboot_after_wake(trigger=trigger, client_id=client_id, backend=backend)




def _parse_hhmm_service(value: Any) -> Optional[Tuple[int, int]]:
    """Parse HH:MM/.MM for local calendar checks used before auto-starting kiosk."""
    if value is None:
        return None
    s = str(value).strip().replace('.', ':')
    if not s:
        return None
    parts = s.split(':')
    try:
        h = int(parts[0])
        m = int(parts[1]) if len(parts) > 1 else 0
        if 0 <= h <= 23 and 0 <= m <= 59:
            return h, m
    except Exception:
        return None
    return None


def _calendar_expected_on_now() -> bool:
    """
    Returnerer True kun hvis lokal calendar_gui.json tydeligt siger,
    at dagens kalender er ON og nuværende tidspunkt ligger inden for on/off-tiden.

    Vigtigt kiosk-design:
    - Approved giver adgang og heartbeat.
    - Kalender OFF skal ikke automatisk starte Chrome/kiosk.
    - Explicit backend/GUI Start må stadig starte Chrome via pending_chrome_action/gui_event.
    """
    try:
        path = Path(CALENDAR_GUI_PATH)
        if not path.exists():
            log("[CAL] calendar_gui.json findes ikke endnu — auto-starter ikke kiosk ved approval.")
            return False
        raw = json.loads(path.read_text(encoding='utf-8'))
        if isinstance(raw, list):
            days = {str(d.get('date', '')): d for d in raw if isinstance(d, dict)}
        elif isinstance(raw, dict):
            marked = raw.get('markedDays', raw.get('days', raw))
            if isinstance(marked, list):
                days = {str(d.get('date', '')): d for d in marked if isinstance(d, dict)}
            elif isinstance(marked, dict):
                days = marked
            else:
                days = {}
        else:
            days = {}

        now = datetime.datetime.now()
        today = now.strftime('%Y-%m-%d')
        day = days.get(today) or {}
        if not isinstance(day, dict):
            return False
        if str(day.get('status', 'off')).strip().lower() != 'on':
            return False
        on_t = _parse_hhmm_service(day.get('onTime'))
        off_t = _parse_hhmm_service(day.get('offTime'))
        if not on_t or not off_t:
            return False
        start = now.replace(hour=on_t[0], minute=on_t[1], second=0, microsecond=0)
        end = now.replace(hour=off_t[0], minute=off_t[1], second=0, microsecond=0)
        if end <= start:
            return False
        return start <= now < end
    except Exception as e:
        log(f"[CAL] Kunne ikke afgøre kalenderstatus — auto-starter ikke kiosk: {e}")
        return False


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------
def main() -> None:
    global system_is_shutting_down, LAST_WAKE_REBOOT, SERVICE_STARTUP_TIME
    ensure_api_files()

    # FIX 2+3: Sæt SERVICE_STARTUP_TIME præcist ved opstart af main()
    SERVICE_STARTUP_TIME = time.time()

    log("clientflow_service.py starter op!")
    prev_status = None
    prev_url = None

    backend = BackendAPI(BASE_URL, USERNAME, PASSWORD, CLIENT_ID_ENV, CLIENT_SECRET)
    backend_data: Dict[str, Any] = read_config() or {}

    # Nye klienter installeret med enrollment har id/secret i environment.
    # Sørg for at lokal config også får id, så terminal/remote/livestream kan læse den.
    if CLIENT_ID_ENV and not (backend_data.get("id") or backend_data.get("client_id")):
        try:
            backend_data["id"] = int(CLIENT_ID_ENV)
        except Exception:
            backend_data["id"] = CLIENT_ID_ENV
        backend_data["client_id"] = backend_data["id"]
        backend_data.setdefault("status", "pending")
        backend_data["last_seen"] = _utc_now_iso()
        atomic_write(CONFIG_PATH, backend_data)

    client_id = backend_data.get("id")

    # FIX 4: Nulstil gui_event.json ved opstart — forhindrer forældede GUI-events
    # fra tidligere sessioner i at blive opfanget af gui_event_watcher og derved
    # overskrive trigger-teksten med "gui" selvom handlingen kom fra backend.
    try:
        atomic_write(GUI_EVENT_PATH, {})
        log("FIX 4: gui_event.json nulstillet ved opstart (forhindrer forældede events).")
    except Exception as e:
        log(f"FEJL ved nulstilling af gui_event ved opstart: {e}")

    try:
        if backend_data.get("state") == "sleeping":
            log("Lokal config havde state='sleeping' ved opstart — nulstiller til 'normal'.")
            backend_data["state"] = "normal"
            atomic_write(CONFIG_PATH, backend_data)
            cid = backend_data.get("id")
            if cid:
                try:
                    backend.update_client_status(cid, {"state": "normal"})
                except Exception as e:
                    log(f"FEJL ved opdatering af backend state ved opstart: {e}")
    except Exception as e:
        log(f"FEJL ved opstart-reset af state: {e}")

    # FIX 1: Ryd system_sleep fra chrome_status.json ved opstart.
    # Hvis det seneste step er system_sleep, skriv et nyt neutralt step FØR
    # trådene startes — så poll-loops ikke pusher state="sleeping" til backend.
    try:
        steps = _read_chrome_steps()
        if steps and steps[-1].get("step") == "system_sleep":
            log("chrome_status.json indeholder system_sleep som seneste step ved opstart — rydder med chrome_closed_programmatically.")
            clearing_step = {
                "step": "chrome_closed_programmatically",
                "message": "Kiosk browser lukket ved systemstart",
                "status": "closed",
                "trigger": "system_start",
                "color": "red",
                "timestamp": _utc_now_iso(),
                "id": str(uuid.uuid4()),
            }
            if _HAS_CHROME_KIOSK and hasattr(chrome_kiosk, "append_external_step"):
                try:
                    chrome_kiosk.append_external_step(clearing_step)
                    log("FIX 1: Ryddet system_sleep via chrome_kiosk.append_external_step.")
                except Exception as e:
                    log(f"FIX 1: chrome_kiosk append fejl — bruger fallback: {e}")
                    _fallback_append_status_step(clearing_step)
            else:
                _fallback_append_status_step(clearing_step)
                log("FIX 1: Ryddet system_sleep via fallback.")
    except Exception as e:
        log(f"FEJL ved FIX 1 opstart-rydning af system_sleep: {e}")

    def _force_send():
        cid = backend_data.get("id") or read_config().get("id")
        if not cid:
            return
        try:
            send_latest_status_to_backend(cid, backend)
        except Exception as e:
            log(f"FEJL i FORCE_SEND_CALLBACK: {e}")

    if _HAS_CHROME_KIOSK:
        chrome_kiosk.set_force_send_callback(_force_send)

    threading.Thread(target=input_monitor_loop, args=(backend, backend_data), daemon=True, name="input_monitor").start()
    threading.Thread(target=event_writer_loop, args=(backend, backend_data), daemon=True, name="event_writer").start()
    threading.Thread(target=gui_event_watcher, daemon=True, name="gui_event").start()
    threading.Thread(target=chrome_status_poll_loop, args=(backend, backend_data), daemon=True, name="chrome_poll").start()
    if _HAS_CHROME_KIOSK:
        try:
            chrome_kiosk.start_watchdog(on_chrome_stopped=chrome_stopped_callback, poll_interval=2)
        except Exception as e:
            log(f"start_watchdog fejlede: {e}")
    threading.Thread(target=gui_watchdog, daemon=True, name="gui_watchdog").start()

    stop_status_update = threading.Event()
    threading.Thread(target=status_update_loop, args=(backend, backend_data, stop_status_update), daemon=True, name="status_update").start()

    stop_config_writer = threading.Event()
    threading.Thread(target=config_writer_loop, args=(backend_data, stop_config_writer), daemon=True, name="config_writer").start()

    try:
        pca_startup = backend_data.get("pending_chrome_action")
        pca_source = backend_data.get("pending_chrome_action_source")
        if pca_startup == "os_update":
            _handle_pending_os_update(backend, backend_data, client_id, pca_source)
        elif pca_startup in ("wakeup", "sleep"):
            _handle_pending_chrome_action(pca_startup, backend, backend_data, client_id, pca_source, is_startup=True)
    except Exception as e:
        log(f"FEJL ved opstarts pending_chrome_action: {e}")

    if client_id:
        fetch_and_update_backend_config(backend, backend_data, client_id)

    last_backend_poll = 0.0
    last_manual_closed_log = 0.0
    last_pending_log = 0.0
    last_pca_debug_log = 0.0
    last_pca_debug_value = None
    last_pca_debug_source = None

    while True:
        try:
            now = time.time()
            client_id = backend_data.get("id")
            status = backend_data.get("status")
            url = backend_data.get("kiosk_url", "https://www.google.com/")

            if backend_data.get("pending_reboot"):
                log("pending_reboot -> rebooter.")
                block_event_handling()
                system_is_shutting_down = True
                if _HAS_CHROME_KIOSK:
                    chrome_kiosk.set_system_shutdown_flag()
                clear_event_queue(status_event_queue)
                backend_data["pending_reboot"] = False
                try:
                    backend.update_client_status(client_id, {"pending_reboot": False})
                except Exception:
                    pass
                atomic_write(CONFIG_PATH, backend_data)
                try:
                    if _HAS_CHROME_KIOSK:
                        chrome_kiosk.shutdown_chrome(trigger="pending_reboot", after_system_status=True)
                        time.sleep(5)
                        chrome_kiosk.write_system_status("system_rebooting", "pending_reboot")
                        time.sleep(5)
                    send_latest_status_to_backend(client_id, backend)
                except Exception as e:
                    log(f"Fejl under chrome shutdown: {e}")
                try_reboot()
                time.sleep(20)
                continue

            if backend_data.get("pending_shutdown"):
                log("pending_shutdown -> lukker maskinen.")
                block_event_handling()
                system_is_shutting_down = True
                if _HAS_CHROME_KIOSK:
                    chrome_kiosk.set_system_shutdown_flag()
                clear_event_queue(status_event_queue)
                backend_data["pending_shutdown"] = False
                try:
                    backend.update_client_status(client_id, {"pending_shutdown": False})
                except Exception:
                    pass
                atomic_write(CONFIG_PATH, backend_data)
                try:
                    if _HAS_CHROME_KIOSK:
                        chrome_kiosk.shutdown_chrome(trigger="pending_shutdown", after_system_status=True)
                        time.sleep(5)
                        chrome_kiosk.write_system_status("system_shutting_down", "pending_shutdown")
                        time.sleep(5)
                    send_latest_status_to_backend(client_id, backend)
                except Exception as e:
                    log(f"Fejl under chrome shutdown: {e}")
                try_shutdown()
                time.sleep(30)
                continue

            if not client_id:
                if now - last_pending_log >= 30:
                    log("Mangler client_id. Kør ClientFlow Installer og indtast en installationskode.")
                    last_pending_log = now
                backend_data.setdefault("status", "pending")
                backend_data["uptime"] = get_uptime()
                backend_data["last_seen"] = _utc_now_iso()
                atomic_write(CONFIG_PATH, backend_data)
                time.sleep(2)
                continue

            backend_check = backend.fetch_backend_config(client_id)
            if backend_check is None:
                log("Kunne ikke hente config fra backend; beholder client-id.")
            elif backend_check is False:
                # Klienten er sandsynligvis slettet i backend. Opret IKKE ny klient via gammelt admin-flow.
                # Bevar lokal config nok til at GUI kan forklare situationen, og lad teknikeren bruge
                # ClientFlow Installer -> "Indtast ny installationskode".
                if now - last_pending_log >= 30:
                    log("Klient-id findes ikke længere i backend. Indtast ny installationskode i ClientFlow Installer.")
                    last_pending_log = now
                backend_data["status"] = "pending"
                backend_data["last_seen"] = _utc_now_iso()
                atomic_write(CONFIG_PATH, backend_data)
                time.sleep(5)
                continue
            else:
                for key, value in backend_check.items():
                    backend_data[key] = value
                backend_data["uptime"] = get_uptime()
                backend_data["last_seen"] = _utc_now_iso()
                atomic_write(CONFIG_PATH, backend_data)
                url = backend_data.get("kiosk_url", "https://www.google.com/")
                status = backend_data.get("status")
                client_id = backend_data.get("id")

            if status == "pending" and now - last_pending_log >= 30:
                log("Status pending: venter på godkendelse i ClientFlow admin.")
                last_pending_log = now

            if prev_status != "approved" and status == "approved":
                if _calendar_expected_on_now():
                    log("Godkendt og kalender er ON -> systemstart-flow")
                    status_event_queue.put({
                        "type": "chrome_start",
                        "url": url,
                        "countdown": 12,
                        "trigger": "system_start",
                        "client_id": client_id,
                        "clear_pca": False,
                    })
                    manual_chrome_closed.clear()
                else:
                    log("Godkendt, men kalender er OFF/ikke aktiv endnu -> starter ikke kiosk automatisk.")
                    manual_chrome_closed.clear()
            if prev_status == "approved" and status != "approved":
                log("Ikke længere godkendt -> stop-flow")
                status_event_queue.put({
                    "type": "chrome_kill",
                    "trigger": "system_start",
                    "client_id": client_id,
                    "clear_pca": False,
                })
                manual_chrome_closed.clear()
            if status == "approved" and prev_url and url and url != prev_url:
                if _calendar_expected_on_now():
                    log(f"URL ændret: {prev_url} -> {url}")
                    status_event_queue.put({
                        "type": "chrome_urlchange",
                        "url": url,
                        "countdown": 12,
                        "trigger": "url_change",
                        "client_id": client_id,
                        "clear_pca": False,
                    })
                else:
                    log(f"URL ændret, men kalender er OFF/ikke aktiv — venter med kiosk-start: {prev_url} -> {url}")

            if status == "approved" and manual_chrome_closed.is_set():
                if now - last_manual_closed_log >= 30:
                    log("Chrome lukket manuelt. Venter på statusskift før auto-start.")
                    last_manual_closed_log = now

            if now - last_backend_poll >= BACKEND_POLL_INTERVAL:
                if client_id:
                    backend.send_heartbeat(client_id)
                last_backend_poll = now

            pca = backend_data.get("pending_chrome_action", None)
            pca_source = backend_data.get("pending_chrome_action_source")
            if pca and pca != "none":
                if (
                    pca != last_pca_debug_value
                    or pca_source != last_pca_debug_source
                    or now - last_pca_debug_log >= 30
                ):
                    log(f"[DEBUG] pending_chrome_action={pca!r} (source={pca_source!r})")
                    last_pca_debug_log = now
                    last_pca_debug_value = pca
                    last_pca_debug_source = pca_source

            if pca == "livestream_start":
                start_livestream()
                backend_data["pending_chrome_action"] = None
                try:
                    backend.update_client_status(client_id, {"pending_chrome_action": "none"})
                except Exception:
                    pass
                atomic_write(CONFIG_PATH, backend_data)

            elif pca == "livestream_stop":
                stop_livestream()
                backend_data["pending_chrome_action"] = None
                try:
                    backend.update_client_status(client_id, {"pending_chrome_action": "none"})
                except Exception:
                    pass
                atomic_write(CONFIG_PATH, backend_data)

            elif pca == "os_update":
                log("[PCA] Detekteret 'os_update' — starter ubuntu_update.py i baggrund.")
                _handle_pending_os_update(backend, backend_data, client_id, pca_source)

            elif pca == "start":
                log("[PCA] Detekteret 'start' — clearer i backend straks og kø-er chrome_start.")
                backend_data["pending_chrome_action"] = None
                atomic_write(CONFIG_PATH, backend_data)
                try:
                    backend.update_client_status(client_id, {"pending_chrome_action": "none"})
                except Exception as e:
                    log(f"FEJL ved clear pca (start): {e}")
                status_event_queue.put({
                    "type": "chrome_start",
                    "url": url,
                    "countdown": 12,
                    "trigger": "backend",
                    "client_id": client_id,
                    "clear_pca": False,
                })

            elif pca == "stop":
                log("[PCA] Detekteret 'stop' — clearer i backend straks og kø-er chrome_kill.")
                backend_data["pending_chrome_action"] = None
                atomic_write(CONFIG_PATH, backend_data)
                try:
                    backend.update_client_status(client_id, {"pending_chrome_action": "none"})
                except Exception as e:
                    log(f"FEJL ved clear pca (stop): {e}")
                status_event_queue.put({
                    "type": "chrome_kill",
                    "trigger": "backend",
                    "client_id": client_id,
                    "clear_pca": False,
                })

            elif pca in ("sleep", "wakeup"):
                _handle_pending_chrome_action(pca, backend, backend_data, client_id, pca_source, is_startup=False)

            prev_status = status
            prev_url = url
            time.sleep(0.2)
        except Exception as e:
            log(f"ERROR i hovedloop: {e}")
            time.sleep(2)


if __name__ == "__main__":
    time.sleep(5)
    main()
