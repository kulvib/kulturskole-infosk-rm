#!/usr/bin/env python3
"""
livestream.py

Optager skærm via ffmpeg x11grab og uploader korte HLS-segmenter (.ts) til backend.
Sender captured_at timestamp ved upload så backend kan skrive korrekt
EXT-X-PROGRAM-DATE-TIME i manifestet → præcis forsinkelsesmåling i frontend.

FIX: asyncio.Event() oprettes nu inde i den kørende event loop (Python 3.10+
     kræver dette — global oprettelse uden for loop gav DeprecationWarning/fejl).
"""
from pathlib import Path
import asyncio
import json
import requests
import time
import os
import sys
import subprocess
import glob
import threading
import signal
import datetime
import traceback
from typing import Optional, List


# ---------------------------------------------------------------------------
# Konfig
# ---------------------------------------------------------------------------
BASE_DIR = Path(__file__).resolve().parent
API_DIR  = BASE_DIR
API_DIR.mkdir(parents=True, exist_ok=True)

BASE_URL = os.environ.get("CLIENTFLOW_BASE_URL", "https://kulturskole-infosk-rm.onrender.com").rstrip("/")
USERNAME = os.environ.get("CLIENTFLOW_USERNAME", os.environ.get("CF_USER", ""))
PASSWORD = os.environ.get("CLIENTFLOW_PASSWORD", os.environ.get("CF_PASS", ""))
CLIENT_ID_ENV = os.environ.get("CLIENTFLOW_CLIENT_ID", os.environ.get("CF_CLIENT_ID", "")).strip()
CLIENT_SECRET = os.environ.get("CLIENTFLOW_CLIENT_SECRET", os.environ.get("CF_CLIENT_SECRET", "")).strip()

SEGMENT_LENGTH = int(os.environ.get("SEGMENT_LENGTH", "8"))
MAX_SEGMENTS   = int(os.environ.get("MAX_SEGMENTS",   "10"))
WIDTH          = int(os.environ.get("WIDTH",           "1920"))
HEIGHT         = int(os.environ.get("HEIGHT",          "1080"))
FPS            = int(os.environ.get("FPS",             "8"))
DISPLAY        = os.environ.get("DISPLAY",    ":0")
XAUTHORITY     = os.environ.get("XAUTHORITY", "/run/user/1000/gdm/Xauthority")

UPLOAD_PATH  = os.environ.get("UPLOAD_PATH",  "/api/hls/upload")
CLEANUP_PATH = os.environ.get("CLEANUP_PATH", "/api/hls/cleanup")
TOKEN_PATH   = os.environ.get("TOKEN_PATH",   "/auth/token")
CLIENT_TOKEN_PATH = os.environ.get("CLIENT_TOKEN_PATH", "/auth/client-token")

UPLOAD_URL  = BASE_URL.rstrip("/") + UPLOAD_PATH
CLEANUP_URL = BASE_URL.rstrip("/") + CLEANUP_PATH
TOKEN_URL   = BASE_URL.rstrip("/") + TOKEN_PATH
CLIENT_TOKEN_URL = BASE_URL.rstrip("/") + CLIENT_TOKEN_PATH

CONFIG_PATH  = str(API_DIR / "clientflow_config.json")
SEGMENT_DIR  = str(API_DIR / "segments")
os.makedirs(SEGMENT_DIR, exist_ok=True)

LIVESTREAM_TIMEOUT = int(os.environ.get("LIVESTREAM_TIMEOUT", "0"))

GOP = FPS * SEGMENT_LENGTH


# ---------------------------------------------------------------------------
# Logging
# ---------------------------------------------------------------------------
def _ts() -> str:
    return datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%f") + "Z"

def log(msg: str, level: str = "INFO") -> None:
    print(f"{_ts()} [{level}] {msg}")
    sys.stdout.flush()


# ---------------------------------------------------------------------------
# Token
# ---------------------------------------------------------------------------
class TokenStore:
    def __init__(self):
        self._lock       = threading.Lock()
        self._token: Optional[str] = None
        self._token_time: float    = 0
        # FIX: Reduceret TTL fra 25 min til 20 min for at undgå at overstige
        # backend JWT TTL. Giver 5 minutters buffer mod udløb.
        self._ttl = 60 * 20

    def get(self, force: bool = False) -> Optional[str]:
        with self._lock:
            if not force and self._token and (time.time() - self._token_time) < self._ttl:
                return self._token

        # Nye klienter bruger client-token fra enrollment.
        if CLIENT_ID_ENV and CLIENT_SECRET:
            try:
                resp = requests.post(
                    CLIENT_TOKEN_URL,
                    json={"client_id": int(CLIENT_ID_ENV), "client_secret": CLIENT_SECRET},
                    timeout=10,
                )
                if resp.status_code == 200:
                    tok = resp.json().get("access_token")
                    if tok:
                        with self._lock:
                            self._token      = tok
                            self._token_time = time.time()
                        log("Hentet nyt client access_token.")
                        return tok
                log(f"Kunne ikke hente client-token: {resp.status_code} {resp.text[:200]}", "WARN")
            except Exception as e:
                log(f"Client-token-fejl: {e}", "WARN")

        # Bagudkompatibel fallback til user-token.
        if not USERNAME or not PASSWORD:
            log("Token-fejl: hverken client-secret eller username/password er sat.", "WARN")
            return None
        try:
            resp = requests.post(TOKEN_URL, data={"username": USERNAME, "password": PASSWORD}, timeout=10)
            if resp.status_code == 200:
                tok = resp.json().get("access_token")
                if tok:
                    with self._lock:
                        self._token      = tok
                        self._token_time = time.time()
                    log("Hentet nyt user access_token.")
                    return tok
            log(f"Kunne ikke hente token: {resp.status_code} {resp.text[:200]}", "WARN")
        except Exception as e:
            log(f"Token-fejl: {e}", "WARN")
        return None

    def invalidate(self):
        with self._lock:
            self._token      = None
            self._token_time = 0


TOKENS = TokenStore()

def _auth_headers() -> dict:
    tok = TOKENS.get()
    return {"Authorization": f"Bearer {tok}"} if tok else {}


# ---------------------------------------------------------------------------
# client_id
# ---------------------------------------------------------------------------
def get_client_id_blocking(max_wait: int = 60) -> str:
    deadline = time.time() + max_wait
    last_log = 0.0
    while True:
        try:
            with open(CONFIG_PATH, "r", encoding="utf-8") as f:
                data = json.load(f)
                cid  = data.get("id") or data.get("client_id")
                if cid is not None:
                    return str(cid)
        except FileNotFoundError:
            pass
        except Exception as e:
            log(f"Fejl ved læsning af {CONFIG_PATH}: {e}", "WARN")

        if time.time() > deadline:
            log(f"FATAL: client_id ikke tilgængelig efter {max_wait}s.", "ERROR")
            sys.exit(1)

        if time.time() - last_log > 5:
            log(f"Venter på client_id i {CONFIG_PATH}...")
            last_log = time.time()
        time.sleep(1)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
def extract_num(filename: str) -> int:
    import re
    m = re.match(r"segment_(\d+)(?:_[^.]+)?\.(ts|mp4)$", filename)
    return int(m.group(1)) if m else -1


SEGMENT_PATTERN   = os.path.join(SEGMENT_DIR, "segment_%05d.ts")
SEGMENT_LIST_PATH = os.path.join(SEGMENT_DIR, "segment_list.txt")


# ---------------------------------------------------------------------------
# Server reset
# ---------------------------------------------------------------------------
def reset_server(client_id: str) -> None:
    try:
        reset_url = BASE_URL.rstrip("/") + f"/api/hls/{client_id}/reset"
        headers   = _auth_headers()
        r = requests.post(reset_url, headers=headers, timeout=15)
        if r.status_code == 401:
            TOKENS.invalidate()
            r = requests.post(reset_url, headers=_auth_headers(), timeout=15)
        if r.status_code == 200:
            log("Server reset OK — alle gamle segmenter slettet.")
        else:
            log(f"Server reset fejl: {r.status_code} {r.text[:200]}", "WARN")
    except Exception as e:
        log(f"Server reset exception: {e}", "WARN")


# ---------------------------------------------------------------------------
# Server cleanup
# ---------------------------------------------------------------------------
def cleanup_server_segments(client_id: str, keep_files: List[str]) -> None:
    try:
        payload = {
            "client_id":        client_id,
            "keep_files":       keep_files,
            "segment_duration": SEGMENT_LENGTH,
        }
        headers = _auth_headers()
        r = requests.post(CLEANUP_URL, json=payload, headers=headers, timeout=15)
        if r.status_code == 401:
            TOKENS.invalidate()
            r = requests.post(CLEANUP_URL, json=payload, headers=_auth_headers(), timeout=15)
        if r.status_code != 200:
            log(f"Server-cleanup fejlede ({r.status_code}): {r.text[:200]}", "WARN")
    except Exception as e:
        log(f"cleanup_server_segments fejl: {e}", "WARN")


def total_cleanup_local_and_server(client_id: str) -> None:
    removed = 0
    for pat in ("segment_*.ts", "segment_*.mp4", "index.m3u8", "segment_list.txt"):
        for f in glob.glob(os.path.join(SEGMENT_DIR, pat)):
            try:
                os.remove(f)
                removed += 1
            except Exception as e:
                log(f"Kunne ikke slette {f}: {e}", "WARN")
    log(f"Lokal cleanup: fjernede {removed} filer.")
    reset_server(client_id)


# ---------------------------------------------------------------------------
# Upload
# ---------------------------------------------------------------------------
def upload_segment(ts_path: str, ts_name: str, client_id: str, max_retries: int = 3) -> bool:
    try:
        size = os.path.getsize(ts_path)
    except Exception:
        size = 0

    try:
        mtime         = os.path.getmtime(ts_path)
        capture_start = mtime - SEGMENT_LENGTH
        captured_at   = datetime.datetime.fromtimestamp(
            capture_start, tz=datetime.timezone.utc
        ).strftime("%Y-%m-%dT%H:%M:%SZ")
    except Exception:
        captured_at = None

    log(f"Upload {ts_name} ({size / 1024:.1f} KB) captured_at={captured_at}")

    for attempt in range(max_retries):
        try:
            headers = _auth_headers()
            with open(ts_path, "rb") as fh:
                files = {"file": (ts_name, fh, "video/MP2T")}
                data  = {
                    "client_id":        client_id,
                    "segment_duration": str(SEGMENT_LENGTH),
                }
                if captured_at:
                    data["captured_at"] = captured_at

                t0 = time.time()
                r  = requests.post(UPLOAD_URL, files=files, data=data, headers=headers, timeout=60)
                elapsed = time.time() - t0

            if r.status_code == 401:
                log("Upload 401 — fornyer token.", "WARN")
                TOKENS.invalidate()
                continue
            if r.status_code == 200:
                log(f"Upload OK ({elapsed:.2f}s)")
                return True
            log(f"Upload fejlede ({r.status_code}): {r.text[:300]}", "WARN")
        except Exception as e:
            log(f"Upload exception: {e}", "WARN")
        if attempt < max_retries - 1:
            time.sleep(2)

    log(f"Upload fejlede efter {max_retries} forsøg.", "ERROR")
    return False


# ---------------------------------------------------------------------------
# ffmpeg recorder
# ---------------------------------------------------------------------------
class FfmpegRecorder:
    def __init__(self):
        self._proc: Optional[subprocess.Popen] = None
        self._lock = threading.Lock()

    def start(self) -> bool:
        cmd = [
            "ffmpeg", "-y", "-loglevel", "warning",
            "-f", "x11grab",
            "-framerate", str(FPS),
            "-video_size", f"{WIDTH}x{HEIGHT}",
            "-i", f"{DISPLAY}.0",
            "-f", "lavfi",
            "-i", "anullsrc=channel_layout=stereo:sample_rate=44100",
            "-c:v", "libx264",
            "-preset", "veryfast",
            "-tune", "zerolatency",
            "-b:v", "800K",
            "-maxrate", "800K",
            "-bufsize", "1.6M",
            "-pix_fmt", "yuv420p",
            "-g", str(GOP),
            "-keyint_min", str(GOP),
            "-force_key_frames", f"expr:gte(t,n_forced*{SEGMENT_LENGTH})",
            "-c:a", "aac",
            "-ar", "44100",
            "-f", "segment",
            "-segment_time", str(SEGMENT_LENGTH),
            "-segment_format", "mpegts",
            "-segment_list", SEGMENT_LIST_PATH,
            "-segment_list_type", "flat",
            "-segment_list_flags", "+live",
            "-reset_timestamps", "1",
            SEGMENT_PATTERN,
        ]

        env = {**os.environ, "DISPLAY": DISPLAY, "XAUTHORITY": XAUTHORITY}
        log(f"Starter ffmpeg x11grab ({WIDTH}x{HEIGHT}@{FPS}fps, seg={SEGMENT_LENGTH}s, GOP={GOP}, bitrate=800K)")

        try:
            self._proc = subprocess.Popen(
                cmd, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE, env=env,
            )
            time.sleep(2)
            if self._proc.poll() is not None:
                stderr = self._proc.stderr.read().decode("utf-8", errors="ignore")
                log(f"ffmpeg stoppede med det samme (rc={self._proc.returncode}):\n{stderr[:1000]}", "ERROR")
                return False
            log(f"ffmpeg kører med PID={self._proc.pid}")
            return True
        except FileNotFoundError:
            log("ffmpeg ikke fundet — kør: sudo apt install ffmpeg", "ERROR")
            return False
        except Exception as e:
            log(f"Kunne ikke starte ffmpeg: {e}", "ERROR")
            return False

    def is_running(self) -> bool:
        return self._proc is not None and self._proc.poll() is None

    def stop(self) -> None:
        with self._lock:
            if self._proc and self._proc.poll() is None:
                log("Stopper ffmpeg (SIGTERM)...")
                try:
                    self._proc.terminate()
                    self._proc.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    log("ffmpeg reagerede ikke — SIGKILL.", "WARN")
                    try: self._proc.kill(); self._proc.wait(timeout=3)
                    except Exception: pass
                except Exception as e:
                    log(f"Fejl ved stop: {e}", "WARN")
                log("ffmpeg stoppet.")
            self._proc = None

    def drain_stderr(self) -> None:
        if not self._proc or not self._proc.stderr:
            return
        try:
            import select as _sel
            while True:
                r, _, _ = _sel.select([self._proc.stderr], [], [], 0)
                if not r: break
                line = self._proc.stderr.readline()
                if not line: break
                decoded = line.decode("utf-8", errors="ignore").rstrip()
                if decoded:
                    log(f"[ffmpeg] {decoded}", "WARN")
        except Exception:
            pass


# ---------------------------------------------------------------------------
# Segment uploader
# ---------------------------------------------------------------------------
async def segment_uploader(client_id: str, recorder: FfmpegRecorder, stop_event: asyncio.Event) -> None:
    log("segment_uploader starter.")
    uploaded: set     = set()
    last_stderr_drain = time.time()

    while not stop_event.is_set():
        if time.time() - last_stderr_drain > 10:
            recorder.drain_stderr()
            last_stderr_drain = time.time()

        if not recorder.is_running():
            log("ffmpeg stoppede uventet!", "ERROR")
            stop_event.set()
            break

        if not os.path.exists(SEGMENT_LIST_PATH):
            await asyncio.sleep(0.5)
            continue

        try:
            with open(SEGMENT_LIST_PATH, "r", encoding="utf-8") as f:
                lines = [l.strip() for l in f if l.strip()]
        except Exception as e:
            log(f"Fejl ved læsning af segment_list: {e}", "WARN")
            await asyncio.sleep(0.5)
            continue

        ready = lines[:-1] if len(lines) > 1 else []

        for seg_name in ready:
            if seg_name in uploaded:
                continue
            seg_path = os.path.join(SEGMENT_DIR, seg_name)
            if not os.path.exists(seg_path):
                continue
            try:
                seg_size = os.path.getsize(seg_path)
            except Exception:
                continue
            if seg_size < 1000:
                log(f"Segment {seg_name} for lille ({seg_size}B) — springer over.", "WARN")
                uploaded.add(seg_name)
                continue

            ok = await asyncio.to_thread(upload_segment, seg_path, seg_name, client_id)
            if ok:
                uploaded.add(seg_name)
                try:
                    all_ts    = sorted(
                        [f for f in os.listdir(SEGMENT_DIR) if f.endswith(".ts")],
                        key=extract_num,
                    )
                    keep_segs = all_ts[-MAX_SEGMENTS:]
                    await asyncio.to_thread(cleanup_server_segments, client_id, keep_segs)
                    for old_seg in all_ts:
                        if old_seg not in keep_segs:
                            try: os.remove(os.path.join(SEGMENT_DIR, old_seg))
                            except Exception: pass
                except Exception as e:
                    log(f"Cleanup fejl: {e}", "WARN")

        await asyncio.sleep(0.5)

    log("segment_uploader stoppet.")


# ---------------------------------------------------------------------------
# Shutdown
# ---------------------------------------------------------------------------
# FIX: shutdown_event oprettes ikke længere som global variabel uden for event
# loop. I Python 3.10+ skal asyncio-primitiver (Event, Lock osv.) altid oprettes
# inde i en kørende event loop — ellers gives DeprecationWarning i 3.10 og
# RuntimeError i fremtidige versioner.
# shutdown_event flyttes nu ind i main() og signalhåndteringen opdateres tilsvarende.

_main_loop: Optional[asyncio.AbstractEventLoop] = None
_shutdown_event: Optional[asyncio.Event] = None


def signal_handler(signum, frame):
    log(f"Modtog signal {signum} — nedlukning.")
    # FIX: Bruger nu _shutdown_event der er oprettet inde i event loop
    if _main_loop and _main_loop.is_running() and _shutdown_event is not None:
        try:
            _main_loop.call_soon_threadsafe(_shutdown_event.set)
        except Exception:
            pass


def timeout_shutdown():
    log("Timeout nået — nedlukning.")
    # FIX: Samme fix som signal_handler — bruger loop-bundet event
    if _main_loop and _main_loop.is_running() and _shutdown_event is not None:
        try:
            _main_loop.call_soon_threadsafe(_shutdown_event.set)
        except Exception:
            pass


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------
async def main():
    global _main_loop, _shutdown_event

    _main_loop = asyncio.get_running_loop()

    # FIX: asyncio.Event() oprettes nu inde i den kørende event loop.
    # Tidligere var den global og blev oprettet ved modul-import uden for en
    # event loop, hvilket giver DeprecationWarning i Python 3.10+ og kan
    # føre til RuntimeError i fremtidige Python-versioner.
    _shutdown_event = asyncio.Event()

    client_id = get_client_id_blocking(max_wait=60)
    log(f"CLIENT_ID={client_id}")

    recorder = FfmpegRecorder()
    if not recorder.start():
        log("Kunne ikke starte ffmpeg — afslutter.", "ERROR")
        sys.exit(1)

    stop_event    = asyncio.Event()
    uploader_task = asyncio.create_task(
        segment_uploader(client_id, recorder, stop_event),
        name="segment_uploader"
    )
    shutdown_task = asyncio.create_task(
        _shutdown_event.wait(),
        name="shutdown"
    )

    await asyncio.wait({uploader_task, shutdown_task}, return_when=asyncio.FIRST_COMPLETED)

    log("Stopper alle tasks...")
    stop_event.set()
    if not uploader_task.done():
        uploader_task.cancel()
    if not shutdown_task.done():
        shutdown_task.cancel()
    await asyncio.gather(uploader_task, shutdown_task, return_exceptions=True)

    recorder.stop()

    log("Kører cleanup...")
    try:
        total_cleanup_local_and_server(client_id)
    except Exception as e:
        log(f"Cleanup-fejl: {e}", "WARN")


# ---------------------------------------------------------------------------
# Entry
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    log(f"livestream.py starter ({WIDTH}x{HEIGHT}@{FPS}fps, seg={SEGMENT_LENGTH}s, GOP={GOP}, bitrate=800K, display={DISPLAY})")

    try:
        cfg = json.loads(Path(CONFIG_PATH).read_text(encoding="utf-8"))
        cid = str(cfg.get("id") or cfg.get("client_id") or "unknown")
        total_cleanup_local_and_server(cid)
    except Exception as e:
        log(f"Initial cleanup-fejl: {e}", "WARN")

    signal.signal(signal.SIGTERM, signal_handler)
    signal.signal(signal.SIGINT,  signal_handler)

    timer = None
    if LIVESTREAM_TIMEOUT > 0:
        timer = threading.Timer(LIVESTREAM_TIMEOUT, timeout_shutdown)
        timer.daemon = True
        timer.start()
        log(f"Auto-shutdown timer sat til {LIVESTREAM_TIMEOUT}s")

    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        log("KeyboardInterrupt — nedlukning.")
    finally:
        if timer:
            timer.cancel()

    log("livestream.py exit.")
    sys.exit(0)
