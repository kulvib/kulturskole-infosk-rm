#!/usr/bin/env python3
"""
status_utils.py

Hjælpe-module for ClientFlow scripts:
 - Append-baseret logging til clientflow_service.log med automatisk rotation
 - Trådsikker læsning/skrivning af chrome_status.json
 - Atomisk skrivning med unik tmp-fil pr. proces (race-safe)
 - Helper til at appende et enkelt step til chrome_status.json med dedup
"""
from pathlib import Path
import json
import datetime
import os
import sys
import threading
import uuid
from typing import Any, Dict, List, Optional

API_DIR = Path(__file__).resolve().parent

SERVICE_LOG = API_DIR / "clientflow_service.log"
CHROME_STATUS = API_DIR / "chrome_status.json"

# Maks log-størrelse før rotation (1 MB)
MAX_LOG_BYTES = int(os.environ.get("CLIENTFLOW_MAX_LOG_BYTES", str(1 * 1024 * 1024)))
# Hvor meget af loggen vi beholder ved rotation (50%)
LOG_KEEP_BYTES = MAX_LOG_BYTES // 2

# Tail-læsning: maks bytes vi læser bagfra
TAIL_READ_BYTES = 64 * 1024  # 64 KB

_log_lock = threading.RLock()
_status_lock = threading.RLock()


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
def _now_iso() -> str:
    return datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%f") + "Z"


def _warn(msg: str) -> None:
    """Skriv warning til stderr."""
    try:
        print(f"[status_utils WARN] {msg}", file=sys.stderr)
    except Exception:
        pass


def _atomic_write(path: Path, text: str) -> bool:
    """Skriv text atomisk. Returnerer True ved succes."""
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        tmp = path.with_name(f"{path.name}.tmp.{os.getpid()}.{uuid.uuid4().hex[:8]}")
        tmp.write_text(text, encoding="utf-8")
        os.replace(str(tmp), str(path))
        return True
    except Exception as e:
        _warn(f"_atomic_write fejlede for {path}: {e}")
        try:
            path.write_text(text, encoding="utf-8")
            return True
        except Exception as e2:
            _warn(f"_atomic_write fallback fejlede for {path}: {e2}")
            return False


# ---------------------------------------------------------------------------
# Logging
# ---------------------------------------------------------------------------
def _rotate_log_if_needed() -> None:
    """Hvis SERVICE_LOG > MAX_LOG_BYTES, trim til LOG_KEEP_BYTES (behold sidste del)."""
    try:
        if not SERVICE_LOG.exists():
            return
        size = SERVICE_LOG.stat().st_size
        if size <= MAX_LOG_BYTES:
            return
        # Læs sidste LOG_KEEP_BYTES bytes
        with SERVICE_LOG.open("rb") as f:
            f.seek(-LOG_KEEP_BYTES, os.SEEK_END)
            tail = f.read()
        # Spring til næste linjeskift så vi ikke deler en linje midt over
        nl = tail.find(b"\n")
        if 0 <= nl < len(tail) - 1:
            tail = tail[nl + 1:]
        # Skriv tilbage atomisk
        try:
            text = tail.decode("utf-8", errors="replace")
            _atomic_write(SERVICE_LOG, text)
        except Exception as e:
            _warn(f"log rotation skrivning fejlede: {e}")
    except Exception as e:
        _warn(f"_rotate_log_if_needed fejlede: {e}")


def log(msg: str) -> None:
    """
    Append en linje til clientflow_service.log. Trådsikker.
    Roterer automatisk hvis filen vokser for stor.
    """
    line = f"{_now_iso()} - {msg}\n"
    with _log_lock:
        try:
            SERVICE_LOG.parent.mkdir(parents=True, exist_ok=True)
            with SERVICE_LOG.open("a", encoding="utf-8") as f:
                f.write(line)
                f.flush()
            _rotate_log_if_needed()
        except Exception as e:
            _warn(f"log skrivning fejlede: {e}")
            try:
                print(line, end="")
            except Exception:
                pass


def tail_log(n: int = 200) -> List[str]:
    """
    Returnér de sidste n linjer fra service-loggen.
    Læser efficient kun de sidste ~64 KB i stedet for hele filen.
    """
    try:
        with _log_lock:
            if not SERVICE_LOG.exists():
                return []
            size = SERVICE_LOG.stat().st_size
            with SERVICE_LOG.open("rb") as f:
                if size > TAIL_READ_BYTES:
                    f.seek(-TAIL_READ_BYTES, os.SEEK_END)
                else:
                    f.seek(0)
                data = f.read()
            text = data.decode("utf-8", errors="replace")
            lines = text.splitlines()
            # Hvis vi har læst midt i en linje (pga. seek), drop første ufuldstændige
            if size > TAIL_READ_BYTES and lines:
                lines = lines[1:]
            return lines[-n:]
    except Exception as e:
        _warn(f"tail_log fejlede: {e}")
        return []


# ---------------------------------------------------------------------------
# chrome_status.json
# ---------------------------------------------------------------------------
def read_status() -> Dict[str, Any]:
    """
    Læs chrome_status.json. Returnerer altid en dict med 'steps' og 'chrome_running'.
    """
    default: Dict[str, Any] = {"steps": [], "chrome_running": False}
    with _status_lock:
        if not CHROME_STATUS.exists():
            return default
        try:
            data = json.loads(CHROME_STATUS.read_text(encoding="utf-8"))
            if not isinstance(data, dict):
                _warn("chrome_status.json indeholder ikke en dict.")
                return default
            data.setdefault("steps", [])
            data.setdefault("chrome_running", False)
            return data
        except json.JSONDecodeError as e:
            _warn(f"chrome_status.json er ugyldig JSON: {e}")
            return default
        except Exception as e:
            _warn(f"Kunne ikke læse chrome_status.json: {e}")
            return default


def update_status_file(status: Dict[str, Any]) -> bool:
    """Skriv hele status dict atomisk. Returnerer True ved succes."""
    if not isinstance(status, dict):
        _warn(f"update_status_file modtog ikke dict (type={type(status).__name__}).")
        return False
    with _status_lock:
        text = json.dumps(status, ensure_ascii=False, indent=2)
        return _atomic_write(CHROME_STATUS, text)


def append_chrome_step(step: Dict[str, Any], max_steps: int = 50) -> bool:
    """
    Append et enkelt step til chrome_status.json's 'steps' array.
    - Sikrer at step har 'timestamp' og 'id'
    - Dedup på (id, step) for at undgå dubletter
    - Beholder kun de sidste 'max_steps' i listen

    Returnerer True ved succes.
    """
    if not isinstance(step, dict):
        _warn(f"append_chrome_step modtog ikke dict (type={type(step).__name__}).")
        return False

    # Lav copy så vi ikke muterer caller's dict
    step = dict(step)
    step.setdefault("timestamp", _now_iso())
    step.setdefault("id", str(uuid.uuid4()))
    step.setdefault("trigger", "backend")
    step.setdefault("color", "black")

    with _status_lock:
        data = read_status()
        steps = data.get("steps", [])
        if not isinstance(steps, list):
            steps = []

        # Dedup: skip hvis id allerede findes
        new_id = step.get("id")
        if new_id and any(s.get("id") == new_id for s in steps):
            return True  # silent dedup

        # Eller dedup på (timestamp, step) hvis der ikke er id
        if not new_id:
            new_ts = step.get("timestamp")
            new_step_name = step.get("step")
            if any(s.get("timestamp") == new_ts and s.get("step") == new_step_name for s in steps):
                return True

        steps.append(step)
        data["steps"] = steps[-max_steps:]
        return update_status_file(data)


def ensure_status_defaults() -> None:
    """
    Sikr at chrome_status.json findes og har {steps: [], chrome_running: false}.
    Kald ved opstart af scripts.
    """
    with _status_lock:
        if not CHROME_STATUS.exists():
            update_status_file({"steps": [], "chrome_running": False})


def get_latest_step() -> Optional[Dict[str, Any]]:
    """Returnér det sidste step (eller None hvis ingen)."""
    data = read_status()
    steps = data.get("steps", [])
    if not isinstance(steps, list) or not steps:
        return None
    last = steps[-1]
    return last if isinstance(last, dict) else None


def get_latest_step_name() -> Optional[str]:
    """Returnér step-navn på sidste step (fx 'system_sleep') eller None."""
    last = get_latest_step()
    return last.get("step") if last else None


# ---------------------------------------------------------------------------
# Selvtest
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    ensure_status_defaults()
    log("status_utils: selvtest startet")

    print(f"Service log: {SERVICE_LOG}")
    print(f"Chrome status: {CHROME_STATUS}")
    print(f"Max log bytes: {MAX_LOG_BYTES}")

    print("\nSidste 5 log-linjer:")
    for l in tail_log(5):
        print(f"  {l}")

    print("\nSelvtest OK")
