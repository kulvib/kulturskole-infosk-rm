#!/usr/bin/env python3
"""
kiosk_sleep.py

Sæt kiosk-klienten i "sleep" (ikke system suspend) uden at lukke GUI eller livestream:
 - Stop/kill alle browsere (Chrome/Chromium/Firefox/Edge/Brave/Opera/Vivaldi)
 - (Valgfrit) behold livestream-processer kørende (env: ALLOW_LIVESTREAM)
 - Sluk skærmen (xset DPMS -> HDMI-CEC fallback)
 - Opdatér lokal kiosk_sleep_config.json state -> "sleeping"
 - Append step til kiosk_sleep_status.json OG forsøg at skrive system_sleep til chrome_status.json
 - Vent op til 5s for at sikre alle Chrome-processer er væk
 - Kør 5s countdown før DPMS-sluk
 - Bekræft at system_sleep er landet i chrome_status.json (id-match) før marker fjernes

Trigger udledes fra env KIOSK_TRIGGER (sat af clientflow_service), ellers
CLIENTFLOW_TRIGGER, ellers "backend".
"""
from pathlib import Path
import json
import time
import os
import sys
import re
import subprocess
import psutil
import uuid
import datetime
from shutil import which
from typing import Any, Dict, List, Optional, Tuple

API_DIR = Path(__file__).resolve().parent

SLEEP_CONFIG_PATH = API_DIR / "kiosk_sleep_config.json"
SLEEP_STATUS_PATH = API_DIR / "kiosk_sleep_status.json"
LOG_PATH = API_DIR / "kiosk_sleep.log"
CHROME_STATUS_PATH = API_DIR / "chrome_status.json"
SLEEP_MARKER = API_DIR / ".pending_system_sleep"

DISPLAY = os.environ.get("DISPLAY", ":0")
XAUTH = os.environ.get("XAUTHORITY", "/run/user/1000/gdm/Xauthority")
CEC_CLIENT_CMD = "cec-client"

ALLOW_LIVESTREAM = os.environ.get("ALLOW_LIVESTREAM", "true").lower() in ("1", "true", "yes", "y")

# Trigger der bruges i alle status-steps
TRIGGER = os.environ.get("KIOSK_TRIGGER", os.environ.get("CLIENTFLOW_TRIGGER", "backend"))

# Browsers vi vil lukke. Brug regex word-boundary for at undgå false positives
BROWSER_PATTERNS = [
    r"\bchrome\b", r"\bchromium\b", r"\bchromium-browser\b",
    r"\bfirefox\b", r"\bmicrosoft-edge\b", r"\bedge\b",
    r"\bbrave\b", r"\bvivaldi\b", r"\bopera\b",
]
_BROWSER_RE = re.compile("|".join(BROWSER_PATTERNS), re.IGNORECASE)

# Processer vi ALDRIG må dræbe
SAFELIST_KEYWORDS = [
    "systemd", "dbus", "init", "xorg", "xwayland", "wayland",
    "pulseaudio", "pipewire", "networkmanager", "sshd",
    "rsyslog", "journald", "cron", "login", "gdm", "lightdm", "sddm",
]

if ALLOW_LIVESTREAM:
    SAFELIST_KEYWORDS.extend(["ffmpeg", "livestream.py", "livestream"])


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
def now_iso() -> str:
    return datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%f") + "Z"


def log(msg: str) -> None:
    line = f"{now_iso()} - kiosk_sleep: {msg}\n"
    try:
        with open(LOG_PATH, "a", encoding="utf-8") as f:
            f.write(line)
    except Exception:
        try:
            print(line, end="")
        except Exception:
            pass


def _atomic_write(path: Path, obj: Any) -> None:
    # FIX: Bruger nu unik tmp-fil pr. proces for at undgå race conditions
    try:
        if not isinstance(path, Path):
            path = Path(path)
        if not isinstance(obj, (dict, list)):
            log(f"ADVARSEL: ikke-json-objekt af type {type(obj)} til {path}; wrapper.")
            obj = {"value": str(obj)}
        text = json.dumps(obj, ensure_ascii=False, indent=2)
        path.parent.mkdir(parents=True, exist_ok=True)
        tmp = path.with_name(f"{path.name}.tmp.{os.getpid()}.{uuid.uuid4().hex[:8]}")
        tmp.write_text(text, encoding="utf-8")
        os.replace(str(tmp), str(path))
    except Exception as e:
        log(f"FEJL i _atomic_write til {path}: {e}")
        try:
            path.write_text(json.dumps(obj, ensure_ascii=False, indent=2), encoding="utf-8")
        except Exception as e2:
            log(f"FEJL fallback write til {path}: {e2}")


def read_config() -> Dict[str, Any]:
    try:
        if SLEEP_CONFIG_PATH.exists():
            data = json.loads(SLEEP_CONFIG_PATH.read_text(encoding="utf-8"))
            if isinstance(data, dict):
                return data
            log(f"ADVARSEL: {SLEEP_CONFIG_PATH.name} er ikke en dict; ignorerer.")
    except Exception as e:
        log(f"FEJL read_config: {e}")
    return {}


def write_config(cfg: Dict[str, Any]) -> None:
    if not isinstance(cfg, dict):
        cfg = {"state": str(cfg)}
    _atomic_write(SLEEP_CONFIG_PATH, cfg)


def append_sleep_step(step: Dict[str, Any]) -> None:
    if not isinstance(step, dict):
        step = {"message": str(step), "timestamp": now_iso()}
    step.setdefault("timestamp", now_iso())
    step.setdefault("id", str(uuid.uuid4()))

    try:
        data: Dict[str, Any] = {"steps": [], "kiosk_sleep_running": False}
        if SLEEP_STATUS_PATH.exists():
            try:
                existing = json.loads(SLEEP_STATUS_PATH.read_text(encoding="utf-8"))
                if isinstance(existing, dict):
                    data = existing
            except Exception:
                log(f"FEJL: kunne ikke læse {SLEEP_STATUS_PATH.name}, nulstiller.")
        steps = data.get("steps", [])
        if not isinstance(steps, list):
            steps = []
        steps.append(step)
        data["steps"] = steps[-50:]
        running = any("chrome" in (p.info.get("name") or "").lower() for p in psutil.process_iter(["name"]))
        data["kiosk_sleep_running"] = running
        _atomic_write(SLEEP_STATUS_PATH, data)
    except Exception as e:
        log(f"FEJL ved append_sleep_step: {e}")


# ---------------------------------------------------------------------------
# Display power
# ---------------------------------------------------------------------------
def try_xset_dpms_off() -> bool:
    env = {**os.environ, "DISPLAY": DISPLAY, "XAUTHORITY": XAUTH}
    try:
        subprocess.run(
            ["xset", "dpms", "force", "off"],
            env=env, timeout=5, check=True,
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
        )
        log("Skærmen slukket via xset DPMS.")
        return True
    except Exception as e:
        log(f"xset DPMS off fejlede: {e}")
        return False


def try_cec_standby() -> bool:
    if not which(CEC_CLIENT_CMD):
        log("cec-client ikke installeret, springer HDMI-CEC standby over.")
        return False
    p = None
    try:
        p = subprocess.Popen(
            [CEC_CLIENT_CMD, "-s", "-d", "1"],
            stdin=subprocess.PIPE, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
        )
        time.sleep(0.3)
        try:
            if p.stdin:
                p.stdin.write(b"standby 0\n")
                p.stdin.flush()
        except Exception as e:
            log(f"Kunne ikke skrive til cec-client stdin: {e}")
        time.sleep(0.5)
        log("Skærmen forsøgt slukket via HDMI-CEC.")
        return True
    except Exception as e:
        log(f"cec-client standby fejlede: {e}")
        return False
    finally:
        if p:
            try:
                if p.stdin:
                    p.stdin.close()
            except Exception:
                pass
            try:
                p.terminate()
                p.wait(timeout=2)
            except Exception:
                try:
                    p.kill()
                except Exception:
                    pass


# ---------------------------------------------------------------------------
# Browser-process killing
# ---------------------------------------------------------------------------
def _is_safe_to_kill(proc: psutil.Process) -> bool:
    try:
        if proc.pid in (0, 1):
            return False
        name = (proc.name() or "").lower()
        try:
            cmd = " ".join(proc.cmdline() or []).lower()
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            cmd = ""
        for s in SAFELIST_KEYWORDS:
            if s.lower() in name or s.lower() in cmd:
                return False
        return True
    except Exception:
        return False


def _matches_browser(name: str, cmdline: str) -> bool:
    return bool(_BROWSER_RE.search(name) or _BROWSER_RE.search(cmdline))


def shutdown_browsers_only(trigger: str = "sleep", wait: float = 3.0) -> List[Tuple[int, str, str]]:
    results: List[Tuple[int, str, str]] = []

    # Forsøg pænt shutdown via chrome_kiosk først
    try:
        import chrome_kiosk  # type: ignore
        try:
            chrome_kiosk.scenario_manual_shutdown(trigger=trigger)
            log("chrome_kiosk.scenario_manual_shutdown kaldt for pæn chrome-shutdown.")
        except Exception as e:
            log(f"chrome_kiosk shutdown fejl (ignored): {e}")
    except Exception:
        log("chrome_kiosk ikke tilgængelig — bruger ren psutil fallback.")

    # Kør derefter generel browser-kill
    for proc in psutil.process_iter(["pid", "name", "cmdline"]):
        try:
            pid = proc.info.get("pid")
            name = (proc.info.get("name") or "").lower()
            try:
                cmdline = " ".join(proc.info.get("cmdline") or []).lower()
            except Exception:
                cmdline = ""
            if not _matches_browser(name, cmdline):
                continue
            display_name = name or cmdline
            if not _is_safe_to_kill(proc):
                results.append((pid, display_name, "skipped_safe"))
                continue
            try:
                proc.terminate()
                results.append((pid, display_name, "term"))
                log(f"Sendt SIGTERM til pid={pid} ({display_name})")
            except Exception as e:
                log(f"SIGTERM fejlede for pid={pid}: {e}")
                results.append((pid, display_name, "term_failed"))
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            continue
        except Exception as e:
            log(f"Fejl ved process-iteration: {e}")
            continue

    # Vent på terminate
    deadline = time.time() + wait
    while time.time() < deadline:
        any_still = False
        for pid, _, action in results:
            if action != "term":
                continue
            if psutil.pid_exists(pid):
                try:
                    if psutil.Process(pid).is_running():
                        any_still = True
                        break
                except Exception:
                    continue
        if not any_still:
            break
        time.sleep(0.2)

    # SIGKILL eventuelle resterende
    for i, (pid, display_name, action) in enumerate(list(results)):
        if action != "term":
            continue
        try:
            if psutil.pid_exists(pid):
                p = psutil.Process(pid)
                if p.is_running():
                    p.kill()
                    results[i] = (pid, display_name, "killed")
                    log(f"Sendt SIGKILL til pid={pid} ({display_name})")
                else:
                    results[i] = (pid, display_name, "gone")
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            results[i] = (pid, display_name, "gone_or_denied")
        except Exception as e:
            log(f"SIGKILL fejlede for pid={pid}: {e}")
            results[i] = (pid, display_name, "kill_failed")

    return results


def shutdown_chrome_compat(trigger: str = "sleep") -> None:
    try:
        res = shutdown_browsers_only(trigger=trigger, wait=3.0)
    except Exception as e:
        log(f"FEJL i shutdown_browsers_only: {e}")
        res = []
    stopped = [(p, n, a) for p, n, a in res if a in ("term", "killed")]
    skipped = [(p, n, a) for p, n, a in res if a.startswith("skipped") or a in ("term_failed", "kill_failed", "gone_or_denied")]
    msg = {
        "step": "system_sleep_process_report",
        "message": f"Stopped {len(stopped)} browser processes, skipped {len(skipped)} processes.",
        "stopped": [{"pid": p, "proc": n, "action": a} for p, n, a in stopped],
        "skipped": [{"pid": p, "proc": n, "action": a} for p, n, a in skipped],
        "trigger": TRIGGER,
        "timestamp": now_iso(),
        "color": "blue",
    }
    append_sleep_step(msg)
    log(f"shutdown_chrome_compat: {msg['message']}")


def wait_for_chrome_exit(timeout: float = 5.0, poll: float = 0.2) -> bool:
    log(f"Venter op til {timeout:.1f}s på at chrome-processer stopper...")
    deadline = time.time() + timeout
    while time.time() < deadline:
        found = False
        for p in psutil.process_iter(["name"]):
            try:
                name = (p.info.get("name") or "").lower()
                if name in ("chrome", "chromium", "chromium-browser", "google-chrome", "google-chrome-stable"):
                    found = True
                    break
            except Exception:
                continue
        if not found:
            log("Ingen chrome-processer fundet.")
            return True
        time.sleep(poll)
    log(f"Timeout ({timeout:.1f}s): chrome-processer stadig til stede.")
    return False


# ---------------------------------------------------------------------------
# Countdown og chrome_status integration
# ---------------------------------------------------------------------------
def write_chrome_status_step(step: Dict[str, Any]) -> None:
    """Forsøg at notify chrome_status.json så backend ser sleep/wake."""
    try:
        import chrome_kiosk  # type: ignore
        try:
            if hasattr(chrome_kiosk, "append_external_step"):
                chrome_kiosk.append_external_step(step)
                log("Brugte chrome_kiosk.append_external_step (id-preserving).")
                return
            if step.get("step") == "system_sleep" and hasattr(chrome_kiosk, "mark_system_sleep"):
                chrome_kiosk.mark_system_sleep(trigger=step.get("trigger", "backend"))
                log("Brugte chrome_kiosk.mark_system_sleep (fallback).")
                return
            if hasattr(chrome_kiosk, "write_system_status"):
                chrome_kiosk.write_system_status(step.get("step"), step.get("trigger", "backend"))
                log("Brugte chrome_kiosk.write_system_status (fallback).")
                return
            if hasattr(chrome_kiosk, "write_step"):
                chrome_kiosk.write_step(
                    step.get("step"), step.get("trigger", "backend"),
                    status=step.get("status"), url=step.get("url"),
                )
                log("Brugte chrome_kiosk.write_step (fallback).")
                return
        except Exception as e:
            log(f"chrome_kiosk helper-fejl: {e}")
    except Exception:
        log("chrome_kiosk ikke tilgængelig; lokal fallback.")

    # Lokal fallback append
    try:
        data: Dict[str, Any] = {"steps": [], "chrome_running": False}
        if CHROME_STATUS_PATH.exists():
            try:
                existing = json.loads(CHROME_STATUS_PATH.read_text(encoding="utf-8"))
                if isinstance(existing, dict):
                    data = existing
            except Exception as e:
                log(f"Kunne ikke læse chrome_status.json: {e}")
        steps = data.get("steps", [])
        if not isinstance(steps, list):
            steps = []
        s = {
            "step": step.get("step"),
            "message": step.get("message"),
            "status": step.get("status", ""),
            "trigger": step.get("trigger", "backend"),
            "color": step.get("color", "black"),
            "timestamp": step.get("timestamp", now_iso()),
            "id": step.get("id", str(uuid.uuid4())),
        }
        steps.append(s)
        data["steps"] = steps[-50:]
        if "chrome_running" in step:
            data["chrome_running"] = bool(step.get("chrome_running"))
        _atomic_write(CHROME_STATUS_PATH, data)
        log("Appended system_sleep til chrome_status.json (fallback).")
    except Exception as e:
        log(f"FEJL ved fallback skriv til chrome_status.json: {e}")


def countdown_before_sleep(seconds: int = 5, trigger: str = "backend") -> None:
    log(f"Starter countdown på {seconds} sekunder før dvale (trigger={trigger}).")
    used_chrome_kiosk = False
    try:
        import chrome_kiosk  # type: ignore
        if hasattr(chrome_kiosk, "write_step"):
            used_chrome_kiosk = True
    except Exception:
        chrome_kiosk = None  # type: ignore

    for i in range(seconds, 0, -1):
        try:
            msg_text = f"Starter dvale om {i} sekund" + ("" if i == 1 else "er")
            step = {
                "step": "countdown",
                "message": msg_text,
                "status": "waiting",
                "trigger": trigger,
                "color": "orange",
                "timestamp": now_iso(),
                "id": str(uuid.uuid4()),
                "extra": i,
            }
            if used_chrome_kiosk:
                try:
                    chrome_kiosk.append_external_step(step)  # type: ignore
                except Exception:
                    write_chrome_status_step(step)
            else:
                write_chrome_status_step(step)
        except Exception as e:
            log(f"FEJL under countdown-skriv (sekund={i}): {e}")
        time.sleep(1.0)
    log("Countdown færdig.")


# ---------------------------------------------------------------------------
# Confirmation
# ---------------------------------------------------------------------------
def wait_for_system_sleep_confirmation(step: Dict[str, Any], timeout: float = 3.0) -> bool:
    log(f"Venter op til {timeout:.1f}s på bekræftelse i chrome_status.json (id={step.get('id')})")
    try:
        our_ts = datetime.datetime.fromisoformat(step["timestamp"].replace("Z", "+00:00"))
    except Exception:
        our_ts = None

    deadline = time.time() + timeout
    target_id = step.get("id")
    while time.time() < deadline:
        try:
            if CHROME_STATUS_PATH.exists():
                data = json.loads(CHROME_STATUS_PATH.read_text(encoding="utf-8"))
                steps = data.get("steps", []) if isinstance(data, dict) else []
                # 1) id-match
                if target_id:
                    for s in reversed(steps[-200:]):
                        if s.get("step") == "system_sleep" and s.get("id") == target_id:
                            log("Bekræftet via id-match.")
                            return True
                # 2) timestamp-proximity
                if our_ts:
                    for s in reversed(steps[-200:]):
                        if s.get("step") != "system_sleep":
                            continue
                        s_ts_raw = s.get("timestamp")
                        if not s_ts_raw:
                            continue
                        try:
                            s_ts = datetime.datetime.fromisoformat(str(s_ts_raw).replace("Z", "+00:00"))
                            delta = abs((s_ts - our_ts).total_seconds())
                            if delta <= 5.0:
                                log(f"Bekræftet via timestamp-proximity (delta={delta:.2f}s).")
                                return True
                        except Exception:
                            continue
        except Exception as e:
            log(f"Fejl under confirmation-læs: {e}")
        time.sleep(0.12)

    log("WARNING: kunne ikke bekræfte system_sleep inden timeout; fortsætter alligevel.")
    return False


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------
def main() -> int:
    log(f"Starter kiosk_sleep (trigger={TRIGGER}, allow_livestream={ALLOW_LIVESTREAM}).")

    # 1) Stop browsere
    try:
        shutdown_chrome_compat(trigger="sleep")
    except Exception as e:
        log(f"FEJL shutdown_chrome_compat: {e}")

    # 2) Vent på Chrome er væk
    try:
        wait_for_chrome_exit(timeout=5.0, poll=0.2)
    except Exception as e:
        log(f"FEJL i wait_for_chrome_exit: {e}")

    # 3) Countdown (5s)
    try:
        countdown_before_sleep(seconds=5, trigger=TRIGGER)
    except Exception as e:
        log(f"FEJL i countdown_before_sleep: {e}")

    # 4) Sluk skærm
    if not try_xset_dpms_off():
        try:
            try_cec_standby()
        except Exception as e:
            log(f"HDMI-CEC fejlede: {e}")

    # 5) Opdater lokal sleep-config
    cfg = read_config()
    if not isinstance(cfg, dict):
        cfg = {}
    cfg["state"] = "sleeping"
    cfg["sleep_trigger"] = TRIGGER
    cfg["sleep_started_at"] = now_iso()
    cfg["allow_livestream"] = bool(ALLOW_LIVESTREAM)
    for k in ("pending_chrome_action", "pending_sleep", "pending_wake"):
        cfg.pop(k, None)
    write_config(cfg)
    log(f"{SLEEP_CONFIG_PATH.name} opdateret -> state=sleeping.")

    # 6) Append eget step til kiosk_sleep_status.json
    step = {
        "step": "system_sleep",
        "message": "Klient sat i dvale; kiosk browser lukket, skærm slukket",
        "status": "sleeping",
        "trigger": TRIGGER,
        "color": "blue",
        "timestamp": now_iso(),
        "id": str(uuid.uuid4()),
    }
    append_sleep_step(step)

    # 7) Skriv til central chrome_status.json
    try:
        write_chrome_status_step(step)
    except Exception as e:
        log(f"FEJL ved write_chrome_status_step: {e}")

    # 8) Bekræft at det landede
    wait_for_system_sleep_confirmation(step, timeout=3.0)

    time.sleep(0.2)
    return 0


# ---------------------------------------------------------------------------
# Entry
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    # Opret marker FØR alt andet så watchdog ved hvad der sker
    try:
        API_DIR.mkdir(parents=True, exist_ok=True)
        SLEEP_MARKER.write_text(now_iso(), encoding="utf-8")
        log("Oprettede marker .pending_system_sleep")
    except Exception as e:
        log(f"Kunne ikke skrive marker: {e}")

    rc = 0
    try:
        rc = main()
    except Exception as e:
        log(f"FATAL i main: {e}")
        rc = 1
    finally:
        # FIX: finally-blok er nu komplet — markeren fjernes ALTID,
        # også ved undtagelser. Den afskårne kode er rettet her.
        try:
            if SLEEP_MARKER.exists():
                SLEEP_MARKER.unlink()
                log("Fjernede marker .pending_system_sleep")
        except Exception as e:
            log(f"Kunne ikke fjerne marker .pending_system_sleep: {e}")

    sys.exit(rc)
