#!/usr/bin/env python3
"""
config_utils.py

Hjælpe-modul for ClientFlow scripts. Centraliserer læsning/skrivning af
clientflow_config.json og chrome_status.json med:
 - Atomisk skrivning (unik tmp-fil pr. proces, undgår race conditions)
 - Trådsikkerhed via RLock
 - Convenience helpers (get_kiosk_url, is_approved, update_config, ...)

Scripts bør foretrække update_config(partial_dict) frem for read+write,
da det er atomisk for hele read-modify-write cyklussen.
"""
from pathlib import Path
import json
import os
import sys
import threading
import uuid
from typing import Any, Dict, Optional

API_DIR = Path(__file__).resolve().parent

CLIENTFLOW_CONFIG = API_DIR / "clientflow_config.json"
CHROME_STATUS = API_DIR / "chrome_status.json"
SERVICE_LOG = API_DIR / "clientflow_service.log"

# Re-entrant locks så samme tråd kan tage flere gange (fx update_config kalder write_config)
_config_lock = threading.RLock()
_chrome_status_lock = threading.RLock()


def _warn(msg: str) -> None:
    """Skriv warning til stderr — ingen afhængighed af log-modul."""
    try:
        print(f"[config_utils WARN] {msg}", file=sys.stderr)
    except Exception:
        pass


# ---------------------------------------------------------------------------
# Atomic write
# ---------------------------------------------------------------------------
def _atomic_write(path: Path, data: str) -> bool:
    """
    Skriv data atomisk til path. Returnerer True ved succes.
    Bruger unik tmp-fil pr. proces+uuid for at undgå race med andre processer.
    """
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        tmp = path.with_name(f"{path.name}.tmp.{os.getpid()}.{uuid.uuid4().hex[:8]}")
        tmp.write_text(data, encoding="utf-8")
        os.replace(str(tmp), str(path))
        return True
    except Exception as e:
        _warn(f"_atomic_write fejlede for {path}: {e}")
        # Sidste forsøg: direkte skrivning (ikke atomisk)
        try:
            path.write_text(data, encoding="utf-8")
            return True
        except Exception as e2:
            _warn(f"_atomic_write fallback fejlede for {path}: {e2}")
            return False


# ---------------------------------------------------------------------------
# clientflow_config.json
# ---------------------------------------------------------------------------
def read_config() -> Dict[str, Any]:
    """Returnerer parsed JSON fra clientflow_config.json eller {}."""
    with _config_lock:
        if not CLIENTFLOW_CONFIG.exists():
            return {}
        try:
            data = json.loads(CLIENTFLOW_CONFIG.read_text(encoding="utf-8"))
            return data if isinstance(data, dict) else {}
        except json.JSONDecodeError as e:
            _warn(f"clientflow_config.json er ugyldig JSON: {e}")
            return {}
        except Exception as e:
            _warn(f"Kunne ikke læse clientflow_config.json: {e}")
            return {}


def write_config(cfg: Dict[str, Any]) -> bool:
    """Skriv hele config dict atomisk. Returnerer True ved succes."""
    if not isinstance(cfg, dict):
        _warn(f"write_config modtog ikke dict (type={type(cfg).__name__}); ignorerer.")
        return False
    with _config_lock:
        text = json.dumps(cfg, indent=2, ensure_ascii=False)
        return _atomic_write(CLIENTFLOW_CONFIG, text)


def update_config(partial: Dict[str, Any]) -> Dict[str, Any]:
    """
    Atomisk read-modify-write af config.
    Merger 'partial' ind i eksisterende config og skriver tilbage.
    Returnerer den NYE config dict.

    Brug denne i stedet for read_config()+manuel mutation+write_config()
    for at undgå race conditions ved samtidige opdateringer.
    """
    if not isinstance(partial, dict):
        _warn(f"update_config modtog ikke dict (type={type(partial).__name__}).")
        return read_config()
    with _config_lock:
        cfg = read_config()
        cfg.update(partial)
        write_config(cfg)
        return cfg


def delete_config_keys(*keys: str) -> Dict[str, Any]:
    """Atomisk fjern et eller flere nøgler fra config."""
    with _config_lock:
        cfg = read_config()
        changed = False
        for k in keys:
            if k in cfg:
                cfg.pop(k, None)
                changed = True
        if changed:
            write_config(cfg)
        return cfg


# ---------------------------------------------------------------------------
# Convenience getters
# ---------------------------------------------------------------------------
def get_client_id(cfg: Optional[Dict[str, Any]] = None) -> Optional[str]:
    """
    Returnerer client id fra config (str) eller None.
    Understøtter både 'id' (nyere backend) og 'client_id' (legacy).
    """
    if cfg is None:
        cfg = read_config()
    cid = cfg.get("id")
    if cid is None:
        cid = cfg.get("client_id")
    return None if cid is None else str(cid)


def get_status(cfg: Optional[Dict[str, Any]] = None) -> Optional[str]:
    """Returnerer status (fx 'approved') fra config eller None."""
    if cfg is None:
        cfg = read_config()
    status = cfg.get("status")
    return None if status is None else str(status)


def is_approved(cfg: Optional[Dict[str, Any]] = None) -> bool:
    """True hvis klienten er godkendt af backend."""
    status = get_status(cfg)
    return status is not None and status.lower() == "approved"


def get_kiosk_url(cfg: Optional[Dict[str, Any]] = None, default: str = "") -> str:
    """Returnerer kiosk_url fra config eller default."""
    if cfg is None:
        cfg = read_config()
    return str(cfg.get("kiosk_url") or default)


def get_locality(cfg: Optional[Dict[str, Any]] = None, default: str = "Ukendt") -> str:
    """Returnerer locality fra config eller default."""
    if cfg is None:
        cfg = read_config()
    return str(cfg.get("locality") or default)


def get_state(cfg: Optional[Dict[str, Any]] = None) -> Optional[str]:
    """Returnerer 'state' (fx 'sleeping' eller 'normal') eller None."""
    if cfg is None:
        cfg = read_config()
    state = cfg.get("state")
    return None if state is None else str(state)


def is_sleeping(cfg: Optional[Dict[str, Any]] = None) -> bool:
    """True hvis klienten er i dvale-state."""
    state = get_state(cfg)
    return state is not None and state.lower() == "sleeping"


# ---------------------------------------------------------------------------
# chrome_status.json
# ---------------------------------------------------------------------------
def read_chrome_status() -> Dict[str, Any]:
    """Læs chrome_status.json. Returnerer {} ved fejl."""
    with _chrome_status_lock:
        if not CHROME_STATUS.exists():
            return {}
        try:
            data = json.loads(CHROME_STATUS.read_text(encoding="utf-8"))
            return data if isinstance(data, dict) else {}
        except json.JSONDecodeError as e:
            _warn(f"chrome_status.json er ugyldig JSON: {e}")
            return {}
        except Exception as e:
            _warn(f"Kunne ikke læse chrome_status.json: {e}")
            return {}


def write_chrome_status(status: Dict[str, Any]) -> bool:
    """Skriv chrome_status.json atomisk."""
    if not isinstance(status, dict):
        _warn(f"write_chrome_status modtog ikke dict (type={type(status).__name__}).")
        return False
    with _chrome_status_lock:
        text = json.dumps(status, indent=2, ensure_ascii=False)
        return _atomic_write(CHROME_STATUS, text)


def get_latest_chrome_step() -> Optional[Dict[str, Any]]:
    """Returnerer det sidst-skrevne step fra chrome_status.json eller None."""
    data = read_chrome_status()
    steps = data.get("steps", []) if isinstance(data, dict) else []
    if not isinstance(steps, list) or not steps:
        return None
    last = steps[-1]
    return last if isinstance(last, dict) else None


def get_latest_chrome_step_name() -> Optional[str]:
    """Returnerer step-navnet på det sidste step (fx 'system_sleep')."""
    last = get_latest_chrome_step()
    return last.get("step") if last else None


# ---------------------------------------------------------------------------
# Selvtest
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    print("Config:")
    print(json.dumps(read_config(), indent=2, ensure_ascii=False))
    print(f"\nclient_id={get_client_id()}")
    print(f"status={get_status()}")
    print(f"is_approved={is_approved()}")
    print(f"state={get_state()}")
    print(f"is_sleeping={is_sleeping()}")
    print(f"kiosk_url={get_kiosk_url()}")
    print(f"locality={get_locality()}")
    print(f"\nLatest chrome step: {get_latest_chrome_step_name()}")
