#!/usr/bin/env python3
"""
clientflow_browser_guard.py v1.2.0

Defensiv ClientFlow Browser Guard via Chrome Remote Debugging Protocol.

Rettet efter v1.1-log:
- Main page WebSocket kunne lukke med "no close frame received or sent"
- Cookie Information iframe-target kunne afvise WebSocket med HTTP 500
- Derfor:
  * Vi skipper iframe-/worker-targets og policy.app.cookieinformation.com
  * Vi evaluerer kun i hovedsider af type "page"
  * Vi bruger små, hurtige Runtime.evaluate-kald
  * Vi skjuler cookie overlay via CSS/DOM først; vi klikker ikke som primær handling
  * Kort timeout pr. WebSocket-kald
"""

import asyncio
import json
import os
import sys
import time
import urllib.request
from datetime import datetime, timezone

try:
    import websockets
except Exception as e:
    print(f"FEJL: Python-modulet websockets mangler: {e}", file=sys.stderr)
    sys.exit(1)


HOST = os.environ.get("CLIENTFLOW_CHROME_DEBUG_HOST", "127.0.0.1")
PORT = int(os.environ.get("CLIENTFLOW_CHROME_DEBUG_PORT", "9222"))
INTERVAL = float(os.environ.get("CLIENTFLOW_BROWSER_GUARD_INTERVAL", "2"))
REFRESH_SEC = int(os.environ.get("CLIENTFLOW_BROWSER_GUARD_REFRESH_SEC", "900"))
WS_TIMEOUT = float(os.environ.get("CLIENTFLOW_BROWSER_GUARD_WS_TIMEOUT", "4"))
VERSION = "1.2.0"

DEBUG_URL = f"http://{HOST}:{PORT}/json"


def now_iso() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%fZ")


def log(msg: str) -> None:
    print(f"{now_iso()} - browser_guard: {msg}", flush=True)


def get_tabs():
    try:
        with urllib.request.urlopen(DEBUG_URL, timeout=3) as resp:
            return json.loads(resp.read().decode("utf-8", errors="replace"))
    except Exception as e:
        log(f"Chrome remote debugging ikke klar på {DEBUG_URL}: {e}")
        return []


def is_main_page_target(tab: dict) -> bool:
    url = tab.get("url", "") or ""
    target_type = tab.get("type", "") or ""

    if target_type and target_type != "page":
        return False

    if not url.startswith(("http://", "https://")):
        return False

    # Skipper Cookie Information iframe-target, extension pages, service workers osv.
    blocked = [
        "policy.app.cookieinformation.com",
        "cookiesharingiframe",
        "chrome-extension://",
        "devtools://",
    ]

    if any(b in url for b in blocked):
        return False

    return True


HIDE_JS = r"""
(() => {
  const VERSION = '1.2.0';

  function safe(fn, fallback) {
    try { return fn(); } catch (e) { return fallback; }
  }

  function addCss() {
    if (document.getElementById('clientflow-browser-guard-css')) return true;

    const css = document.createElement('style');
    css.id = 'clientflow-browser-guard-css';
    css.textContent = `
      #coiOverlay,
      #coiConsentBanner,
      #coi-banner-wrapper,
      #coiPage-1,
      #coiPage-2,
      .coi-overlay,
      .coi-banner__wrapper,
      .coi-banner__page,
      .coi-banner__summary,
      [class*="coi-banner" i],
      [id^="coi" i],
      [class^="coi" i],
      [class*=" coi" i],
      #CybotCookiebotDialog,
      #CybotCookiebotDialogBodyUnderlay,
      #CookiebotWidget,
      [id^="CybotCookiebot" i],
      [class*="CybotCookiebot" i],
      #usercentrics-root,
      [data-testid="uc-app-container"],
      [data-testid="uc-overlay"],
      #onetrust-banner-sdk,
      #onetrust-consent-sdk,
      .didomi-popup-container,
      .didomi-consent-popup,
      .qc-cmp2-container,
      .cc-window,
      .cookie-banner,
      .cookie-consent,
      .cookie-box,
      .cookie-notice,
      .consent-banner,
      .consent-modal,
      .CookieConsent,
      .cookiescript_injected,
      [data-clientflow-browser-guard-hidden] {
        display: none !important;
        visibility: hidden !important;
        pointer-events: none !important;
        opacity: 0 !important;
      }

      #tm-kiosk-bar,
      #tm-kiosk-text {
        pointer-events: none !important;
        z-index: 2147483647 !important;
      }

      :fullscreen #tm-kiosk-bar,
      :fullscreen #tm-kiosk-text,
      :-webkit-full-screen #tm-kiosk-bar,
      :-webkit-full-screen #tm-kiosk-text {
        display: none !important;
        visibility: hidden !important;
        opacity: 0 !important;
      }
    `;

    return safe(() => {
      (document.head || document.documentElement).appendChild(css);
      return true;
    }, false);
  }

  function hide(el, reason) {
    if (!el) return false;
    if (el.id === 'tm-kiosk-bar' || el.id === 'tm-kiosk-text' || el.id === 'clientflow-browser-guard-css') return false;

    safe(() => el.setAttribute('data-clientflow-browser-guard-hidden', reason || 'hidden'));
    safe(() => el.style.setProperty('display', 'none', 'important'));
    safe(() => el.style.setProperty('visibility', 'hidden', 'important'));
    safe(() => el.style.setProperty('pointer-events', 'none', 'important'));
    safe(() => el.style.setProperty('opacity', '0', 'important'));
    return true;
  }

  function restorePage() {
    safe(() => document.documentElement.style.setProperty('overflow', 'auto', 'important'));
    safe(() => document.body && document.body.style.setProperty('overflow', 'auto', 'important'));
    safe(() => document.documentElement.style.setProperty('pointer-events', 'auto', 'important'));
    safe(() => document.body && document.body.style.setProperty('pointer-events', 'auto', 'important'));

    ['noScroll','modal-open','no-scroll','noscroll','cookie-open','coi-banner-open','coi-modal-open'].forEach(c => {
      safe(() => document.documentElement.classList.remove(c));
      safe(() => document.body && document.body.classList.remove(c));
    });
  }

  function hideKnown() {
    let hidden = 0;
    const selectors = [
      '#coiOverlay',
      '#coiConsentBanner',
      '#coi-banner-wrapper',
      '#coiPage-1',
      '#coiPage-2',
      '.coi-overlay',
      '.coi-banner__wrapper',
      '.coi-banner__page',
      '.coi-banner__summary',
      '[class*="coi-banner" i]',
      '[id^="coi" i]',
      '[class^="coi" i]',
      '[class*=" coi" i]',
      '#CybotCookiebotDialog',
      '#CybotCookiebotDialogBodyUnderlay',
      '#CookiebotWidget',
      '[id^="CybotCookiebot" i]',
      '[class*="CybotCookiebot" i]',
      '#usercentrics-root',
      '[data-testid="uc-app-container"]',
      '[data-testid="uc-overlay"]',
      '#onetrust-banner-sdk',
      '#onetrust-consent-sdk',
      '.didomi-popup-container',
      '.didomi-consent-popup',
      '.qc-cmp2-container',
      '.cc-window',
      '.cookie-banner',
      '.cookie-consent',
      '.cookie-box',
      '.cookie-notice',
      '.consent-banner',
      '.consent-modal',
      '.CookieConsent',
      '.cookiescript_injected'
    ];

    for (const sel of selectors) {
      safe(() => document.querySelectorAll(sel).forEach(el => {
        if (hide(el, 'selector:' + sel)) hidden++;
      }));
    }

    // Universel fallback på store cookie/samtykke overlays.
    const keywords = /cookie|cookies|samtykke|consent|privatliv|personoplysninger|persondata|gdpr|marketing|statistik|funktionelle|nødvendige|du bestemmer over dine data|powered by cookie information|samarbejdspartnere bruger teknologier/i;

    const nodes = safe(() => Array.from(document.querySelectorAll('div,section,aside,dialog,form')), []);
    for (const el of nodes) {
      const meta = safe(() => [
        el.id,
        el.className,
        el.getAttribute('role'),
        el.getAttribute('aria-modal'),
        el.getAttribute('aria-label'),
        el.getAttribute('title'),
        el.innerText || el.textContent || ''
      ].join(' '), '');

      if (keywords.test(meta)) {
        if (hide(el, 'keyword')) hidden++;
        continue;
      }

      const bigFixed = safe(() => {
        const s = getComputedStyle(el);
        const r = el.getBoundingClientRect();
        const area = r.width * r.height;
        const viewport = innerWidth * innerHeight;
        const z = parseInt(s.zIndex || '0', 10) || 0;
        return ['fixed','absolute','sticky'].includes(s.position) && z >= 50 && area > viewport * 0.2;
      }, false);

      if (bigFixed) {
        if (hide(el, 'big-fixed')) hidden++;
      }
    }

    restorePage();
    return hidden;
  }

  function blockNative() {
    const noop = function(){};
    const yes = function(){ return true; };
    const nil = function(){ return null; };

    safe(() => { window.alert = noop; });
    safe(() => { window.confirm = yes; });
    safe(() => { window.prompt = nil; });
    safe(() => { window.print = noop; });
    safe(() => {
      window.open = function() {
        return { closed: true, close(){}, focus(){}, blur(){}, postMessage(){}, location: { href: 'about:blank' } };
      };
    });
  }

  document.documentElement.setAttribute('data-clientflow-browser-guard', VERSION);
  window.__clientflowBrowserGuardVersion = VERSION;

  addCss();
  blockNative();

  if (!window.__clientflowBrowserGuardHideLoop) {
    window.__clientflowBrowserGuardHideLoop = true;
    safe(() => {
      new MutationObserver(() => {
        addCss();
        hideKnown();
      }).observe(document.documentElement || document.body, {
        childList: true,
        subtree: true,
        attributes: true,
        attributeFilter: ['class','style','id','role','aria-modal','aria-label']
      });
    });
    safe(() => setInterval(() => {
      document.documentElement.setAttribute('data-clientflow-browser-guard', VERSION);
      addCss();
      hideKnown();
    }, 1000));
  }

  const hidden = hideKnown();
  const overlay = document.querySelector('#coiOverlay');

  return {
    version: VERSION,
    href: location.href,
    marker: document.documentElement.getAttribute('data-clientflow-browser-guard'),
    hidden,
    overlay: overlay ? {
      display: getComputedStyle(overlay).display,
      visibility: getComputedStyle(overlay).visibility,
      opacity: getComputedStyle(overlay).opacity
    } : null,
    css: !!document.getElementById('clientflow-browser-guard-css')
  };
})()
"""

COUNTDOWN_JS = r"""
(() => {
  const VERSION = '1.2.0';
  const REFRESH_SEC = __REFRESH_SEC__;

  function safe(fn, fallback) {
    try { return fn(); } catch (e) { return fallback; }
  }

  function isFullscreen() {
    return safe(() => {
      if (document.fullscreenElement || document.webkitFullscreenElement || document.querySelector(':fullscreen')) return true;
      const h = Math.abs(outerHeight - screen.height) <= 2 || Math.abs(innerHeight - screen.height) <= 2;
      const w = Math.abs(outerWidth - screen.width) <= 2 || Math.abs(innerWidth - screen.width) <= 2;
      if (h && w) return true;
      if (innerHeight >= screen.availHeight - 2 && innerWidth >= screen.availWidth - 2) return true;
      return false;
    }, false);
  }

  function createCountdown() {
    if (document.getElementById('tm-kiosk-bar')) return;

    const bar = document.createElement('div');
    bar.id = 'tm-kiosk-bar';
    const txt = document.createElement('div');
    txt.id = 'tm-kiosk-text';

    Object.entries({
      position:'fixed', top:'0', left:'0', height:'6px', width:'100%',
      transform:'scaleX(0)', 'transform-origin':'left center',
      background:'linear-gradient(90deg, rgba(0,150,136,.95), rgba(76,175,80,.95))',
      'z-index':'2147483647', 'pointer-events':'none', transition:'transform 0.9s linear, opacity 0.2s',
      display:'block', visibility:'visible', opacity:'1'
    }).forEach(([k,v]) => safe(() => bar.style.setProperty(k, v, 'important')));

    Object.entries({
      position:'fixed', top:'8px', right:'10px', padding:'3px 6px',
      background:'rgba(0,0,0,.6)', color:'#fff', 'font-size':'12px',
      'border-radius':'4px', 'z-index':'2147483647', 'pointer-events':'none',
      'font-family':'sans-serif', 'line-height':'1', display:'block', visibility:'visible', opacity:'1'
    }).forEach(([k,v]) => safe(() => txt.style.setProperty(k, v, 'important')));

    safe(() => (document.body || document.documentElement).appendChild(bar));
    safe(() => (document.body || document.documentElement).appendChild(txt));
  }

  function updateCountdown() {
    createCountdown();

    if (!window.__clientflowBrowserGuardStart) window.__clientflowBrowserGuardStart = Date.now();

    const elapsed = Math.floor((Date.now() - window.__clientflowBrowserGuardStart) / 1000);
    const pct = Math.max(0, Math.min(1, elapsed / REFRESH_SEC));
    const hidden = isFullscreen();

    const bar = document.getElementById('tm-kiosk-bar');
    const txt = document.getElementById('tm-kiosk-text');

    if (bar) {
      bar.removeAttribute('data-clientflow-browser-guard-hidden');
      bar.style.setProperty('display', hidden ? 'none' : 'block', 'important');
      bar.style.setProperty('visibility', hidden ? 'hidden' : 'visible', 'important');
      bar.style.setProperty('opacity', hidden ? '0' : '1', 'important');
      bar.style.setProperty('transform', 'scaleX(' + pct + ')', 'important');
      bar.style.setProperty('z-index', '2147483647', 'important');
    }

    if (txt) {
      txt.removeAttribute('data-clientflow-browser-guard-hidden');
      const left = Math.max(0, REFRESH_SEC - elapsed);
      const m = Math.floor(left / 60);
      const s = left % 60;
      txt.textContent = 'Opdaterer om ' + m + ':' + String(s).padStart(2, '0');
      txt.style.setProperty('display', hidden ? 'none' : 'block', 'important');
      txt.style.setProperty('visibility', hidden ? 'hidden' : 'visible', 'important');
      txt.style.setProperty('opacity', hidden ? '0' : '1', 'important');
      txt.style.setProperty('z-index', '2147483647', 'important');
    }

    if (elapsed >= REFRESH_SEC) {
      window.__clientflowBrowserGuardStart = Date.now();
      const url = new URL(location.href);
      url.searchParams.set('_kiosk_refresh', Date.now().toString());
      location.replace(url.toString());
    }

    return { elapsed, hidden, bar: !!bar, text: !!txt };
  }

  if (!window.__clientflowBrowserGuardCountdownLoop) {
    window.__clientflowBrowserGuardCountdownLoop = true;
    window.__clientflowBrowserGuardStart = window.__clientflowBrowserGuardStart || Date.now();
    safe(() => setInterval(updateCountdown, 1000));
  }

  return updateCountdown();
})()
""".replace("__REFRESH_SEC__", str(REFRESH_SEC))


async def evaluate_js(tab, js: str, label: str):
    wsurl = tab.get("webSocketDebuggerUrl")
    url = tab.get("url", "")

    if not wsurl:
        return {"href": url, "error": "missing webSocketDebuggerUrl", "label": label}

    try:
        async with websockets.connect(
            wsurl,
            max_size=10_000_000,
            open_timeout=WS_TIMEOUT,
            close_timeout=1,
        ) as ws:
            await ws.send(json.dumps({
                "id": 1,
                "method": "Runtime.evaluate",
                "params": {
                    "expression": js,
                    "returnByValue": True,
                    "awaitPromise": False,
                    "userGesture": False,
                    "timeout": int(WS_TIMEOUT * 1000),
                },
            }))

            while True:
                msg = await asyncio.wait_for(ws.recv(), timeout=WS_TIMEOUT)
                payload = json.loads(msg)
                if payload.get("id") != 1:
                    continue

                result = payload.get("result", {})
                if "exceptionDetails" in result:
                    return {
                        "href": url,
                        "label": label,
                        "error": "Runtime.evaluate exception",
                        "exceptionDetails": result.get("exceptionDetails"),
                    }

                return result.get("result", {}).get("value")
    except Exception as e:
        return {"href": url, "label": label, "error": str(e)}


async def run_once():
    tabs = [t for t in get_tabs() if is_main_page_target(t)]
    results = []

    for tab in tabs:
        # Først: kort CSS/DOM hide. Dette må ikke klikke/reloade siden.
        hide_result = await evaluate_js(tab, HIDE_JS, "hide")
        results.append(hide_result)

        # Countdown i separat lille kald. Hvis det fejler, påvirker det ikke cookie-hide.
        countdown_result = await evaluate_js(tab, COUNTDOWN_JS, "countdown")
        if isinstance(countdown_result, dict):
            hide_result = dict(hide_result or {})
            hide_result["countdown"] = countdown_result
            results[-1] = hide_result

    return results


async def main():
    log(f"Starter v{VERSION}. DevTools={DEBUG_URL}, interval={INTERVAL}s, refresh={REFRESH_SEC}s, ws_timeout={WS_TIMEOUT}s")

    last_summary = 0.0
    last_error = ""

    while True:
        try:
            results = await run_once()

            for r in results:
                if isinstance(r, dict) and r.get("error"):
                    msg = json.dumps(r, ensure_ascii=False)[:1400]
                    if msg != last_error:
                        log(f"FEJL evaluate: {msg}")
                        last_error = msg

            now = time.monotonic()
            if now - last_summary > 10:
                if results:
                    for r in results:
                        if isinstance(r, dict):
                            log(
                                "status "
                                f"url={r.get('href')} "
                                f"marker={r.get('marker')} "
                                f"hidden={r.get('hidden')} "
                                f"overlay={r.get('overlay')} "
                                f"css={r.get('css')} "
                                f"countdown={r.get('countdown')}"
                            )
                        else:
                            log(f"status non-dict={r!r}")
                else:
                    log("Ingen main page http(s)-tabs fundet eller Chrome ikke klar.")
                last_summary = now
        except Exception as e:
            log(f"FEJL i loop: {e}")

        await asyncio.sleep(INTERVAL)


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        log("Stopper.")
