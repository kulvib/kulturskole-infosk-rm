#!/usr/bin/env python3
"""
kiosk_wake.py — komplet version
"""
from pathlib import Path
import json
import time
import os
import sys
import subprocess
import psutil
import uuid
import datetime
from shutil import which
from typing import Any, Dict, Optional

API_DIR = Path(__file__).resolve().parent

WAKE_CONFIG_PATH = API_DIR / "kiosk_wake_config.json"
WAKE_STATUS_PATH = API_DIR / "kiosk_wake_status.json"
LOG_PATH         = API_DIR / "kiosk_wake.log"
CHROME_STATUS_PATH = API_DIR / "chrome_status.json"
WAKE_MARKER  = API_DIR / ".pending_system_wake"
SLEEP_MARKER = API_DIR / ".pending_system_sleep"

DISPLAY = os.environ.get("DISPLAY", ":0")
XAUTH   = os.environ.get("XAUTHORITY", "/run/user/1000/gdm/Xauthority")
CEC_CLIENT_CMD = "cec-client"

TRIGGER = os.environ.get("KIOSK_TRIGGER", os.environ.get("CLIENTFLOW_TRIGGER", "backend"))

RECENT_CHROME_THRESHOLD_SECS = 30


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
def now_iso() -> str:
    return datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%f") + "Z"


def log(msg: str) -> None:
    line = f"{now_iso()} - kiosk_wake: {msg}\n"
    try:
        with open(LOG_PATH, "a", encoding="utf-8") as f:
            f.write(line)
    except Exception:
        try:
            print(line, end="")
        except Exception:
            pass


def _atomic_write(path: Path, obj: Any) -> None:
    try:
        if not isinstance(path, Path):
            path = Path(path)
        if not isinstance(obj, (dict, list)):
            obj = {"value": str(obj)}
        text = json.dumps(obj, ensure_ascii=False, indent=2)
        path.parent.mkdir(parents=True, exist_ok=True)
        tmp = path.with_name(f"{path.name}.tmp.{os.getpid()}.{uuid.uuid4().hex[:8]}")
        tmp.write_text(text, encoding="utf-8")
        os.replace(str(tmp), str(path))
    except Exception as e:
        log(f"FEJL i _atomic_write til {path}: {e}")
        try:
            path.write_text(json.dumps(obj, ensure_ascii=False, indent=2), encoding="utf-8")
        except Exception as e2:
            log(f"FEJL fallback write til {path}: {e2}")


def read_config() -> Dict[str, Any]:
    try:
        if WAKE_CONFIG_PATH.exists():
            data = json.loads(WAKE_CONFIG_PATH.read_text(encoding="utf-8"))
            if isinstance(data, dict):
                return data
    except Exception as e:
        log(f"FEJL read_config: {e}")
    return {}


def write_config(cfg: Dict[str, Any]) -> None:
    if not isinstance(cfg, dict):
        cfg = {"state": str(cfg)}
    _atomic_write(WAKE_CONFIG_PATH, cfg)


def append_wake_step(step: Dict[str, Any]) -> None:
    if not isinstance(step, dict):
        step = {"message": str(step), "timestamp": now_iso()}
    step.setdefault("timestamp", now_iso())
    step.setdefault("id", str(uuid.uuid4()))
    try:
        data: Dict[str, Any] = {"steps": [], "kiosk_wake_running": False}
        if WAKE_STATUS_PATH.exists():
            try:
                existing = json.loads(WAKE_STATUS_PATH.read_text(encoding="utf-8"))
                if isinstance(existing, dict):
                    data = existing
            except Exception:
                log(f"FEJL: kunne ikke læse {WAKE_STATUS_PATH.name}, nulstiller.")
        steps = data.get("steps", [])
        if not isinstance(steps, list):
            steps = []
        steps.append(step)
        data["steps"] = steps[-50:]
        data["kiosk_wake_running"] = False
        _atomic_write(WAKE_STATUS_PATH, data)
    except Exception as e:
        log(f"FEJL ved append_wake_step: {e}")


# ---------------------------------------------------------------------------
# Display power
# ---------------------------------------------------------------------------
def try_xset_dpms_on() -> bool:
    env = {**os.environ, "DISPLAY": DISPLAY, "XAUTHORITY": XAUTH}
    try:
        try:
            subprocess.run(["xset", "+dpms"],   env=env, timeout=3, check=False,
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            subprocess.run(["xset", "s", "off"], env=env, timeout=3, check=False,
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        except Exception:
            pass
        subprocess.run(["xset", "dpms", "force", "on"],
                       env=env, timeout=5, check=True,
                       stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        log("Skærmen tændt via xset DPMS.")
        return True
    except Exception as e:
        log(f"xset DPMS on fejlede: {e}")
        return False


def try_cec_power_on() -> bool:
    if not which(CEC_CLIENT_CMD):
        log("cec-client ikke installeret, springer HDMI-CEC power-on over.")
        return False
    p = None
    try:
        p = subprocess.Popen(
            [CEC_CLIENT_CMD, "-s", "-d", "1"],
            stdin=subprocess.PIPE, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
        )
        time.sleep(0.3)
        try:
            if p.stdin:
                p.stdin.write(b"on 0\n")
                p.stdin.flush()
        except Exception as e:
            log(f"Kunne ikke skrive til cec-client stdin: {e}")
        time.sleep(0.5)
        log("Skærmen forsøgt tændt via HDMI-CEC.")
        return True
    except Exception as e:
        log(f"cec-client power-on fejlede: {e}")
        return False
    finally:
        if p:
            try:
                if p.stdin:
                    p.stdin.close()
            except Exception:
                pass
            try:
                p.terminate()
                p.wait(timeout=2)
            except Exception:
                try:
                    p.kill()
                except Exception:
                    pass


# ---------------------------------------------------------------------------
# Chrome cleanup (stille — dræb KUN gamle processer)
# ---------------------------------------------------------------------------
def _chrome_proc_age_secs(proc: psutil.Process) -> Optional[float]:
    try:
        return time.time() - proc.create_time()
    except Exception:
        return None


def cleanup_old_chrome_processes(trigger: str = "wake") -> None:
    """
    Dræber Chrome-processer der er ældre end RECENT_CHROME_THRESHOLD_SECS.
    Nyere processer (netop startet af clientflow_service) berøres ikke.
    """
    killed = 0
    for proc in psutil.process_iter(["pid", "name", "create_time"]):
        try:
            name = (proc.info.get("name") or "").lower()
            if "chrome" not in name:
                continue
            age = _chrome_proc_age_secs(proc)
            if age is None or age < RECENT_CHROME_THRESHOLD_SECS:
                log(f"Bevarer Chrome pid={proc.pid} (alder={age:.1f}s < {RECENT_CHROME_THRESHOLD_SECS}s)")
                continue
            proc.terminate()
            killed += 1
            log(f"SIGTERM til gammel Chrome pid={proc.pid} (alder={age:.1f}s)")
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            continue
        except Exception as e:
            log(f"Fejl ved cleanup af Chrome pid={proc.pid}: {e}")

    if killed:
        time.sleep(1.0)
        for proc in psutil.process_iter(["pid", "name"]):
            try:
                if "chrome" in (proc.info.get("name") or "").lower():
                    age = _chrome_proc_age_secs(proc)
                    if age is not None and age >= RECENT_CHROME_THRESHOLD_SECS:
                        proc.kill()
                        log(f"SIGKILL til Chrome pid={proc.pid}")
            except Exception:
                continue
    log(f"cleanup_old_chrome_processes: dræbte {killed} processer.")


# ---------------------------------------------------------------------------
# chrome_status.json integration
# ---------------------------------------------------------------------------
def write_chrome_status_step(step: Dict[str, Any]) -> None:
    """Skriv system_wake step til central chrome_status.json."""
    try:
        import chrome_kiosk  # type: ignore
        try:
            if hasattr(chrome_kiosk, "append_external_step"):
                chrome_kiosk.append_external_step(step)
                log("Brugte chrome_kiosk.append_external_step til system_wake.")
                return
            if hasattr(chrome_kiosk, "mark_system_wake"):
                chrome_kiosk.mark_system_wake(trigger=step.get("trigger", "backend"))
                log("Brugte chrome_kiosk.mark_system_wake (fallback).")
                return
        except Exception as e:
            log(f"chrome_kiosk helper-fejl: {e}")
    except Exception:
        log("chrome_kiosk ikke tilgængelig; lokal fallback.")

    # Lokal fallback
    try:
        data: Dict[str, Any] = {"steps": [], "chrome_running": False}
        if CHROME_STATUS_PATH.exists():
            try:
                existing = json.loads(CHROME_STATUS_PATH.read_text(encoding="utf-8"))
                if isinstance(existing, dict):
                    data = existing
            except Exception as e:
                log(f"Kunne ikke læse chrome_status.json: {e}")
        steps = data.get("steps", [])
        if not isinstance(steps, list):
            steps = []
        s = {
            "step":      step.get("step"),
            "message":   step.get("message"),
            "status":    step.get("status", ""),
            "trigger":   step.get("trigger", "backend"),
            "color":     step.get("color", "green"),
            "timestamp": step.get("timestamp", now_iso()),
            "id":        step.get("id", str(uuid.uuid4())),
        }
        steps.append(s)
        data["steps"] = steps[-50:]
        _atomic_write(CHROME_STATUS_PATH, data)
        log("Appended system_wake til chrome_status.json (fallback).")
    except Exception as e:
        log(f"FEJL ved fallback skriv til chrome_status.json: {e}")


def wait_for_system_wake_confirmation(step: Dict[str, Any], timeout: float = 3.0) -> bool:
    log(f"Venter op til {timeout:.1f}s på bekræftelse i chrome_status.json (id={step.get('id')})")
    try:
        our_ts = datetime.datetime.fromisoformat(step["timestamp"].replace("Z", "+00:00"))
    except Exception:
        our_ts = None

    deadline    = time.time() + timeout
    target_id   = step.get("id")

    while time.time() < deadline:
        try:
            if CHROME_STATUS_PATH.exists():
                data  = json.loads(CHROME_STATUS_PATH.read_text(encoding="utf-8"))
                steps = data.get("steps", []) if isinstance(data, dict) else []
                # 1) id-match
                if target_id:
                    for s in reversed(steps[-200:]):
                        if s.get("step") == "system_wake" and s.get("id") == target_id:
                            log("Bekræftet via id-match.")
                            return True
                # 2) timestamp-proximity
                if our_ts:
                    for s in reversed(steps[-200:]):
                        if s.get("step") != "system_wake":
                            continue
                        s_ts_raw = s.get("timestamp")
                        if not s_ts_raw:
                            continue
                        try:
                            s_ts  = datetime.datetime.fromisoformat(str(s_ts_raw).replace("Z", "+00:00"))
                            delta = abs((s_ts - our_ts).total_seconds())
                            if delta <= 5.0:
                                log(f"Bekræftet via timestamp-proximity (delta={delta:.2f}s).")
                                return True
                        except Exception:
                            continue
        except Exception as e:
            log(f"Fejl under confirmation-læs: {e}")
        time.sleep(0.12)

    log("WARNING: kunne ikke bekræfte system_wake inden timeout; fortsætter alligevel.")
    return False


# ---------------------------------------------------------------------------
# Fjern sleep-marker hvis den stadig er der
# ---------------------------------------------------------------------------
def clear_sleep_marker() -> None:
    try:
        if SLEEP_MARKER.exists():
            SLEEP_MARKER.unlink()
            log("Fjernede gammel .pending_system_sleep marker.")
    except Exception as e:
        log(f"Kunne ikke fjerne .pending_system_sleep: {e}")


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------
def main() -> int:
    log(f"Starter kiosk_wake (trigger={TRIGGER}).")

    # 1) Fjern sleep-marker (hvis dvale-scriptet ikke nåede det)
    clear_sleep_marker()

    # 2) Tænd skærm
    if not try_xset_dpms_on():
        try:
            try_cec_power_on()
        except Exception as e:
            log(f"HDMI-CEC power-on fejlede: {e}")

    # 3) Ryd gamle Chrome-processer (nye bevares)
    try:
        cleanup_old_chrome_processes(trigger=TRIGGER)
    except Exception as e:
        log(f"FEJL i cleanup_old_chrome_processes: {e}")

    # 4) Opdater lokal wake-config
    cfg = read_config()
    if not isinstance(cfg, dict):
        cfg = {}
    cfg["state"]           = "normal"
    cfg["wake_trigger"]    = TRIGGER
    cfg["wake_started_at"] = now_iso()
    for k in ("pending_chrome_action", "pending_sleep", "pending_wake"):
        cfg.pop(k, None)
    write_config(cfg)
    log(f"{WAKE_CONFIG_PATH.name} opdateret -> state=normal.")

    # 5) Append eget step til kiosk_wake_status.json
    step = {
        "step":    "system_wake",
        "message": "Klient vækket fra dvale; skærm tændt",
        "status":  "running",
        "trigger": TRIGGER,
        "color":   "green",
        "timestamp": now_iso(),
        "id":      str(uuid.uuid4()),
    }
    append_wake_step(step)

    # 6) Skriv til central chrome_status.json
    try:
        write_chrome_status_step(step)
    except Exception as e:
        log(f"FEJL ved write_chrome_status_step: {e}")

    # 7) Bekræft at det landede
    wait_for_system_wake_confirmation(step, timeout=3.0)

    time.sleep(0.2)
    return 0


# ---------------------------------------------------------------------------
# Entry
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    # Opret wake-marker FØR alt andet
    try:
        API_DIR.mkdir(parents=True, exist_ok=True)
        WAKE_MARKER.write_text(now_iso(), encoding="utf-8")
        log("Oprettede marker .pending_system_wake")
    except Exception as e:
        log(f"Kunne ikke skrive marker: {e}")

    rc = 0
    try:
        rc = main()
    except Exception as e:
        log(f"FATAL i main: {e}")
        rc = 1
    finally:
        try:
            if WAKE_MARKER.exists():
                WAKE_MARKER.unlink()
                log("Fjernede marker .pending_system_wake")
        except Exception as e:
            log(f"Kunne ikke fjerne marker .pending_system_wake: {e}")

    sys.exit(rc)
