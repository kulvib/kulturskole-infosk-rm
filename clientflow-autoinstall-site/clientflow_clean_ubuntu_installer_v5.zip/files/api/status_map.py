#!/usr/bin/env python3
"""
status_map.py

Central, autoritativ STATUS_MAP og format_message.
Bruges af chrome_kiosk.py, clientflow_gui.py, clientflow_service.py m.fl.

Hvis du tilføjer nye step/trigger-kombinationer, gør det HER (ikke i fallback-versioner
spredt rundt i koden).
"""
from typing import Any, Dict, Tuple

# ---------------------------------------------------------------------------
# Trigger-aliasser:
# clientflow_service._map_source_to_trigger() producerer triggers som
# 'actionbutton_backend_sleep_wakeup' og 'calendar_backend_sleep_wakeup'.
# Vi normaliserer dem til base-triggers så STATUS_MAP ikke skal duplikere alle entries.
# ---------------------------------------------------------------------------
TRIGGER_ALIASES: Dict[str, str] = {
    "actionbutton_backend_sleep_wakeup": "backend",
    "calendar_backend_sleep_wakeup": "calendar",
    "calendar_sleep": "calendar",
    "calendar_wake": "calendar",
}


def _normalize_trigger(trigger: Any) -> Any:
    """Returner normaliseret trigger (lowercased + alias-mapped)."""
    if not isinstance(trigger, str):
        return trigger
    low = trigger.lower()
    return TRIGGER_ALIASES.get(low, low)


def fallback_status_message(step: str, trigger: str) -> Tuple[str, str]:
    return (f"{step} via {trigger}", "black")


# ---------------------------------------------------------------------------
# STATUS_MAP
# ---------------------------------------------------------------------------
STATUS_MAP: Dict[Tuple[str, str], Tuple[str, str]] = {
    # ----- chrome_opened_manual -----
    ("chrome_opened_manual", "manual"):       ("Kiosk browser åbnet manuelt", "green"),
    ("chrome_opened_manual", "backend"):      ("Kiosk browser åbnet fra backend", "green"),
    ("chrome_opened_manual", "system_start"): ("Kiosk browser åbnet ved systemstart", "green"),
    ("chrome_opened_manual", "gui"):          ("Kiosk browser åbnet fra GUI på klient", "green"),
    ("chrome_opened_manual", "url_change"):   ("Kiosk browser åbnet ved URL-skift", "green"),
    ("chrome_opened_manual", "calendar"):     ("Kiosk browser åbnet fra kalender", "green"),

    # ----- start_chrome -----
    ("start_chrome", "manual"):       ("Kiosk browser startet manuelt", "green"),
    ("start_chrome", "backend"):      ("Kiosk browser startet fra backend", "green"),
    ("start_chrome", "system_start"): ("Kiosk browser startet ved systemstart", "green"),
    ("start_chrome", "gui"):          ("Kiosk browser startet fra GUI på klient", "green"),
    ("start_chrome", "url_change"):   ("Kiosk browser startet ved URL-skift", "green"),
    ("start_chrome", "calendar"):     ("Kiosk browser startet fra kalender", "green"),

    # ----- chrome_closed_manual -----
    ("chrome_closed_manual", "manual"):       ("Kiosk browser lukket manuelt", "red"),
    ("chrome_closed_manual", "backend"):      ("Kiosk browser lukket fra backend", "red"),
    ("chrome_closed_manual", "system_start"): ("Kiosk browser lukket ved systemstart", "red"),
    ("chrome_closed_manual", "gui"):          ("Kiosk browser lukket fra GUI på klient", "red"),
    ("chrome_closed_manual", "url_change"):   ("Kiosk browser lukket ved URL-skift", "red"),
    ("chrome_closed_manual", "calendar"):     ("Kiosk browser lukket fra kalender", "red"),

    # ----- chrome_closed_programmatically -----
    ("chrome_closed_programmatically", "manual"):          ("Kiosk browser lukket manuelt", "red"),
    ("chrome_closed_programmatically", "backend"):         ("Kiosk browser lukket fra backend", "red"),
    ("chrome_closed_programmatically", "system_start"):    ("Kiosk browser lukket ved systemstart", "red"),
    ("chrome_closed_programmatically", "gui"):             ("Kiosk browser lukket fra GUI på klient", "red"),
    ("chrome_closed_programmatically", "url_change"):      ("Kiosk browser lukket ved URL-skift", "red"),
    ("chrome_closed_programmatically", "calendar"):        ("Kiosk browser lukket fra kalender", "red"),
    # FIX: kortere og mere præcise tekster — synkroniseret med chrome_kiosk.py
    ("chrome_closed_programmatically", "pending_reboot"):  ("Kiosk browser lukket — klient genstarter", "red"),
    ("chrome_closed_programmatically", "pending_shutdown"):("Kiosk browser lukket — klient lukker ned", "red"),
    ("chrome_closed_programmatically", "wakeup"):          ("Kiosk browser lukket — klient genstarter efter dvale", "red"),
    ("chrome_closed_programmatically", "sleep"):           ("Kiosk browser lukket — klient i dvale", "red"),

    # ----- shutdown_chrome -----
    ("shutdown_chrome", "manual"):          ("Kiosk browser lukket manuelt", "red"),
    ("shutdown_chrome", "backend"):         ("Kiosk browser lukket fra backend", "red"),
    ("shutdown_chrome", "system_start"):    ("Kiosk browser lukket ved systemstart", "red"),
    ("shutdown_chrome", "gui"):             ("Kiosk browser lukket fra GUI på klient", "red"),
    ("shutdown_chrome", "url_change"):      ("Kiosk browser lukket ved URL-skift", "red"),
    ("shutdown_chrome", "calendar"):        ("Kiosk browser lukket fra kalender", "red"),
    # FIX: kortere og mere præcise tekster — synkroniseret med chrome_kiosk.py
    ("shutdown_chrome", "pending_reboot"):  ("Kiosk browser lukket — klient genstarter", "red"),
    ("shutdown_chrome", "pending_shutdown"):("Kiosk browser lukket — klient lukker ned", "red"),
    ("shutdown_chrome", "sleep"):           ("Kiosk browser lukket — klient i dvale", "red"),
    ("shutdown_chrome", "wakeup"):          ("Kiosk browser lukket — klient genstarter efter dvale", "red"),

    # ----- terminate_chrome -----
    # FIX: ændret fra "Kiosk browser lukket..." til "Lukker kiosk browser…"
    # terminate_chrome er et BUSY-step (SIGTERM sendt, men processen er ikke stoppet endnu)
    # — teksten skal afspejle at noget er i gang, ikke at det er færdigt.
    ("terminate_chrome", "manual"):       ("Lukker kiosk browser…", "orange"),
    ("terminate_chrome", "backend"):      ("Lukker kiosk browser…", "orange"),
    ("terminate_chrome", "system_start"): ("Lukker kiosk browser…", "orange"),
    ("terminate_chrome", "gui"):          ("Lukker kiosk browser…", "orange"),
    ("terminate_chrome", "url_change"):   ("Lukker kiosk browser…", "orange"),
    ("terminate_chrome", "calendar"):     ("Lukker kiosk browser…", "orange"),
    ("terminate_chrome", "sleep"):        ("Lukker kiosk browser — klient i dvale…", "orange"),
    ("terminate_chrome", "wakeup"):       ("Lukker kiosk browser — klient genstarter efter dvale…", "orange"),

    # ----- kill_chrome -----
    ("kill_chrome", "manual"):   ("Kiosk browser tvangslukket manuelt", "red"),
    ("kill_chrome", "backend"):  ("Kiosk browser tvangslukket fra backend", "red"),
    ("kill_chrome", "calendar"): ("Kiosk browser tvangslukket fra kalender", "red"),
    ("kill_chrome", "sleep"):    ("Kiosk browser tvangslukket — klient i dvale", "red"),

    # ----- countdown (start) -----
    ("countdown", "system_start"): ("Kiosk browser starter om {X} sekund{plural}…", "orange"),
    ("countdown", "backend"):      ("Kiosk browser starter om {X} sekund{plural}…", "orange"),
    ("countdown", "url_change"):   ("Kiosk browser starter ved URL-skift om {X} sekund{plural}…", "orange"),
    ("countdown", "manual_start"): ("Kiosk browser starter om {X} sekund{plural}…", "orange"),
    ("countdown", "gui"):          ("Kiosk browser starter om {X} sekund{plural}…", "orange"),
    ("countdown", "calendar"):     ("Kiosk browser starter fra kalender om {X} sekund{plural}…", "orange"),

    # ----- countdown (sleep) — bruges af kiosk_sleep.py -----
    ("countdown", "sleep"): ("Klient sættes i dvale om {X} sekund{plural}…", "orange"),

    # ----- clear_cookies -----
    # FIX: ændret fra "Cookies og browserdata slettes..." til "Rydder cookies og browserdata…"
    # clear_cookies er et BUSY-step — teksten skal afspejle at noget er i gang.
    ("clear_cookies", "manual"):       ("Rydder cookies og browserdata…", "orange"),
    ("clear_cookies", "backend"):      ("Rydder cookies og browserdata…", "orange"),
    ("clear_cookies", "system_start"): ("Rydder cookies og browserdata…", "orange"),
    ("clear_cookies", "gui"):          ("Rydder cookies og browserdata…", "orange"),
    ("clear_cookies", "url_change"):   ("Rydder cookies og browserdata…", "orange"),
    ("clear_cookies", "calendar"):     ("Rydder cookies og browserdata…", "orange"),
    ("cookies_cleared", "backend"):    ("Cookies og browserdata ryddet", "orange"),

    # ----- error -----
    ("error", "manual"):          ("Der opstod en fejl ved manuel handling", "red"),
    ("error", "backend"):         ("Der opstod en fejl ved backendkommando", "red"),
    ("error", "system_start"):    ("Der opstod en fejl ved systemstart", "red"),
    ("error", "gui"):             ("Der opstod en fejl ved GUI kommando", "red"),
    ("error", "url_change"):      ("Der opstod en fejl ved URL-skift", "red"),
    ("error", "calendar"):        ("Der opstod en fejl ved kalender-handling", "red"),
    ("error", "pending_reboot"):  ("Der opstod en fejl ved genstart", "red"),
    ("error", "pending_shutdown"):("Der opstod en fejl ved nedlukning", "red"),

    # ----- system_sleep / system_wake -----
    ("system_sleep", "backend"):  ("Klient i dvale — kiosk browser lukket, skærm slukket", "blue"),
    ("system_sleep", "manual"):   ("Klient i dvale — kiosk browser lukket, skærm slukket", "blue"),
    ("system_sleep", "calendar"): ("Klient i dvale fra kalender — kiosk browser lukket, skærm slukket", "blue"),

    ("system_wake", "backend"):   ("Klient vækket fra dvale — skærm tændt", "green"),
    ("system_wake", "manual"):    ("Klient vækket fra dvale — skærm tændt", "green"),
    ("system_wake", "calendar"):  ("Klient vækket fra kalender — skærm tændt", "green"),

    ("system_sleep_process_report", "backend"):  ("Processer stoppet ved dvale: {detail}", "blue"),
    ("system_sleep_process_report", "manual"):   ("Processer stoppet ved dvale: {detail}", "blue"),
    ("system_sleep_process_report", "calendar"): ("Processer stoppet ved dvale: {detail}", "blue"),
    ("system_sleep_process_report", "sleep"):    ("Processer stoppet ved dvale: {detail}", "blue"),

    ("system_wake_complete", "backend"):  ("Klient vækket og initialiseret", "green"),
    ("system_wake_complete", "calendar"): ("Klient vækket fra kalender og initialiseret", "green"),
    ("system_sleep_complete", "backend"): ("Klient sat i dvale", "blue"),
    ("system_sleep_complete", "calendar"):("Klient sat i dvale fra kalender", "blue"),

    # ----- system_rebooting -----
    # FIX: ingen debug-suffixer, "wakeup" er den eneste der nævner "efter dvale"
    ("system_rebooting", "pending_reboot"): ("Klient genstarter…", "red"),
    ("system_rebooting", "wakeup"):         ("Klient genstarter efter dvale…", "red"),
    ("system_rebooting", "calendar"):       ("Klient genstarter efter kalender-vækning…", "red"),
    ("system_rebooting", "backend"):        ("Klient genstarter…", "red"),
    ("system_rebooting", "manual"):         ("Klient genstarter efter manuel vækning…", "red"),

    # FIX: "Klient lukker ned…" — kortere og konsistent med chrome_kiosk.py
    ("system_shutting_down", "pending_shutdown"): ("Klient lukker ned…", "red"),

    ("reboot_failed", "pending_reboot"):  ("Genstart fejlede", "red"),
    ("reboot_success", "pending_reboot"): ("Genstart igangsat", "red"),

    # ----- system_reboot_countdown -----
    # FIX: ingen debug-suffixer, "wakeup"/"calendar"/"manual" nævner kontekst
    ("system_reboot_countdown", "backend"):       ("Klient genstarter om {X} sekund{plural}…", "orange"),
    ("system_reboot_countdown", "wakeup"):        ("Klient genstarter efter dvale om {X} sekund{plural}…", "orange"),
    ("system_reboot_countdown", "calendar"):      ("Klient genstarter om {X} sekund{plural} efter kalender-vækning…", "orange"),
    ("system_reboot_countdown", "manual"):        ("Klient genstarter om {X} sekund{plural} efter manuel vækning…", "orange"),
    ("system_reboot_countdown", "pending_reboot"):("Klient genstarter om {X} sekund{plural}…", "orange"),

    # ----- power / display -----
    ("power_state_change", "system"):  ("Skiftet strømtilstand: {state}", "orange"),
    ("dpms_off_failed", "system"):     ("Kunne ikke slukke skærm via DPMS", "orange"),
    ("dpms_on_failed", "system"):      ("Kunne ikke tænde skærm via DPMS", "orange"),
    ("cec_standby_failed", "system"):  ("HDMI‑CEC standby fejlede", "orange"),
    ("cec_power_on_failed", "system"): ("HDMI‑CEC power on fejlede", "orange"),
    ("cec_unavailable", "system"):     ("Cec-client ikke installeret", "orange"),

    # ----- chrome update / extensions -----
    ("chrome_updated", "system"):      ("Chrome opdateret — genstarter browser", "orange"),
    ("chrome_update_failed", "system"):("Opdatering af Chrome fejlede", "red"),
    ("extensions_blocked", "system"):  ("Udvidelser blokeret/ændret", "orange"),

    # ----- livestream -----
    ("livestream_started", "backend"):        ("Livestream startet", "green"),
    ("livestream_stopped", "backend"):        ("Livestream stoppet", "orange"),
    ("livestream_error", "system"):           ("Fejl i livestream: {detail}", "red"),
    ("livestream_segment_created", "system"): ("Nyt livestream-segment oprettet", "green"),
    ("livestream_status", "system"):          ("Livestream status: {detail}", "orange"),

    # ----- camera / audio -----
    ("camera_error", "system"): ("Fejl ved kamera: {detail}", "red"),
    ("no_camera", "system"):    ("Kamera ikke fundet", "red"),
    ("audio_error", "system"):  ("Fejl ved lydoptagelse: {detail}", "red"),

    # ----- registration / config / network / auth -----
    ("registered", "system"):           ("Klient registreret hos backend", "green"),
    ("registration_failed", "system"):  ("Registrering hos backend fejlede", "red"),
    ("config_updated", "backend"):      ("Konfiguration hentet og opdateret", "green"),
    ("config_update_failed", "backend"):("Kunne ikke hente konfiguration", "red"),
    ("network_lost", "system"):         ("Netværk mistet", "red"),
    ("network_restored", "system"):     ("Netværk genoprettet", "green"),
    ("auth_failed", "system"):          ("Fejl ved backend-login (auth)", "red"),
    ("token_refreshed", "system"):      ("Access token fornyet", "green"),
    ("heartbeat_sent", "system"):       ("Heartbeat sendt", "green"),

    # ----- disk / cpu / memory -----
    ("disk_space_low", "system"): ("Lav diskplads", "red"),
    ("disk_space_ok", "system"):  ("Diskplads OK", "green"),
    ("cpu_high", "system"):       ("Høj CPU‑belastning", "orange"),
    ("memory_high", "system"):    ("Høj hukommelsesbrug", "orange"),

    # ----- profile / cookies -----
    ("profile_reset", "manual"): ("Browserprofil nulstillet manuelt", "orange"),

    # ----- generic -----
    ("unknown_event", "system"): ("Ukendt event modtaget: {detail}", "black"),
    ("info", "system"):          ("Info: {detail}", "black"),
}


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------
def _pluralize_dk(n: int) -> str:
    """Dansk pluralisering: '1 sekund' / '2 sekunder'."""
    try:
        return "" if abs(int(n)) == 1 else "er"
    except Exception:
        return "er"


def format_message(step: str, trigger: Any, **kwargs: Any) -> Tuple[str, str]:
    """
    Returnér (besked, farve) for et givet step+trigger.
    kwargs kan indeholde: X (for countdown), detail, state, m.fl.
    """
    trig_norm = _normalize_trigger(trigger)

    # Lookup-prioritet:
    #   1. (step, normaliseret trigger)
    #   2. (step, original trigger)
    #   3. (step, "backend")  -- generisk fallback
    tpl = (
        STATUS_MAP.get((step, trig_norm))
        or STATUS_MAP.get((step, trigger))
        or STATUS_MAP.get((step, "backend"))
    )
    if not tpl:
        return fallback_status_message(step, str(trigger))

    msg_tpl, color = tpl

    # Templating
    if "{X}" in msg_tpl:
        try:
            X = int(kwargs.get("X", 0) or 0)
        except (TypeError, ValueError):
            X = 0
        plural = _pluralize_dk(X)
        try:
            msg = msg_tpl.format(X=X, plural=plural, **kwargs)
        except Exception:
            msg = msg_tpl.replace("{X}", str(X)).replace("{plural}", plural)
    else:
        try:
            msg = msg_tpl.format(**kwargs)
        except Exception:
            msg = msg_tpl
    return msg, color


def get_color(step: str, trigger: Any, **kwargs: Any) -> str:
    """Helper: returnér kun farven."""
    _, color = format_message(step, trigger, **kwargs)
    return color


def get_message(step: str, trigger: Any, **kwargs: Any) -> str:
    """Helper: returnér kun beskeden."""
    msg, _ = format_message(step, trigger, **kwargs)
    return msg


# ---------------------------------------------------------------------------
# Selvtest
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    test_cases = [
        ("system_sleep", "calendar"),
        ("system_wake", "manual"),
        ("system_wake", "calendar"),
        ("countdown", "calendar", {"X": 5}),
        ("countdown", "sleep", {"X": 1}),
        ("system_reboot_countdown", "calendar", {"X": 15}),
        ("system_reboot_countdown", "wakeup", {"X": 1}),
        ("start_chrome", "calendar"),
        ("shutdown_chrome", "calendar"),
        ("terminate_chrome", "manual"),
        ("clear_cookies", "backend"),
        ("system_shutting_down", "pending_shutdown"),
        ("system_rebooting", "pending_reboot"),
        ("system_rebooting", "wakeup"),
        # Aliasser:
        ("system_sleep", "calendar_backend_sleep_wakeup"),
        ("system_wake", "actionbutton_backend_sleep_wakeup"),
        # Ukendt:
        ("foo_bar", "unknown_trigger"),
    ]
    for tc in test_cases:
        if len(tc) == 3:
            step, trig, kw = tc
        else:
            step, trig = tc
            kw = {}
        msg, color = format_message(step, trig, **kw)
        print(f"  {step:40s} | {trig:35s} -> [{color:8s}] {msg}")
