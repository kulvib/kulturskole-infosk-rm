// ClientFlow Kiosk Protection v3.8.0
// CSS + MAIN world script. Designed to work without Tampermonkey.

(function () {
  'use strict';

  const VERSION = '3.8.0';

  const REFRESH_INTERVAL_SEC = 15 * 60;
  const TICK_MS = 1000;
  const HIDE_CHECK_MS = 500;
  const SHOW_REFRESH_BAR = true;
  const HIDE_BAR_IN_HTML_FULLSCREEN = true;
  const HIDE_BAR_IN_BROWSER_FULLSCREEN = true;

  const BAR_ID = 'tm-kiosk-bar';
  const TEXT_ID = 'tm-kiosk-text';

  const COOKIE_WORDS = [
    'cookie', 'cookies', 'samtykke', 'consent', 'privatliv',
    'personoplysninger', 'persondata', 'gdpr', 'marketing',
    'statistik', 'funktionelle', 'nødvendige', 'cookie information',
    'powered by cookie information', 'du bestemmer over dine data',
    'vi og vores samarbejdspartnere bruger teknologier'
  ];

  const HARD_SELECTORS = [
    '#coiOverlay',
    '#coiConsentBanner',
    '#coi-banner-wrapper',
    '#coiPage-1',
    '#coiPage-2',
    '.coi-overlay',
    '.coi-banner__wrapper',
    '.coi-banner__page',
    '.coi-banner__summary',
    '[class*="coi-banner" i]',
    '[id^="coi" i]',
    '[class^="coi" i]',
    '[class*=" coi" i]',
    'iframe[src*="cookieinformation" i]',
    'iframe[src*="consent.cookieinformation" i]',
    'iframe[title*="cookie" i]',
    'iframe[title*="consent" i]',
    'iframe[name*="cookie" i]',
    'iframe[id*="cookie" i]',
    'iframe[class*="cookie" i]',

    '#CybotCookiebotDialog',
    '#CybotCookiebotDialogBodyUnderlay',
    '#CookiebotWidget',
    '[id^="CybotCookiebot" i]',
    '[class*="CybotCookiebot" i]',
    'iframe[src*="cookiebot" i]',

    '#usercentrics-root',
    '[data-testid="uc-app-container"]',
    '[data-testid="uc-overlay"]',
    '#uc-center-container',
    '#uc-banner-centered',
    '#uc-banner-modal',
    '.uc-banner',
    '.uc-overlay',
    'iframe[src*="usercentrics" i]',

    '#onetrust-banner-sdk',
    '#onetrust-consent-sdk',
    '.ot-sdk-container',
    '.didomi-popup-container',
    '.didomi-consent-popup',
    '.qc-cmp2-container',
    '.qc-cmp2-summary-section',
    '.cc-window',

    '.cookie-banner',
    '.cookie-consent',
    '.cookie-box',
    '.cookie-notice',
    '.consent-banner',
    '.consent-modal',
    '.CookieConsent',
    '.cookiescript_injected',
    '[role="dialog"]',
    '[aria-modal="true"]',
    'dialog'
  ];

  const ACCEPT_SELECTORS = [
    '#acceptButton',
    '#updateButton',
    '.coi-banner__accept',
    '.coi-banner__lastpage',
    '#CybotCookiebotDialogBodyLevelButtonLevelOptinAllowAll',
    '#CybotCookiebotDialogBodyButtonAccept',
    '#CybotCookiebotDialogBodyLevelButtonAccept',
    '[data-testid="uc-accept-all-button"]',
    '[data-testid="uc-save-button"]',
    '#onetrust-accept-btn-handler',
    '.cc-accept',
    '.accept-all',
    '.cookie-accept'
  ];

  const REJECT_SELECTORS = [
    '#declineButton',
    '.coi-banner__decline',
    '#CybotCookiebotDialogBodyButtonDecline',
    '[data-testid="uc-deny-all-button"]',
    '#onetrust-reject-all-handler',
    '.cc-deny',
    '.reject-all',
    '.cookie-reject'
  ];

  const ACCEPT_TEXT = /(accept all|accept cookies|allow all|agree|i agree|ok|got it|continue|save|save settings|acceptér|accepter|accepter alle|accepter alle cookies|jeg accepterer|tillad alle|gem valg|gem indstillinger|godkend|forstået|fortsæt)/i;
  const REJECT_TEXT = /(reject all|decline all|deny all|refuse all|afvis alle|afvis|nej tak|kun nødvendige|nødvendige cookies|necessary only|kun nødvendige cookies)/i;
  const CLOSE_TEXT = /(close|dismiss|skip|no thanks|not now|maybe later|luk|lukke|spring over|fortsæt uden|senere)/i;

  function log(...args) {
    try { console.warn('[ClientFlow Kiosk ' + VERSION + ']', ...args); } catch (_) {}
  }

  function markLoaded() {
    try {
      document.documentElement.setAttribute('data-clientflow-kiosk-protection', VERSION);
    } catch (_) {}
  }

  function norm(s) {
    return String(s || '').replace(/\s+/g, ' ').trim().toLowerCase();
  }

  function isOwnUi(el) {
    if (!el || !el.getAttribute) return false;
    const id = el.getAttribute('id') || '';
    return id === BAR_ID || id === TEXT_ID || id === 'clientflow-kiosk-css';
  }

  function safeStyleHide(el, reason) {
    if (!el || isOwnUi(el)) return false;
    try {
      el.setAttribute('data-clientflow-kiosk-hidden', reason || 'hidden');
      el.style.setProperty('display', 'none', 'important');
      el.style.setProperty('visibility', 'hidden', 'important');
      el.style.setProperty('pointer-events', 'none', 'important');
      el.style.setProperty('opacity', '0', 'important');
      return true;
    } catch (_) {
      return false;
    }
  }

  function isVisible(el) {
    try {
      if (!el || !el.getBoundingClientRect) return false;
      const r = el.getBoundingClientRect();
      if (r.width === 0 && r.height === 0) return false;
      const s = getComputedStyle(el);
      return s.display !== 'none' && s.visibility !== 'hidden' && parseFloat(s.opacity || '1') > 0;
    } catch (_) {
      return false;
    }
  }

  function txt(el) {
    try {
      return String(el.innerText || el.textContent || el.value || el.getAttribute('aria-label') || el.getAttribute('title') || '').trim();
    } catch (_) {
      return '';
    }
  }

  function zIndex(el) {
    try {
      const n = parseInt(getComputedStyle(el).zIndex, 10);
      return Number.isFinite(n) ? n : 0;
    } catch (_) {
      return 0;
    }
  }

  function hasCookieWords(el) {
    const t = norm(txt(el));
    if (COOKIE_WORDS.some(w => t.includes(w))) return true;

    try {
      const meta = norm([
        el.id,
        el.className,
        el.getAttribute && el.getAttribute('role'),
        el.getAttribute && el.getAttribute('aria-label'),
        el.getAttribute && el.getAttribute('aria-describedby'),
        el.getAttribute && el.getAttribute('aria-labelledby'),
        el.getAttribute && el.getAttribute('src'),
        el.getAttribute && el.getAttribute('title'),
        el.getAttribute && el.getAttribute('name'),
      ].join(' '));
      return COOKIE_WORDS.some(w => meta.includes(w));
    } catch (_) {
      return false;
    }
  }

  function likelyCookieOrOverlay(el) {
    if (!el || isOwnUi(el) || !isVisible(el)) return false;
    if (hasCookieWords(el)) return true;

    try {
      const s = getComputedStyle(el);
      const r = el.getBoundingClientRect();
      const vw = Math.max(document.documentElement.clientWidth, innerWidth || 0);
      const vh = Math.max(document.documentElement.clientHeight, innerHeight || 0);
      const area = r.width * r.height;
      const viewport = vw * vh;
      const idc = norm((el.id || '') + ' ' + (el.className || ''));

      if (/(cookie|consent|cmp|coi|cybot|usercentrics|didomi|onetrust|modal|popup|overlay|dialog)/i.test(idc)) {
        return true;
      }

      if ((s.position === 'fixed' || s.position === 'absolute' || s.position === 'sticky') &&
          zIndex(el) >= 50 &&
          (area > viewport * 0.05 || r.width > vw * 0.35 || r.height > vh * 0.20)) {
        return true;
      }
    } catch (_) {}

    return false;
  }

  function click(el) {
    try {
      el.click();
      return true;
    } catch (_) {
      try {
        el.dispatchEvent(new MouseEvent('click', { bubbles: true, cancelable: true }));
        return true;
      } catch (__) {}
    }
    return false;
  }

  function clickCookieButtons(root) {
    for (const sel of ACCEPT_SELECTORS.concat(REJECT_SELECTORS)) {
      try {
        const el = root.querySelector(sel);
        if (el && isVisible(el)) {
          log('Klik selector', sel);
          click(el);
          return true;
        }
      } catch (_) {}
    }

    let buttons = [];
    try {
      buttons = Array.from(root.querySelectorAll('button, a, input[type=button], input[type=submit], [role="button"]'));
    } catch (_) {}

    for (const b of buttons) {
      if (!isVisible(b)) continue;
      const t = txt(b);
      if (ACCEPT_TEXT.test(t)) {
        log('Klik accept tekst', t);
        click(b);
        return true;
      }
    }

    for (const b of buttons) {
      if (!isVisible(b)) continue;
      const t = txt(b);
      if (REJECT_TEXT.test(t) || CLOSE_TEXT.test(t)) {
        log('Klik fallback tekst', t);
        click(b);
        return true;
      }
    }

    return false;
  }

  function restorePage() {
    try {
      document.documentElement.style.setProperty('overflow', 'auto', 'important');
      document.body && document.body.style.setProperty('overflow', 'auto', 'important');
      document.documentElement.style.setProperty('pointer-events', 'auto', 'important');
      document.body && document.body.style.setProperty('pointer-events', 'auto', 'important');

      ['modal-open', 'no-scroll', 'noscroll', 'cookie-open', 'coi-banner-open', 'coi-modal-open'].forEach(c => {
        document.documentElement.classList.remove(c);
        document.body && document.body.classList.remove(c);
      });
    } catch (_) {}
  }

  function hideHardSelectors(root) {
    for (const sel of HARD_SELECTORS) {
      try {
        root.querySelectorAll(sel).forEach(el => {
          if (isOwnUi(el)) return;
          safeStyleHide(el, 'hard-selector');
        });
      } catch (_) {}
    }
  }

  function hideUniversal(root) {
    try {
      root.querySelectorAll('div, section, aside, dialog, form, iframe').forEach(el => {
        if (likelyCookieOrOverlay(el)) {
          safeStyleHide(el, hasCookieWords(el) ? 'cookie-text' : 'overlay-heuristic');
        }
      });
    } catch (_) {}
  }

  function handleRoot(root) {
    markLoaded();
    clickCookieButtons(root);
    hideHardSelectors(root);
    hideUniversal(root);
    restorePage();
  }

  function handleIframes() {
    try {
      document.querySelectorAll('iframe').forEach(ifr => {
        if (likelyCookieOrOverlay(ifr)) safeStyleHide(ifr, 'iframe-cookie');
        try {
          const d = ifr.contentDocument || (ifr.contentWindow && ifr.contentWindow.document);
          if (d) handleRoot(d);
        } catch (_) {}
      });
    } catch (_) {}
  }

  function openShadowRoots(root) {
    const roots = [];
    try {
      root.querySelectorAll('*').forEach(el => {
        try { if (el.shadowRoot) roots.push(el.shadowRoot); } catch (_) {}
      });
    } catch (_) {}
    return roots;
  }

  function handleEverywhere() {
    handleRoot(document);
    openShadowRoots(document).forEach(sr => {
      try { handleRoot(sr); } catch (_) {}
    });
    handleIframes();
  }

  function patchShadow() {
    try {
      const orig = Element.prototype.attachShadow;
      if (!orig || orig.__clientflow_v37) return;

      const patched = function(init) {
        const sr = orig.call(this, init);
        try {
          setTimeout(() => {
            handleRoot(sr);
            new MutationObserver(() => handleRoot(sr)).observe(sr, {
              childList: true,
              subtree: true,
              attributes: true,
              attributeFilter: ['class', 'style', 'id', 'role', 'aria-modal', 'aria-label'],
            });
          }, 0);
        } catch (_) {}
        return sr;
      };

      patched.__clientflow_v37 = true;
      Element.prototype.attachShadow = patched;
    } catch (_) {}
  }

  // Native dialog/window APIs. MAIN world makes this effective against page scripts.
  (function blockNative() {
    const noop = function(){};
    const yes = function(){ return true; };
    const nil = function(){ return null; };

    try { window.alert = noop; } catch (_) {}
    try { window.confirm = yes; } catch (_) {}
    try { window.prompt = nil; } catch (_) {}
    try { window.print = noop; } catch (_) {}
    try { window.open = function(){ return { closed: true, close(){}, focus(){}, blur(){}, postMessage(){}, location:{href:'about:blank'} }; }; } catch (_) {}

    try {
      Object.defineProperty(window, 'alert', { value: noop, writable: false, configurable: false });
      Object.defineProperty(window, 'confirm', { value: yes, writable: false, configurable: false });
      Object.defineProperty(window, 'prompt', { value: nil, writable: false, configurable: false });
      Object.defineProperty(window, 'print', { value: noop, writable: false, configurable: false });
    } catch (_) {}

    addEventListener('beforeunload', e => {
      try {
        e.stopImmediatePropagation();
        delete e.returnValue;
        e.returnValue = undefined;
      } catch (_) {}
    }, true);
  })();

  function isAnyFullscreen() {
    try {
      if (HIDE_BAR_IN_HTML_FULLSCREEN && (document.fullscreenElement || document.webkitFullscreenElement || document.querySelector(':fullscreen'))) return true;
    } catch (_) {}

    if (!HIDE_BAR_IN_BROWSER_FULLSCREEN) return false;
    try {
      const h = Math.abs(outerHeight - screen.height) <= 2 || Math.abs(innerHeight - screen.height) <= 2;
      const w = Math.abs(outerWidth - screen.width) <= 2 || Math.abs(innerWidth - screen.width) <= 2;
      if (h && w) return true;
      if (innerHeight >= screen.availHeight - 2 && innerWidth >= screen.availWidth - 2) return true;
    } catch (_) {}

    return false;
  }

  function createBar() {
    if (!SHOW_REFRESH_BAR) return;
    if (!document.body && !document.documentElement) return;
    if (document.getElementById(BAR_ID)) return;

    const bar = document.createElement('div');
    bar.id = BAR_ID;
    const t = document.createElement('div');
    t.id = TEXT_ID;

    const set = (el, styles) => {
      Object.entries(styles).forEach(([k, v]) => {
        try { el.style.setProperty(k, v, 'important'); } catch (_) {}
      });
    };

    set(bar, {
      position: 'fixed', top: '0', left: '0', height: '6px', width: '100%',
      'transform-origin': 'left center', transform: 'scaleX(0)',
      background: 'linear-gradient(90deg, rgba(0,150,136,.95), rgba(76,175,80,.95))',
      'z-index': '2147483647', 'pointer-events': 'none',
      transition: 'transform 0.9s linear, opacity 0.2s',
      display: 'block', visibility: 'visible', opacity: '1'
    });

    set(t, {
      position: 'fixed', top: '8px', right: '10px', padding: '3px 6px',
      background: 'rgba(0,0,0,.6)', color: '#fff', 'font-size': '12px',
      'border-radius': '4px', 'z-index': '2147483647',
      'pointer-events': 'none', 'font-family': 'sans-serif',
      'line-height': '1', display: 'block', visibility: 'visible', opacity: '1'
    });

    try {
      (document.body || document.documentElement).appendChild(bar);
      (document.body || document.documentElement).appendChild(t);
    } catch (_) {}
  }

  function updateBar(elapsed, total) {
    if (!SHOW_REFRESH_BAR) return;
    createBar();

    const hidden = isAnyFullscreen();
    const pct = Math.max(0, Math.min(1, elapsed / total));
    const b = document.getElementById(BAR_ID);
    const t = document.getElementById(TEXT_ID);

    const set = (el, styles) => {
      if (!el) return;
      el.removeAttribute('data-clientflow-kiosk-hidden');
      Object.entries(styles).forEach(([k, v]) => {
        try { el.style.setProperty(k, v, 'important'); } catch (_) {}
      });
    };

    set(b, {
      display: hidden ? 'none' : 'block',
      visibility: hidden ? 'hidden' : 'visible',
      opacity: hidden ? '0' : '1',
      transform: `scaleX(${pct})`,
      'z-index': '2147483647'
    });

    if (t) {
      const left = Math.max(0, total - elapsed);
      const m = Math.floor(left / 60);
      const s = left % 60;
      t.textContent = `Opdaterer om ${m}:${String(s).padStart(2, '0')}`;
    }

    set(t, {
      display: hidden ? 'none' : 'block',
      visibility: hidden ? 'hidden' : 'visible',
      opacity: hidden ? '0' : '1',
      'z-index': '2147483647'
    });
  }

  function isUserTyping() {
    const ae = document.activeElement;
    return !!(ae && (
      ae.tagName === 'INPUT' ||
      ae.tagName === 'TEXTAREA' ||
      ae.tagName === 'SELECT' ||
      ae.isContentEditable
    ));
  }

  function hardRefresh() {
    try {
      const url = new URL(location.href);
      url.searchParams.set('_kiosk_refresh', Date.now().toString());
      location.replace(url.toString());
    } catch (_) {
      try { location.reload(); } catch (__) {}
    }
  }

  function start() {
    patchShadow();
    markLoaded();
    createBar();
    handleEverywhere();

    let startTime = Date.now();

    try {
      new MutationObserver(() => handleEverywhere()).observe(document.documentElement || document.body, {
        childList: true,
        subtree: true,
        attributes: true,
        attributeFilter: ['class', 'style', 'id', 'role', 'aria-modal', 'aria-label', 'src', 'title', 'name'],
      });
    } catch (_) {}

    const aggressive = setInterval(handleEverywhere, HIDE_CHECK_MS);

    const tick = setInterval(() => {
      const elapsed = Math.floor((Date.now() - startTime) / 1000);
      updateBar(elapsed, REFRESH_INTERVAL_SEC);

      if (elapsed >= REFRESH_INTERVAL_SEC) {
        if (isUserTyping()) {
          startTime = Date.now() + 10000;
          return;
        }
        handleEverywhere();
        setTimeout(hardRefresh, 300);
        startTime = Date.now();
      }
    }, TICK_MS);

    const fsHandler = () => {
      const elapsed = Math.floor((Date.now() - startTime) / 1000);
      updateBar(elapsed, REFRESH_INTERVAL_SEC);
      setTimeout(() => updateBar(Math.floor((Date.now() - startTime) / 1000), REFRESH_INTERVAL_SEC), 150);
      setTimeout(() => updateBar(Math.floor((Date.now() - startTime) / 1000), REFRESH_INTERVAL_SEC), 600);
    };

    addEventListener('resize', fsHandler, { passive: true });
    ['fullscreenchange', 'webkitfullscreenchange', 'mozfullscreenchange', 'MSFullscreenChange'].forEach(evt => {
      document.addEventListener(evt, fsHandler);
    });

    addEventListener('beforeunload', () => {
      clearInterval(aggressive);
      clearInterval(tick);
    });
  }

  if (document.readyState === 'loading') {
    try { markLoaded(); } catch (_) {}
    document.addEventListener('DOMContentLoaded', start, { once: true });
  } else {
    start();
  }
})();
