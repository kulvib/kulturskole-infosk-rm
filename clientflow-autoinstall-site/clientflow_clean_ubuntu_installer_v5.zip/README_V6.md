# ClientFlow clean Ubuntu installer v6.5

Stabil v5 installer med enrollment/client-secret-flow, kiosk-hardening, Xorg/autologin og backend-triggeret ClientFlow self-update.

Nyheder i v6.5:
- Musecursor skjules automatisk efter 10 sekunders inaktivitet i kiosk/Xorg-sessionen.
- GDM sættes til både AutomaticLogin og TimedLogin, så klienten logger automatisk ind igen, hvis Xorg/GDM falder tilbage til login efter display-hotplug.
- Klienten kan modtage pending_chrome_action=clientflow_update fra backend.
- Self-update kører som root one-shot service og bevarer /etc/clientflow/clientflow.env.
- Self-update henter manifest fra https://autoinstall.onrender.com/clientflow_version.json og verificerer SHA256.
- OS-opdatering og ClientFlow-opdatering er adskilt.
- Bluetooth slås fra automatisk for kioskdrift.
- Lokale printer-/discovery-tjenester slås fra, hvis de findes, for at undgå popups og reducere støj.

## v6.5

- Display-hotplug-hærdning: gentaget GDM autologin efter logout/login-skærm.
- Ved kritiske kiosker anbefales stadig HDMI/DP EDID dummy/emulator, hvis kabel eller skærm kan blive fjernet.

## v6.5

- Samlet stabil release baseret på v5.8.
- Kioskinfo-rækkefølge ændret: Status vises før Kiosk browser status.
- Ingen tom linje mellem Status og Kiosk browser status.


## v6.5

- Bluetooth deaktiveres automatisk via systemd/rfkill.
- Printer/CUPS, Avahi og ModemManager slås fra, hvis de findes.
- NetworkManager, USB, tastatur/mus og ClientFlow-services berøres ikke.

## v6.5 admin/root terminal

v6.5 tilføjer en separat `client_admin_terminal_agent.service`, som kører som root og forbinder til backend med terminal-mode `admin`. Den almindelige remote desktop viser fortsat kioskbrugerens Xorg-session, og den almindelige `client_terminal_agent.service` kører fortsat som kioskbrugeren.

Backend skal understøtte terminal-mode `admin`/`root` for at bruge denne funktion, og frontend bør kun vise Root/Admin terminal for superadmin.
