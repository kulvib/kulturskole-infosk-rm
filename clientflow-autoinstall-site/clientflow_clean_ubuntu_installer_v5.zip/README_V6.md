# ClientFlow Clean Ubuntu Installer v6.9

Stabil v6-installer.

Ændringer i v6.9:
- GUI viser LAN IP kun hvis LAN-interface reelt har link/carrier og IPv4.
- GUI bruger live lokal netværksstatus til WiFi/LAN IP, ikke stale backend-config.
- Kalenderfil til GUI skriver 5 dage frem.

Øvrige v6-funktioner er bevaret: enrollment, Xorg/autologin, kiosk-hardening, self-update,
admin/root terminal-agent og backend-triggeret ClientFlow update.
