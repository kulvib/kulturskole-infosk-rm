# ClientFlow Clean Ubuntu Installer v5.4

V5.4 bruger kun enrollment/client-secret-flow.

Nyheder i v5.4:

- GUI Netværksinfo viser nu aktiv forbindelse, aktiv IP, aktivt interface og aktiv MAC ud fra default route.
- GUI viser stadig WiFi IP/MAC og LAN IP/MAC som separate adapteroplysninger.
- GUI kalenderoversigt viser nu kun 5 dage frem.

Videreført fra v5:

- Konfigurerer GDM til automatisk login på Xorg-session (`Ubuntu on Xorg`).
- Kører fuld Ubuntu-/app-opdatering ved installation og geninstallation/opdatering.
- Konfigurerer kiosk-hardening, så system-popups, crash-dialoger, update-notifier, skærmlås og sleep reduceres/deaktiveres.
- Understøtter re-registrering med ny installationskode, hvis klienten er slettet i backend.
- Understøtter geninstallation/opdatering fra Render uden at skifte client credentials.
- GUI viser tydeligt `Pending / Venter på godkendelse`, `Approved / Godkendt` og `Kalender: Off`/venter på aktiv visningstid.
- Efter installation er Enter ved reboot-spørgsmålet også et ja.

Den gamle manuelle client-secret-installation er fjernet.
