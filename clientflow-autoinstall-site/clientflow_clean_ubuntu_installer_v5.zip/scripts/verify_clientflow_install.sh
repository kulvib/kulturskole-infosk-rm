#!/usr/bin/env bash
set -euo pipefail

USER_NAME="${1:-${SUDO_USER:-${USER}}}"
USER_HOME="$(getent passwd "$USER_NAME" | cut -d: -f6)"
API_DIR="${USER_HOME}/api"

echo "=== ClientFlow verify ==="
echo "USER_NAME=$USER_NAME"
echo "API_DIR=$API_DIR"
echo

echo "=== Python syntax ==="
if [[ -x "${API_DIR}/venv/bin/python" ]]; then
  (cd "$API_DIR" && "${API_DIR}/venv/bin/python" -m py_compile *.py) && echo "Python OK"
else
  echo "FEJL: venv python mangler: ${API_DIR}/venv/bin/python"
fi

echo
echo "=== Services ==="
systemctl is-active \
  clientflow_service.service \
  clientflow_calendar.service \
  clientflow_browser_guard.service \
  client_terminal_agent.service \
  client_admin_terminal_agent.service \
  client_remote_desktop_agent.service \
  clientflow_kiosk_x11_guard.service \
  clientflow_hide_cursor.service \
  clientflow_self_update.service \
  clientflow-disable-bluetooth.service || true

echo
echo "=== Env redacted ==="
if [[ -f /etc/clientflow/clientflow.env ]]; then
  sudo sed -E \
    -e 's/CLIENTFLOW_PASSWORD=.*/CLIENTFLOW_PASSWORD=***/' \
    -e 's/CLIENTFLOW_CLIENT_SECRET=.*/CLIENTFLOW_CLIENT_SECRET=***/' \
    /etc/clientflow/clientflow.env
else
  echo "Mangler /etc/clientflow/clientflow.env"
fi


echo
echo "=== Security ==="
if id -nG "$USER_NAME" 2>/dev/null | tr ' ' '\n' | grep -qx sudo; then
  echo "Kiosk user sudo: YES"
else
  echo "Kiosk user sudo: NO"
fi
if [[ -f /etc/clientflow/clientflow.env ]]; then
  stat -c "clientflow.env permissions: %U:%G %a" /etc/clientflow/clientflow.env 2>/dev/null || true
fi
systemctl is-enabled ssh.service 2>/dev/null | sed 's/^/ssh.service: /' || echo "ssh.service: not installed/disabled"
if command -v ufw >/dev/null 2>&1; then
  ufw status 2>/dev/null | head -10 || true
fi

echo
echo "=== Chrome process / port ==="
pgrep -af 'google-chrome|chromium' || echo "Ingen Chrome/Chromium process"
ss -ltnp | grep 9222 || echo "9222 lytter ikke"

echo
echo "=== Browser Guard recent ==="
journalctl -u clientflow_browser_guard.service --since "5 minutes ago" --no-pager -l \
  | grep -E "marker=1.2.0|overlay|hidden=|status|FEJL|Connection refused" \
  | tail -80 || true

echo
echo "=== Service recent ==="
journalctl -u clientflow_service.service --since "5 minutes ago" --no-pager -l \
  | grep -E "GUI startet|pending_chrome_action='none'|Chrome lukket manuelt|Uventet fejl ved sletning|Fjernede mappe|ERROR|FEJL" \
  | tail -120 || true

echo
echo "=== Token test, hvis credentials findes ==="
set +e
if [[ -f /etc/clientflow/clientflow.env ]]; then
  set -a
  # shellcheck disable=SC1091
  . /etc/clientflow/clientflow.env
  set +a
  if [[ -n "${CLIENTFLOW_CLIENT_ID:-}" && -n "${CLIENTFLOW_CLIENT_SECRET:-}" && -n "${CLIENTFLOW_BASE_URL:-}" ]]; then
    curl -i -s -X POST "${CLIENTFLOW_BASE_URL}/auth/client-token" \
      -H "Content-Type: application/json" \
      -d "{\"client_id\":${CLIENTFLOW_CLIENT_ID},\"client_secret\":\"${CLIENTFLOW_CLIENT_SECRET}\"}" \
      | sed -E 's/(access_token":"?)[A-Za-z0-9._-]+/\1***/g; s/(client_secret":"?)[^",}]+/\1***/g' \
      | head -40
  else
    echo "Springer token-test over: CLIENTFLOW_CLIENT_ID/SECRET mangler."
  fi
fi
set -e
