#!/usr/bin/env bash
set -euo pipefail

# ClientFlow client security hardening.
# Formål: Kiosk-brugeren skal kunne køre ClientFlow, men ikke have fri admin/sudo-adgang.
# Scriptet er konservativt: det fjerner kun kiosk-brugeren fra sudo, hvis der findes en anden sudo-bruger.

CLIENTFLOW_USER="${1:-${SUDO_USER:-}}"
if [[ -z "${CLIENTFLOW_USER}" || "${CLIENTFLOW_USER}" == "root" ]]; then
  echo "FEJL: Angiv klientbrugeren: sudo bash configure_client_security.sh <client-user>"
  exit 1
fi

if ! id "${CLIENTFLOW_USER}" >/dev/null 2>&1; then
  echo "FEJL: Brugeren findes ikke: ${CLIENTFLOW_USER}"
  exit 1
fi

KEEP_SSH="${CLIENTFLOW_KEEP_SSH:-0}"
LOCKDOWN_SUDO="${CLIENTFLOW_LOCKDOWN_SUDO:-1}"
ENABLE_UFW="${CLIENTFLOW_ENABLE_UFW:-1}"

USER_HOME="$(getent passwd "${CLIENTFLOW_USER}" | cut -d: -f6)"

echo "Konfigurerer ClientFlow sikkerhed for ${CLIENTFLOW_USER}..."

# 1) Beskyt client credentials. systemd læser EnvironmentFile som root før User= anvendes,
# så services kan stadig få variablerne selvom filen er root-only.
mkdir -p /etc/clientflow
chmod 700 /etc/clientflow || true
if [[ -f /etc/clientflow/clientflow.env ]]; then
  chown root:root /etc/clientflow/clientflow.env
  chmod 600 /etc/clientflow/clientflow.env
fi

# 2) Sluk SSH som default på kiosk-klienter. Kan bevares eksplicit med CLIENTFLOW_KEEP_SSH=1.
if [[ "${KEEP_SSH}" == "1" ]]; then
  echo "SSH bevares pga. CLIENTFLOW_KEEP_SSH=1"
else
  systemctl disable --now ssh.service 2>/dev/null || true
  systemctl disable --now ssh.socket 2>/dev/null || true
fi

# 3) UFW: nægt indgående, tillad udgående. ClientFlow bruger primært udgående HTTPS/WebSocket.
if [[ "${ENABLE_UFW}" == "1" ]]; then
  if command -v ufw >/dev/null 2>&1; then
    ufw default deny incoming >/dev/null 2>&1 || true
    ufw default allow outgoing >/dev/null 2>&1 || true
    ufw --force enable >/dev/null 2>&1 || true
  fi
fi

# 4) Fjern kiosk-brugeren fra sudo-gruppen, men kun hvis der er mindst én anden sudo-bruger.
# Dette forhindrer fysisk/GUI-terminal i at kunne ændre systemet frit, uden at låse maskinen helt.
if [[ "${LOCKDOWN_SUDO}" == "1" ]]; then
  SUDO_MEMBERS="$(getent group sudo | cut -d: -f4 || true)"
  OTHER_SUDO_USERS=""
  IFS=',' read -ra MEMBERS <<< "${SUDO_MEMBERS}"
  for u in "${MEMBERS[@]}"; do
    [[ -z "$u" ]] && continue
    [[ "$u" == "${CLIENTFLOW_USER}" ]] && continue
    if id "$u" >/dev/null 2>&1; then
      OTHER_SUDO_USERS+="$u "
    fi
  done

  if id -nG "${CLIENTFLOW_USER}" | tr ' ' '\n' | grep -qx sudo; then
    if [[ -n "${OTHER_SUDO_USERS// }" ]]; then
      deluser "${CLIENTFLOW_USER}" sudo >/dev/null 2>&1 || true
      echo "Kiosk-brugeren er fjernet fra sudo-gruppen. Anden sudo-bruger: ${OTHER_SUDO_USERS}"
    else
      echo "ADVARSEL: ${CLIENTFLOW_USER} er stadig i sudo-gruppen, fordi der ikke blev fundet en anden sudo-bruger."
      echo "Opret en separat admin-bruger og kør sikkerhedshardening igen for fuld lockdown."
    fi
  else
    echo "Kiosk-brugeren er ikke medlem af sudo-gruppen."
  fi
fi

# 5) Sørg for at ClientFlow kun har snævre passwordless sudo-regler via /etc/sudoers.d/clientflow.
# Selve filen oprettes i install_clientflow_clean_ubuntu.sh og valideres med visudo.
if [[ -f /etc/sudoers.d/clientflow ]]; then
  chmod 440 /etc/sudoers.d/clientflow
  visudo -cf /etc/sudoers.d/clientflow >/dev/null || {
    echo "FEJL: /etc/sudoers.d/clientflow er ugyldig. Deaktiverer den."
    mv /etc/sudoers.d/clientflow /etc/sudoers.d/clientflow.disabled.$(date +%Y%m%d-%H%M%S)
  }
fi

# 6) Lokal brugermappe: undgå world-writable fejl.
chmod go-w "${USER_HOME}" 2>/dev/null || true

echo "ClientFlow sikkerhedshardening færdig."
