#!/usr/bin/env bash
set -euo pipefail

# ClientFlow v6.7
# Robust konfiguration af Ubuntu/GDM til automatisk login i "Ubuntu on Xorg".
# Brug:
#   sudo bash configure_xorg_autologin.sh <username>

if [[ "${EUID}" -ne 0 ]]; then
  echo "FEJL: Kør med sudo/root."
  exit 1
fi

CLIENTFLOW_USER="${1:-${SUDO_USER:-}}"
if [[ -z "${CLIENTFLOW_USER}" || "${CLIENTFLOW_USER}" == "root" ]]; then
  echo "FEJL: Angiv brugeren, fx: sudo bash $0 clientflowbruger"
  exit 1
fi
if ! id "${CLIENTFLOW_USER}" >/dev/null 2>&1; then
  echo "FEJL: Brugeren findes ikke: ${CLIENTFLOW_USER}"
  exit 1
fi

USER_HOME="$(getent passwd "${CLIENTFLOW_USER}" | cut -d: -f6)"
USER_UID="$(id -u "${CLIENTFLOW_USER}")"
SESSION_ID="ubuntu-xorg"
SESSION_DESKTOP="ubuntu-xorg.desktop"

# Find bedste Xorg-session på maskinen.
if [[ ! -f "/usr/share/xsessions/${SESSION_DESKTOP}" ]]; then
  if [[ -f "/usr/share/xsessions/gnome-xorg.desktop" ]]; then
    SESSION_ID="gnome-xorg"
    SESSION_DESKTOP="gnome-xorg.desktop"
  elif ls /usr/share/xsessions/*xorg*.desktop >/dev/null 2>&1; then
    SESSION_DESKTOP="$(basename "$(ls /usr/share/xsessions/*xorg*.desktop | head -1)")"
    SESSION_ID="${SESSION_DESKTOP%.desktop}"
  else
    echo "ADVARSEL: Finder ingen Xorg-session i /usr/share/xsessions."
    echo "Fortsætter med ${SESSION_ID}; installér ubuntu-session/gnome-session hvis autologin ikke vælger Xorg."
  fi
fi

echo "== Konfigurerer GDM autologin + Ubuntu on Xorg =="
echo "Bruger:  ${CLIENTFLOW_USER}"
echo "Session: ${SESSION_ID} (${SESSION_DESKTOP})"

# Sørg for at systemet booter grafisk og at gdm3 er display manager.
systemctl set-default graphical.target >/dev/null 2>&1 || true
systemctl enable gdm3 >/dev/null 2>&1 || true
if [[ -x /usr/sbin/gdm3 ]]; then
  echo "/usr/sbin/gdm3" > /etc/X11/default-display-manager
fi

# Backup og skriv en enkel, kendt-god GDM-konfiguration.
mkdir -p /etc/gdm3
GDM_CONF=/etc/gdm3/custom.conf
if [[ -f "${GDM_CONF}" ]]; then
  cp -a "${GDM_CONF}" "${GDM_CONF}.clientflow.bak.$(date +%Y%m%d-%H%M%S)"
fi

cat > "${GDM_CONF}" <<EOF_GDM
[daemon]
WaylandEnable=false
AutomaticLoginEnable=True
AutomaticLogin=${CLIENTFLOW_USER}
TimedLoginEnable=True
TimedLogin=${CLIENTFLOW_USER}
TimedLoginDelay=1
DefaultSession=${SESSION_DESKTOP}

[security]

[xdmcp]

[chooser]

[debug]
EOF_GDM
chown root:root "${GDM_CONF}"
chmod 644 "${GDM_CONF}"

# AccountsService styrer brugerens foretrukne session på Ubuntu/GNOME.
mkdir -p /var/lib/AccountsService/users
AS_FILE="/var/lib/AccountsService/users/${CLIENTFLOW_USER}"
if [[ -f "${AS_FILE}" ]]; then
  cp -a "${AS_FILE}" "${AS_FILE}.clientflow.bak.$(date +%Y%m%d-%H%M%S)"
fi
cat > "${AS_FILE}" <<EOF_AS
[User]
Session=${SESSION_ID}
XSession=${SESSION_ID}
SystemAccount=false
EOF_AS
chown root:root "${AS_FILE}"
chmod 600 "${AS_FILE}"

# .dmrc er en ekstra fallback, som nogle display managers/session-flows respekterer.
if [[ -n "${USER_HOME}" && -d "${USER_HOME}" ]]; then
  cat > "${USER_HOME}/.dmrc" <<EOF_DMRC
[Desktop]
Session=${SESSION_ID}
EOF_DMRC
  chown "${CLIENTFLOW_USER}:${CLIENTFLOW_USER}" "${USER_HOME}/.dmrc"
  chmod 600 "${USER_HOME}/.dmrc"
fi

systemctl restart accounts-daemon >/dev/null 2>&1 || true

echo "OK: Automatisk login og Xorg-session er konfigureret."
echo "Kontrol efter reboot: loginctl skal vise Type=x11 for ${CLIENTFLOW_USER}."
