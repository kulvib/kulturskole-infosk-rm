#!/usr/bin/env bash
set -euo pipefail

# Konfigurerer Ubuntu/GDM til automatisk login på Xorg-session.
# Målet er login-typen "Ubuntu on Xorg".
# Brug:
#   sudo bash configure_xorg_autologin.sh <username>

if [[ "${EUID}" -ne 0 ]]; then
  echo "FEJL: Kør med sudo/root."
  exit 1
fi

CLIENTFLOW_USER="${1:-${SUDO_USER:-}}"
if [[ -z "${CLIENTFLOW_USER}" || "${CLIENTFLOW_USER}" == "root" ]]; then
  echo "FEJL: Angiv brugeren, fx: sudo bash $0 clientflowbruger"
  exit 1
fi
if ! id "${CLIENTFLOW_USER}" >/dev/null 2>&1; then
  echo "FEJL: Brugeren findes ikke: ${CLIENTFLOW_USER}"
  exit 1
fi

SESSION_ID="ubuntu-xorg"
if [[ ! -f "/usr/share/xsessions/${SESSION_ID}.desktop" ]]; then
  if [[ -f "/usr/share/xsessions/gnome-xorg.desktop" ]]; then
    SESSION_ID="gnome-xorg"
  elif ls /usr/share/xsessions/*xorg*.desktop >/dev/null 2>&1; then
    SESSION_ID="$(basename "$(ls /usr/share/xsessions/*xorg*.desktop | head -1)" .desktop)"
  else
    echo "ADVARSEL: Finder ingen Xorg xsessions-fil i /usr/share/xsessions."
    echo "Fortsætter med SESSION_ID=${SESSION_ID}; tjek login-skærmen hvis Xorg ikke vælges."
  fi
fi

echo "== Sætter GDM autologin + Xorg =="
echo "Bruger:  ${CLIENTFLOW_USER}"
echo "Session: ${SESSION_ID}"

mkdir -p /etc/gdm3
GDM_CONF=/etc/gdm3/custom.conf
if [[ -f "$GDM_CONF" ]]; then
  cp -a "$GDM_CONF" "$GDM_CONF.clientflow.bak.$(date +%Y%m%d-%H%M%S)"
fi

touch "$GDM_CONF"
python3 - "$GDM_CONF" "$CLIENTFLOW_USER" <<'PYCONF'
from pathlib import Path
import sys
path = Path(sys.argv[1])
user = sys.argv[2]
text = path.read_text(encoding='utf-8', errors='replace') if path.exists() else ''
lines = text.splitlines()

# Fjern eksisterende daemon-settings, som vi styrer.
out=[]
in_daemon=False
seen_daemon=False
for line in lines:
    stripped=line.strip()
    if stripped.startswith('[') and stripped.endswith(']'):
        if in_daemon:
            out.extend([
                'WaylandEnable=false',
                'AutomaticLoginEnable=True',
                f'AutomaticLogin={user}',
            ])
        in_daemon=(stripped.lower()=='[daemon]')
        seen_daemon = seen_daemon or in_daemon
        out.append(line)
        continue
    if in_daemon and stripped.split('=',1)[0] in {'WaylandEnable','AutomaticLoginEnable','AutomaticLogin'}:
        continue
    out.append(line)
if in_daemon:
    out.extend([
        'WaylandEnable=false',
        'AutomaticLoginEnable=True',
        f'AutomaticLogin={user}',
    ])
if not seen_daemon:
    if out and out[-1].strip():
        out.append('')
    out.extend([
        '[daemon]',
        'WaylandEnable=false',
        'AutomaticLoginEnable=True',
        f'AutomaticLogin={user}',
    ])
path.write_text('\n'.join(out).rstrip()+"\n", encoding='utf-8')
PYCONF

mkdir -p /var/lib/AccountsService/users
AS_FILE="/var/lib/AccountsService/users/${CLIENTFLOW_USER}"
if [[ -f "$AS_FILE" ]]; then
  cp -a "$AS_FILE" "$AS_FILE.clientflow.bak.$(date +%Y%m%d-%H%M%S)"
fi

touch "$AS_FILE"
python3 - "$AS_FILE" "$SESSION_ID" <<'PYAS'
from pathlib import Path
import sys
path = Path(sys.argv[1])
session = sys.argv[2]
text = path.read_text(encoding='utf-8', errors='replace') if path.exists() else ''
lines = text.splitlines()
out=[]
in_user=False
seen_user=False
xsession_written=False
for line in lines:
    stripped=line.strip()
    if stripped.startswith('[') and stripped.endswith(']'):
        if in_user and not xsession_written:
            out.append(f'XSession={session}')
            xsession_written=True
        in_user=(stripped.lower()=='[user]')
        seen_user = seen_user or in_user
        out.append(line)
        continue
    if in_user and stripped.startswith('XSession='):
        if not xsession_written:
            out.append(f'XSession={session}')
            xsession_written=True
        continue
    out.append(line)
if in_user and not xsession_written:
    out.append(f'XSession={session}')
    xsession_written=True
if not seen_user:
    if out and out[-1].strip():
        out.append('')
    out.extend(['[User]', f'XSession={session}'])
path.write_text('\n'.join(out).rstrip()+"\n", encoding='utf-8')
PYAS

chmod 644 "$GDM_CONF" "$AS_FILE" || true

echo "OK: Automatisk login og Xorg-session er sat."
echo "Bemærk: Ændringen er først fuldt aktiv efter reboot."
