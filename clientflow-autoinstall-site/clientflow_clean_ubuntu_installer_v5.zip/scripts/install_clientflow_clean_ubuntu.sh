#!/usr/bin/env bash
set -euo pipefail

# ClientFlow Clean Ubuntu Installer v6.5
# Tested target: Ubuntu 24.04 Desktop, GNOME on X11, existing kiosk user.
#
# V3 bruger kun enrollment/client-secret-flow:
#   1) Admin opretter installationskode i backend
#   2) Installeren claimer koden via /api/enrollment/claim
#   3) Backend returnerer client_id/client_secret, som gemmes i /etc/clientflow/clientflow.env
#
# Usage:
#   sudo CLIENTFLOW_ENROLLMENT_CODE='CF-XXXX-XXXX-XXXX' bash install_clientflow_clean_ubuntu.sh <client-user> [base-url]
# eller interaktivt:
#   sudo bash install_clientflow_clean_ubuntu.sh <client-user> [base-url]

if [[ "${EUID}" -ne 0 ]]; then
  echo "FEJL: Kør med sudo."
  exit 1
fi

CLIENTFLOW_USER="${1:-${SUDO_USER:-}}"
BASE_URL="${2:-https://kulturskole-infosk-rm.onrender.com}"
ENROLLMENT_CODE="${CLIENTFLOW_ENROLLMENT_CODE:-${3:-}}"
CLIENT_NAME="${CLIENTFLOW_CLIENT_NAME:-}"
LOCALITY="${CLIENTFLOW_LOCALITY:-}"
SKIP_ENROLLMENT="${CLIENTFLOW_SKIP_ENROLLMENT:-0}"
REINSTALL_MODE="${CLIENTFLOW_REINSTALL_MODE:-0}"
SKIP_OS_UPDATE="${CLIENTFLOW_SKIP_OS_UPDATE:-0}"
CONFIGURE_XORG_AUTOLOGIN="${CLIENTFLOW_CONFIGURE_XORG_AUTOLOGIN:-1}"

if [[ -z "${CLIENTFLOW_USER}" || "${CLIENTFLOW_USER}" == "root" ]]; then
  echo "FEJL: Angiv klientbrugeren:"
  echo "  sudo bash $0 <client-user> [base-url]"
  exit 1
fi

if ! id "${CLIENTFLOW_USER}" >/dev/null 2>&1; then
  echo "FEJL: Brugeren findes ikke: ${CLIENTFLOW_USER}"
  echo "Opret/log ind som brugeren først, og kør installeren igen."
  exit 1
fi

USER_HOME="$(getent passwd "${CLIENTFLOW_USER}" | cut -d: -f6)"
USER_UID="$(id -u "${CLIENTFLOW_USER}")"
API_DIR="${USER_HOME}/api"
PKG_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT_DIR="$(cd "${PKG_DIR}/.." && pwd)"
FILES_DIR="${ROOT_DIR}/files"

if [[ ! -d "${FILES_DIR}/api" ]]; then
  echo "FEJL: Pakken mangler files/api."
  exit 1
fi

echo "== ClientFlow Clean Ubuntu Installer v6.5 =="
echo "Bruger:        ${CLIENTFLOW_USER}"
echo "Home:          ${USER_HOME}"
echo "API_DIR:       ${API_DIR}"
echo "Backend URL:   ${BASE_URL}"
echo

if [[ "${SKIP_ENROLLMENT}" != "1" ]]; then
  if [[ -z "${ENROLLMENT_CODE}" ]]; then
    if [[ -t 0 ]]; then
      read -rp "Installationskode (CF-XXXX-XXXX-XXXX): " ENROLLMENT_CODE
    else
      echo "FEJL: CLIENTFLOW_ENROLLMENT_CODE mangler."
      echo "Opret en installationskode i ClientFlow admin og kør installeren med:"
      echo "  sudo CLIENTFLOW_ENROLLMENT_CODE='CF-XXXX-XXXX-XXXX' bash $0 ${CLIENTFLOW_USER} ${BASE_URL}"
      exit 1
    fi
  fi

  ENROLLMENT_CODE="$(echo "${ENROLLMENT_CODE}" | tr '[:lower:]' '[:upper:]' | xargs)"
  if [[ -z "${ENROLLMENT_CODE}" ]]; then
    echo "FEJL: Installationskode mangler."
    exit 1
  fi
else
  echo "== Reinstall/opdatering: springer enrollment over og bevarer /etc/clientflow/clientflow.env =="
  if [[ ! -s /etc/clientflow/clientflow.env ]] || ! grep -q '^CLIENTFLOW_CLIENT_ID=[0-9]' /etc/clientflow/clientflow.env || ! grep -q '^CLIENTFLOW_CLIENT_SECRET=cf_client_' /etc/clientflow/clientflow.env; then
    echo "FEJL: Kan ikke geninstallere uden eksisterende client credentials."
    echo "Brug installation med ny installationskode først."
    exit 1
  fi
fi

if [[ -z "${CLIENT_NAME}" ]]; then
  CLIENT_NAME="$(hostname 2>/dev/null || echo "${CLIENTFLOW_USER}")"
fi

export DEBIAN_FRONTEND=noninteractive

if [[ "${SKIP_OS_UPDATE}" == "1" ]]; then
  echo "== Springer Ubuntu-opdatering over =="
else
  echo "== Opdaterer Ubuntu og installerede programmer =="
  apt-get update
  apt-get -y full-upgrade
  apt-get -y autoremove
fi

echo "== Installerer Ubuntu-pakker =="
apt-get install -y \
  ca-certificates curl wget gnupg unzip tar \
  python3 python3-venv python3-pip python3-tk \
  x11-xserver-utils xdotool wmctrl xprintidle x11-utils x11-apps dbus-x11 \
  ffmpeg x11-utils xserver-xorg-video-dummy \
  net-tools iproute2 procps psmisc rfkill ufw \
  sudo

echo "== Installerer musecursor-skjulning =="
apt-get install -y unclutter-xfixes || apt-get install -y unclutter || true

echo
if ! command -v google-chrome >/dev/null 2>&1; then
  echo "== Installerer Google Chrome =="
  TMP_DEB="/tmp/google-chrome-stable_current_amd64.deb"
  wget -O "${TMP_DEB}" https://dl.google.com/linux/direct/google-chrome-stable_current_amd64.deb
  apt-get install -y "${TMP_DEB}"
else
  echo "== Google Chrome findes allerede =="
  google-chrome --version || true
fi

echo
if [[ -d "${API_DIR}" ]]; then
  BACKUP="${API_DIR}.backup.clean-installer.$(date +%Y%m%d-%H%M%S)"
  echo "== Eksisterende API_DIR findes. Backup: ${BACKUP} =="
  cp -a "${API_DIR}" "${BACKUP}"
  if [[ "${REINSTALL_MODE}" == "1" ]]; then
    echo "== Geninstallation: sletter gammel API_DIR før ny version kopieres =="
    rm -rf "${API_DIR}"
  fi
fi

mkdir -p "${API_DIR}"
cp -a "${FILES_DIR}/api/." "${API_DIR}/"
chown -R "${CLIENTFLOW_USER}:${CLIENTFLOW_USER}" "${API_DIR}"

echo
if [[ ! -d "${API_DIR}/venv" ]]; then
  echo "== Opretter Python venv =="
  sudo -u "${CLIENTFLOW_USER}" python3 -m venv "${API_DIR}/venv"
else
  echo "== Python venv findes allerede =="
fi

sudo -u "${CLIENTFLOW_USER}" "${API_DIR}/venv/bin/python" -m pip install --upgrade pip wheel
sudo -u "${CLIENTFLOW_USER}" "${API_DIR}/venv/bin/python" -m pip install -r "${API_DIR}/requirements.txt"

echo

echo "== Installerer Chrome extension fallback =="
rm -rf /opt/clientflow/chrome_extensions/clientflow-kiosk-protection
mkdir -p /opt/clientflow/chrome_extensions
cp -a "${FILES_DIR}/opt/clientflow/chrome_extensions/clientflow-kiosk-protection" /opt/clientflow/chrome_extensions/
chown -R root:root /opt/clientflow
chmod -R a+rX /opt/clientflow

echo

echo "== Installerer lokale helper scripts =="
install -m 0755 "${FILES_DIR}/usr/local/bin/clientflow-clean-chrome-restore-state.sh" /usr/local/bin/clientflow-clean-chrome-restore-state.sh
install -m 0755 "${FILES_DIR}/usr/local/bin/clientflow-kiosk-x11-guard.sh" /usr/local/bin/clientflow-kiosk-x11-guard.sh
install -m 0755 "${FILES_DIR}/usr/local/bin/clientflow-self-update.sh" /usr/local/bin/clientflow-self-update.sh
install -m 0755 "${FILES_DIR}/usr/local/bin/clientflow-hide-cursor.sh" /usr/local/bin/clientflow-hide-cursor.sh

echo
if [[ "${CONFIGURE_XORG_AUTOLOGIN}" != "0" ]]; then
  echo "== Konfigurerer automatisk login med Ubuntu on Xorg =="
  bash "${ROOT_DIR}/scripts/configure_xorg_autologin.sh" "${CLIENTFLOW_USER}" || true
else
  echo "== Springer Xorg/autologin-konfiguration over =="
fi

echo

echo "== Konfigurerer kiosk-hardening =="
bash "${ROOT_DIR}/scripts/configure_kiosk_hardening.sh" "${CLIENTFLOW_USER}" || true

echo

echo "== Opretter /etc/clientflow/clientflow.env midlertidigt uden secrets =="
mkdir -p /etc/clientflow
if [[ ! -f /etc/clientflow/clientflow.env ]]; then
  cat > /etc/clientflow/clientflow.env <<EOF
CLIENTFLOW_BASE_URL=${BASE_URL}
CLIENTFLOW_USERNAME=
CLIENTFLOW_PASSWORD=
CLIENTFLOW_CLIENT_ID=
CLIENTFLOW_CLIENT_SECRET=
EOF
  chmod 600 /etc/clientflow/clientflow.env
else
  echo "Beholder eksisterende /etc/clientflow/clientflow.env"
  if ! grep -q '^CLIENTFLOW_BASE_URL=' /etc/clientflow/clientflow.env; then
    echo "CLIENTFLOW_BASE_URL=${BASE_URL}" >> /etc/clientflow/clientflow.env
  fi
  if ! grep -q '^CLIENTFLOW_CLIENT_ID=' /etc/clientflow/clientflow.env; then
    echo "CLIENTFLOW_CLIENT_ID=" >> /etc/clientflow/clientflow.env
  fi
  if ! grep -q '^CLIENTFLOW_CLIENT_SECRET=' /etc/clientflow/clientflow.env; then
    echo "CLIENTFLOW_CLIENT_SECRET=" >> /etc/clientflow/clientflow.env
  fi
fi
chown root:root /etc/clientflow/clientflow.env
chmod 600 /etc/clientflow/clientflow.env

echo

echo "== Konfigurerer automatisk skjulning af musecursor =="

echo "== Installerer systemd services =="
# Clean previous known units/dropins before copying.
for s in \
  clientflow_service.service \
  clientflow_calendar.service \
  client_terminal_agent.service \
  client_admin_terminal_agent.service \
  client_remote_desktop_agent.service \
  clientflow_kiosk_x11_guard.service \
  clientflow_browser_guard.service \
  clientflow_hide_cursor.service
  do
    systemctl stop "$s" 2>/dev/null || true
  done

cp -a "${FILES_DIR}/etc/systemd/system/." /etc/systemd/system/

# Replace source client's username/home/uid with target user's values in units and drop-ins.
find /etc/systemd/system \
  \( -name 'clientflow*.service' -o -name 'client_*agent.service' -o -path '*/clientflow*.service.d/*.conf' -o -path '*/client_*agent.service.d/*.conf' \) \
  -type f -print0 | while IFS= read -r -d '' f; do
    sed -i \
      -e "s|kulturskolenviborg-info1|${CLIENTFLOW_USER}|g" \
      -e "s|/home/${CLIENTFLOW_USER}|${USER_HOME}|g" \
      -e "s|/run/user/1000|/run/user/${USER_UID}|g" \
      -e "s|CLIENTFLOW_BASE_URL=https://kulturskole-infosk-rm.onrender.com|CLIENTFLOW_BASE_URL=${BASE_URL}|g" \
      "$f"
  done

# Ensure env drop-ins exist for auth-aware services.
for svc in clientflow_service clientflow_calendar client_terminal_agent client_admin_terminal_agent client_remote_desktop_agent; do
  mkdir -p "/etc/systemd/system/${svc}.service.d"
  cat > "/etc/systemd/system/${svc}.service.d/10-clientflow-env.conf" <<EOF
[Service]
EnvironmentFile=/etc/clientflow/clientflow.env
Environment=DISPLAY=:0
Environment=XAUTHORITY=/run/user/${USER_UID}/gdm/Xauthority
EOF
  cat > "/etc/systemd/system/${svc}.service.d/20-clear-admin-credentials.conf" <<EOF
[Service]
Environment="CLIENTFLOW_USERNAME="
Environment="CLIENTFLOW_PASSWORD="
EOF
  cat > "/etc/systemd/system/${svc}.service.d/30-chrome-extension.conf" <<EOF
[Service]
Environment=CLIENTFLOW_CHROME_EXTENSION_DIR=/opt/clientflow/chrome_extensions/clientflow-kiosk-protection
Environment=CLIENTFLOW_CHROME_EXTENSION_PATH=/opt/clientflow/chrome_extensions/clientflow-kiosk-protection
EOF
done

mkdir -p /etc/systemd/system/clientflow_service.service.d
cat > /etc/systemd/system/clientflow_service.service.d/30-clean-chrome-restore-state.conf <<EOF
[Service]
ExecStartPre=/usr/local/bin/clientflow-clean-chrome-restore-state.sh ${API_DIR}/chrome_profile/Default
EOF

# Browser guard service generated cleanly from verified unit.
cat > /etc/systemd/system/clientflow_browser_guard.service <<EOF
[Unit]
Description=ClientFlow Browser Guard via Chrome Remote Debugging
After=network-online.target clientflow_service.service
Wants=network-online.target clientflow_service.service

[Service]
Type=simple
User=${CLIENTFLOW_USER}
WorkingDirectory=${API_DIR}
Environment=PYTHONUNBUFFERED=1
Environment=CLIENTFLOW_CHROME_DEBUG_HOST=127.0.0.1
Environment=CLIENTFLOW_CHROME_DEBUG_PORT=9222
Environment=CLIENTFLOW_BROWSER_GUARD_INTERVAL=2
Environment=CLIENTFLOW_BROWSER_GUARD_REFRESH_SEC=900
Environment=CLIENTFLOW_BROWSER_GUARD_WS_TIMEOUT=4
ExecStart=${API_DIR}/venv/bin/python ${API_DIR}/clientflow_browser_guard.py
Restart=always
RestartSec=5
StandardOutput=journal
StandardError=journal
SyslogIdentifier=clientflow_browser_guard

[Install]
WantedBy=multi-user.target
EOF

# Kiosk X11 guard service generated with correct UID/home.
cat > /etc/systemd/system/clientflow_kiosk_x11_guard.service <<EOF
[Unit]
Description=ClientFlow Kiosk X11 no-lock/no-blank guard
After=graphical.target display-manager.service
Wants=graphical.target

[Service]
Type=simple
User=${CLIENTFLOW_USER}
Environment=DISPLAY=:0
Environment=XAUTHORITY=/run/user/${USER_UID}/gdm/Xauthority
Environment=XDG_RUNTIME_DIR=/run/user/${USER_UID}
Environment=DBUS_SESSION_BUS_ADDRESS=unix:path=/run/user/${USER_UID}/bus
Environment=HOME=${USER_HOME}
ExecStart=/usr/local/bin/clientflow-kiosk-x11-guard.sh
Restart=always
RestartSec=10

[Install]
WantedBy=graphical.target
EOF

# Hide mouse cursor after 10 seconds of inactivity in kiosk/Xorg session.
cat > /etc/systemd/system/clientflow_hide_cursor.service <<EOF
[Unit]
Description=ClientFlow Hide Mouse Cursor after inactivity
After=graphical.target display-manager.service
Wants=graphical.target

[Service]
Type=simple
User=${CLIENTFLOW_USER}
Environment=DISPLAY=:0
Environment=XAUTHORITY=/run/user/${USER_UID}/gdm/Xauthority
Environment=XDG_RUNTIME_DIR=/run/user/${USER_UID}
Environment=DBUS_SESSION_BUS_ADDRESS=unix:path=/run/user/${USER_UID}/bus
Environment=HOME=${USER_HOME}
ExecStart=/usr/local/bin/clientflow-hide-cursor.sh
Restart=always
RestartSec=10

[Install]
WantedBy=graphical.target
EOF

# Root one-shot service used by backend-triggered ClientFlow self-update.
cat > /etc/systemd/system/clientflow_self_update.service <<EOF
[Unit]
Description=ClientFlow Self Update from Render
After=network-online.target
Wants=network-online.target

[Service]
Type=oneshot
User=root
Environment=CLIENTFLOW_SELF_UPDATE_URL=https://autoinstall.onrender.com/clientflow_version.json
ExecStart=/usr/local/bin/clientflow-self-update.sh ${CLIENTFLOW_USER}
StandardOutput=journal
StandardError=journal
SyslogIdentifier=clientflow_self_update
TimeoutStartSec=3600

[Install]
WantedBy=multi-user.target
EOF

echo

echo "== Installerer sudoers til kontrolleret reboot/poweroff =="
cat > /etc/sudoers.d/clientflow <<EOF
${CLIENTFLOW_USER} ALL=(root) NOPASSWD: /sbin/reboot, /usr/sbin/reboot, /bin/systemctl reboot, /usr/bin/systemctl reboot, /bin/systemctl poweroff, /usr/bin/systemctl poweroff, /sbin/shutdown, /usr/sbin/shutdown
${CLIENTFLOW_USER} ALL=(root) NOPASSWD: /bin/systemctl start --no-block clientflow_self_update.service, /usr/bin/systemctl start --no-block clientflow_self_update.service, /bin/systemctl start clientflow_self_update.service, /usr/bin/systemctl start clientflow_self_update.service
EOF
chmod 440 /etc/sudoers.d/clientflow
visudo -cf /etc/sudoers.d/clientflow >/dev/null

echo

echo "== Konfigurerer klient-sikkerhed =="
bash "${ROOT_DIR}/scripts/configure_client_security.sh" "${CLIENTFLOW_USER}" || true

echo "== Sætter no-lock/no-blank indstillinger for bruger-session, hvis DBus er klar =="
sudo -u "${CLIENTFLOW_USER}" \
  HOME="${USER_HOME}" \
  XDG_RUNTIME_DIR="/run/user/${USER_UID}" \
  DBUS_SESSION_BUS_ADDRESS="unix:path=/run/user/${USER_UID}/bus" \
  bash -lc '
    gsettings set org.gnome.desktop.session idle-delay 0 2>/dev/null || true
    gsettings set org.gnome.desktop.screensaver lock-enabled false 2>/dev/null || true
    gsettings set org.gnome.settings-daemon.plugins.power sleep-inactive-ac-type nothing 2>/dev/null || true
    gsettings set org.gnome.settings-daemon.plugins.power sleep-inactive-ac-timeout 0 2>/dev/null || true
    gsettings set org.gnome.settings-daemon.plugins.power idle-dim false 2>/dev/null || true
    DISPLAY=:0 xset s off -dpms s noblank 2>/dev/null || true
  '

echo

echo "== Syntax check af Python-filer =="
sudo -u "${CLIENTFLOW_USER}" bash -lc "cd '${API_DIR}' && '${API_DIR}/venv/bin/python' -m py_compile *.py"

echo

if [[ "${SKIP_ENROLLMENT}" == "1" ]]; then
  echo "== Bevarer eksisterende client credentials =="
else
  echo "== Claimer installationskode og installerer client credentials =="
  CLIENTFLOW_BASE_URL="${BASE_URL}" CLIENTFLOW_ENROLLMENT_CODE="${ENROLLMENT_CODE}" CLIENTFLOW_CLIENT_NAME="${CLIENT_NAME}" CLIENTFLOW_LOCALITY="${LOCALITY}" CLIENTFLOW_USER="${CLIENTFLOW_USER}" bash "${ROOT_DIR}/scripts/claim_enrollment_env.sh"
fi

echo

echo "== Enable + start services =="
systemctl daemon-reload
systemctl enable \
  clientflow_service.service \
  clientflow_calendar.service \
  client_terminal_agent.service \
  client_admin_terminal_agent.service \
  client_remote_desktop_agent.service \
  clientflow_browser_guard.service \
  clientflow_kiosk_x11_guard.service \
  clientflow_hide_cursor.service

systemctl restart clientflow_kiosk_x11_guard.service || true
systemctl restart clientflow_hide_cursor.service || true
systemctl restart clientflow_service.service || true
systemctl restart clientflow_calendar.service || true
systemctl restart client_terminal_agent.service || true
systemctl restart client_admin_terminal_agent.service || true
systemctl restart client_remote_desktop_agent.service || true
systemctl restart clientflow_browser_guard.service || true

echo

echo "== Installation færdig =="
echo
echo "Client credentials er installeret via enrollment-flow."
echo "Hvis backend returnerede status=pending, skal klienten godkendes i ClientFlow admin."
echo
echo "Verificér med:"
echo "  bash ${ROOT_DIR}/scripts/verify_clientflow_install.sh ${CLIENTFLOW_USER}"
