#!/usr/bin/env bash
set -euo pipefail

USER_NAME="${1:-${USER}}"
USER_HOME="$(getent passwd "$USER_NAME" | cut -d: -f6)"
API_DIR="${USER_HOME}/api"
HOST="$(hostname)"
TS="$(date +%Y%m%d-%H%M%S)"
OUT="${USER_HOME}/clientflow_post_install_snapshot_${HOST}_${TS}"
mkdir -p "$OUT"
cp -a "$API_DIR" "$OUT/api" 2>/dev/null || true
cp -a /etc/systemd/system/clientflow*.service /etc/systemd/system/client_*agent.service "$OUT/" 2>/dev/null || true
journalctl -u clientflow_service.service --since "15 minutes ago" --no-pager -l > "$OUT/clientflow_service.log" 2>&1 || true
journalctl -u clientflow_browser_guard.service --since "15 minutes ago" --no-pager -l > "$OUT/browser_guard.log" 2>&1 || true
if [[ -f /etc/clientflow/clientflow.env ]]; then
  sed -E -e 's/CLIENTFLOW_PASSWORD=.*/CLIENTFLOW_PASSWORD=***/' -e 's/CLIENTFLOW_CLIENT_SECRET=.*/CLIENTFLOW_CLIENT_SECRET=***/' /etc/clientflow/clientflow.env > "$OUT/clientflow.env.redacted"
fi
# Redact only logs/env, not Python source.
grep -RIl . "$OUT" | grep -E '(\.log$|\.env|redacted|\.txt$)' | while read -r f; do
  sed -i -E -e 's/CLIENTFLOW_CLIENT_SECRET=[^[:space:]]+/CLIENTFLOW_CLIENT_SECRET=***/g' -e 's/CLIENTFLOW_PASSWORD=[^[:space:]]+/CLIENTFLOW_PASSWORD=***/g' "$f" || true
done
tar -czf "${OUT}.tar.gz" -C "$(dirname "$OUT")" "$(basename "$OUT")"
echo "${OUT}.tar.gz"
