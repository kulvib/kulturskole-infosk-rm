#!/usr/bin/env bash
set -euo pipefail

# Claimer en ny ClientFlow-klient via backend enrollment-flow og skriver
# /etc/clientflow/clientflow.env med client_id/client_secret.
#
# Brug:
#   sudo bash claim_enrollment_env.sh
# eller non-interaktivt:
#   sudo CLIENTFLOW_ENROLLMENT_CODE='CF-XXXX-XXXX-XXXX' \
#        CLIENTFLOW_CLIENT_NAME='navn' \
#        CLIENTFLOW_BASE_URL='https://...' \
#        bash claim_enrollment_env.sh

if [[ "${EUID}" -ne 0 ]]; then
  echo "FEJL: Kør med sudo."
  exit 1
fi

BASE_URL="${CLIENTFLOW_BASE_URL:-https://kulturskole-infosk-rm.onrender.com}"
CODE="${CLIENTFLOW_ENROLLMENT_CODE:-}"
CLIENT_NAME="${CLIENTFLOW_CLIENT_NAME:-}"
LOCALITY="${CLIENTFLOW_LOCALITY:-}"
CLIENTFLOW_USER="${CLIENTFLOW_USER:-${SUDO_USER:-}}"

if [[ -z "${CODE}" ]]; then
  read -rp "Installationskode (CF-XXXX-XXXX-XXXX): " CODE
fi

CODE="$(echo "${CODE}" | tr '[:lower:]' '[:upper:]' | xargs)"
if [[ -z "${CODE}" ]]; then
  echo "FEJL: Installationskode mangler."
  exit 1
fi

HOSTNAME_VALUE="$(hostname 2>/dev/null || true)"
if [[ -z "${CLIENT_NAME}" ]]; then
  CLIENT_NAME="${HOSTNAME_VALUE:-Ny infoskærm}"
fi

MACHINE_ID=""
if [[ -r /etc/machine-id ]]; then
  MACHINE_ID="$(cat /etc/machine-id | tr -d '\n' || true)"
fi

UBUNTU_VERSION=""
if [[ -r /etc/os-release ]]; then
  UBUNTU_VERSION="$(. /etc/os-release && echo "${PRETTY_NAME:-}" || true)"
fi

UPTIME_VALUE=""
if [[ -r /proc/uptime ]]; then
  UPTIME_VALUE="$(awk '{print int($1)}' /proc/uptime || true)"
fi

# Find første IPv4/MAC for Wi-Fi og LAN uden at fejle, hvis kommandoer mangler.
WIFI_IFACE="$(ip -o link show 2>/dev/null | awk -F': ' '/wl|wifi|wlan/ {print $2; exit}' || true)"
LAN_IFACE="$(ip -o link show 2>/dev/null | awk -F': ' '/en|eth/ {print $2; exit}' || true)"

get_ip() {
  local iface="$1"
  [[ -z "$iface" ]] && return 0
  ip -o -4 addr show dev "$iface" 2>/dev/null | awk '{print $4}' | cut -d/ -f1 | head -1 || true
}

get_mac() {
  local iface="$1"
  [[ -z "$iface" ]] && return 0
  cat "/sys/class/net/$iface/address" 2>/dev/null || true
}

WIFI_IP="$(get_ip "$WIFI_IFACE")"
WIFI_MAC="$(get_mac "$WIFI_IFACE")"
LAN_IP="$(get_ip "$LAN_IFACE")"
LAN_MAC="$(get_mac "$LAN_IFACE")"

TMP_RESPONSE="$(mktemp)"
TMP_STATUS="$(mktemp)"
trap 'rm -f "$TMP_RESPONSE" "$TMP_STATUS"' EXIT

python3 - "$BASE_URL" "$CODE" "$CLIENT_NAME" "$LOCALITY" "$HOSTNAME_VALUE" "$MACHINE_ID" "$UBUNTU_VERSION" "$UPTIME_VALUE" "$WIFI_IP" "$WIFI_MAC" "$LAN_IP" "$LAN_MAC" "$TMP_RESPONSE" "$TMP_STATUS" <<'PY'
import json
import sys
import urllib.error
import urllib.request

(
    base_url, code, name, locality, hostname, machine_id, ubuntu_version, uptime,
    wifi_ip, wifi_mac, lan_ip, lan_mac, response_path, status_path
) = sys.argv[1:]

payload = {
    "enrollment_code": code,
    "name": name or None,
    "locality": locality or None,
    "hostname": hostname or None,
    "machine_id": machine_id or None,
    "ubuntu_version": ubuntu_version or None,
    "uptime": uptime or None,
    "wifi_ip_address": wifi_ip or None,
    "wifi_mac_address": wifi_mac or None,
    "lan_ip_address": lan_ip or None,
    "lan_mac_address": lan_mac or None,
}

data = json.dumps(payload).encode("utf-8")
url = base_url.rstrip("/") + "/api/enrollment/claim"
req = urllib.request.Request(
    url,
    data=data,
    headers={"Content-Type": "application/json", "Accept": "application/json"},
    method="POST",
)

try:
    with urllib.request.urlopen(req, timeout=30) as resp:
        body = resp.read().decode("utf-8", errors="replace")
        status = resp.status
except urllib.error.HTTPError as exc:
    body = exc.read().decode("utf-8", errors="replace")
    status = exc.code
except Exception as exc:
    body = json.dumps({"detail": f"Kunne ikke kontakte backend: {type(exc).__name__}: {exc}"})
    status = 0

open(response_path, "w", encoding="utf-8").write(body)
open(status_path, "w", encoding="utf-8").write(str(status))
PY

STATUS="$(cat "$TMP_STATUS")"
RESPONSE="$(cat "$TMP_RESPONSE")"

if [[ "$STATUS" != "200" ]]; then
  echo "FEJL: Enrollment claim fejlede mod ${BASE_URL}/api/enrollment/claim"
  echo "HTTP status: $STATUS"
  echo "Svar: $RESPONSE"
  exit 1
fi

CLIENT_ID="$(python3 -c 'import json,sys; print(json.load(open(sys.argv[1])).get("client_id", ""))' "$TMP_RESPONSE")"
CLIENT_SECRET="$(python3 -c 'import json,sys; print(json.load(open(sys.argv[1])).get("client_secret", ""))' "$TMP_RESPONSE")"
CLAIMED_NAME="$(python3 -c 'import json,sys; print(json.load(open(sys.argv[1])).get("name", ""))' "$TMP_RESPONSE")"
CLAIMED_STATUS="$(python3 -c 'import json,sys; print(json.load(open(sys.argv[1])).get("status", ""))' "$TMP_RESPONSE")"

if [[ -z "$CLIENT_ID" || -z "$CLIENT_SECRET" ]]; then
  echo "FEJL: Backend svarede uden client_id/client_secret."
  echo "Svar: $RESPONSE"
  exit 1
fi

mkdir -p /etc/clientflow
umask 077
cat > /etc/clientflow/clientflow.env <<EOFENV
CLIENTFLOW_BASE_URL=${BASE_URL}
CLIENTFLOW_USERNAME=
CLIENTFLOW_PASSWORD=
CLIENTFLOW_CLIENT_ID=${CLIENT_ID}
CLIENTFLOW_CLIENT_SECRET=${CLIENT_SECRET}
EOFENV
chown root:root /etc/clientflow/clientflow.env
chmod 600 /etc/clientflow/clientflow.env

systemctl daemon-reload || true
# Skriv også lokal config, så GUI straks kan vise Pending/Approved uden at vente på første backend-poll.
if [[ -n "${CLIENTFLOW_USER}" && "${CLIENTFLOW_USER}" != "root" ]] && id "${CLIENTFLOW_USER}" >/dev/null 2>&1; then
  USER_HOME="$(getent passwd "${CLIENTFLOW_USER}" | cut -d: -f6)"
  API_DIR="${USER_HOME}/api"
  if [[ -d "${API_DIR}" ]]; then
    python3 - "$API_DIR/clientflow_config.json" "$CLIENT_ID" "$CLAIMED_NAME" "$CLAIMED_STATUS" "$BASE_URL" <<'PYCFG'
import json, sys, pathlib, time
path = pathlib.Path(sys.argv[1])
client_id, name, status, base_url = sys.argv[2:]
try:
    data = json.loads(path.read_text(encoding='utf-8')) if path.exists() else {}
except Exception:
    data = {}
data.update({
    "id": int(client_id),
    "client_id": int(client_id),
    "name": name,
    "status": status or "pending",
    "base_url": base_url,
})
path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding='utf-8')
PYCFG
    chown "${CLIENTFLOW_USER}:${CLIENTFLOW_USER}" "${API_DIR}/clientflow_config.json" 2>/dev/null || true
  fi
fi

echo "Enrollment claim OK."
echo "Client ID: ${CLIENT_ID}"
echo "Navn: ${CLAIMED_NAME}"
echo "Status: ${CLAIMED_STATUS}"
echo
if [[ "${CLAIMED_STATUS}" == "pending" ]]; then
  echo "NÆSTE TRIN: Godkend klienten i ClientFlow admin."
fi
