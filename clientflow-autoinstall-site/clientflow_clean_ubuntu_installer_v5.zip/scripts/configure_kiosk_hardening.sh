#!/usr/bin/env bash
set -euo pipefail

# ClientFlow kiosk hardening
# Formål: Undgå system-popups/dialoger på kiosk-klienter.
# Kører uden brugerinteraktion og må gerne være idempotent.

CLIENTFLOW_USER="${1:-${SUDO_USER:-}}"
if [[ -z "${CLIENTFLOW_USER}" || "${CLIENTFLOW_USER}" == "root" ]]; then
  echo "FEJL: Angiv klientbrugeren: sudo bash configure_kiosk_hardening.sh <client-user>"
  exit 1
fi

if ! id "${CLIENTFLOW_USER}" >/dev/null 2>&1; then
  echo "FEJL: Brugeren findes ikke: ${CLIENTFLOW_USER}"
  exit 1
fi

USER_HOME="$(getent passwd "${CLIENTFLOW_USER}" | cut -d: -f6)"
USER_UID="$(id -u "${CLIENTFLOW_USER}")"

echo "Konfigurerer kiosk-hardening for ${CLIENTFLOW_USER}..."

# 1) Slå Apport/crash-dialoger fra.
if [[ -f /etc/default/apport ]]; then
  sed -i 's/^enabled=.*/enabled=0/' /etc/default/apport || true
fi
systemctl disable --now apport.service 2>/dev/null || true
systemctl disable --now whoopsie.service 2>/dev/null || true

# 2) Undgå GUI-baserede opdateringspopups. ClientFlow/installer styrer opdateringer kontrolleret.
cat > /etc/apt/apt.conf.d/20auto-upgrades <<'APTCONF'
APT::Periodic::Update-Package-Lists "0";
APT::Periodic::Unattended-Upgrade "0";
APT::Periodic::AutocleanInterval "0";
APTCONF

systemctl disable --now apt-daily.timer apt-daily-upgrade.timer 2>/dev/null || true
systemctl disable --now apt-daily.service apt-daily-upgrade.service 2>/dev/null || true
systemctl disable --now packagekit.service 2>/dev/null || true

# 3) Skjul autostart-dialoger/notifiers i brugerens session.
AUTOSTART_DIR="${USER_HOME}/.config/autostart"
mkdir -p "${AUTOSTART_DIR}"
for app in update-notifier.desktop org.gnome.Software.desktop software-properties-gtk.desktop nm-applet.desktop bluetooth-applet.desktop; do
  cat > "${AUTOSTART_DIR}/${app}" <<EOF2
[Desktop Entry]
Type=Application
Name=${app}
Hidden=true
NoDisplay=true
X-GNOME-Autostart-enabled=false
EOF2
done
chown -R "${CLIENTFLOW_USER}:${CLIENTFLOW_USER}" "${USER_HOME}/.config"

# 4) GNOME-session: ingen notifikationsbannere, skærmlås, dim/sleep.
sudo -u "${CLIENTFLOW_USER}" \
  HOME="${USER_HOME}" \
  XDG_RUNTIME_DIR="/run/user/${USER_UID}" \
  DBUS_SESSION_BUS_ADDRESS="unix:path=/run/user/${USER_UID}/bus" \
  bash -lc '
    gsettings set org.gnome.desktop.notifications show-banners false 2>/dev/null || true
    gsettings set org.gnome.desktop.notifications show-in-lock-screen false 2>/dev/null || true
    gsettings set org.gnome.desktop.session idle-delay 0 2>/dev/null || true
    gsettings set org.gnome.desktop.screensaver lock-enabled false 2>/dev/null || true
    gsettings set org.gnome.desktop.screensaver ubuntu-lock-on-suspend false 2>/dev/null || true
    gsettings set org.gnome.settings-daemon.plugins.power sleep-inactive-ac-type nothing 2>/dev/null || true
    gsettings set org.gnome.settings-daemon.plugins.power sleep-inactive-ac-timeout 0 2>/dev/null || true
    gsettings set org.gnome.settings-daemon.plugins.power idle-dim false 2>/dev/null || true
    gsettings set org.gnome.mutter check-alive-timeout 0 2>/dev/null || true
    DISPLAY=:0 xset s off -dpms s noblank 2>/dev/null || true
  '

# 5) Chrome policy: reducer prompts/dialoger i drift.
mkdir -p /etc/opt/chrome/policies/managed
cat > /etc/opt/chrome/policies/managed/clientflow-kiosk.json <<'CHROMEPOLICY'
{
  "DefaultBrowserSettingEnabled": false,
  "PasswordManagerEnabled": false,
  "AutofillAddressEnabled": false,
  "AutofillCreditCardEnabled": false,
  "RestoreOnStartup": 4,
  "PromotionalTabsEnabled": false,
  "BrowserSignin": 0,
  "SyncDisabled": true,
  "MetricsReportingEnabled": false,
  "CloudPrintSubmitEnabled": false,
  "TranslateEnabled": false,
  "SafeBrowsingExtendedReportingEnabled": false
}
CHROMEPOLICY
chmod 644 /etc/opt/chrome/policies/managed/clientflow-kiosk.json

# 6) Keyring: undgå at Chrome/GNOME beder om login-keyring i kiosk-sessioner.
# Vi sletter ikke eksisterende keyrings her; vi sikrer kun at Chrome bruger basic password store via commandline i app-koden.

# 7) Sikr at systemet ikke går i sleep på AC-niveau.
systemctl mask sleep.target suspend.target hibernate.target hybrid-sleep.target 2>/dev/null || true

echo "Kiosk-hardening færdig."
