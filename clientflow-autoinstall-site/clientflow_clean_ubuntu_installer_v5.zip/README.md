# ClientFlow Clean Ubuntu Installer v5.4

Denne pakke installerer ClientFlow på Ubuntu-klienter med enrollment/client-secret-flow.

## Flow

1. Opret en installationskode i ClientFlow admin.
2. Kør installeren på Ubuntu-klienten.
3. Indtast installationskoden.
4. Installeren opdaterer systemet, installerer ClientFlow og kalder backend `/api/enrollment/claim`.
5. Backend opretter klienten og returnerer `client_id` + `client_secret`.
6. Installeren skriver credentials til `/etc/clientflow/clientflow.env`.
7. Genstart klienten.
8. Godkend klienten i admin, hvis den står som `pending`.

Den gamle manuelle client-secret-installation er fjernet.
