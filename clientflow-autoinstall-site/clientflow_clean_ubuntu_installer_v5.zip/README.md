ClientFlow clean Ubuntu installer v6.5
