#!/usr/bin/env bash
set -euo pipefail

INSTALLER="$HOME/.local/bin/clientflow_desktop_installer.sh"

if [[ ! -x "$INSTALLER" ]]; then
  echo "ClientFlow installer script mangler: $INSTALLER"
  read -rp "Tryk Enter for at lukke..."
  exit 1
fi

CMD='bash -lc "$HOME/.local/bin/clientflow_desktop_installer.sh; echo; read -rp '\''Tryk Enter for at lukke...'\''"'

if command -v gnome-terminal >/dev/null 2>&1; then
  gnome-terminal -- bash -lc "$HOME/.local/bin/clientflow_desktop_installer.sh; echo; read -rp 'Tryk Enter for at lukke...'"
elif command -v kgx >/dev/null 2>&1; then
  kgx -- bash -lc "$HOME/.local/bin/clientflow_desktop_installer.sh; echo; read -rp 'Tryk Enter for at lukke...'"
elif command -v x-terminal-emulator >/dev/null 2>&1; then
  x-terminal-emulator -e bash -lc "$HOME/.local/bin/clientflow_desktop_installer.sh; echo; read -rp 'Tryk Enter for at lukke...'"
elif command -v xterm >/dev/null 2>&1; then
  xterm -e bash -lc "$HOME/.local/bin/clientflow_desktop_installer.sh; echo; read -rp 'Tryk Enter for at lukke...'"
else
  echo "FEJL: Finder ingen terminal-emulator."
  echo "Kør manuelt:"
  echo "  $INSTALLER"
  read -rp "Tryk Enter for at lukke..."
fi
