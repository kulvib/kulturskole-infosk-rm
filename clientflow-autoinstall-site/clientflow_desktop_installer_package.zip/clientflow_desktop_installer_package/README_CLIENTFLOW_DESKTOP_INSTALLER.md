# ClientFlow Desktop Installer Package

Denne pakke er til flowet:

1. Installer Ubuntu manuelt.
2. Log ind.
3. Opret et ClientFlow Installer-ikon på skrivebordet.
4. Dobbeltklik på ikonet og vælg installation/aktivering/verificering.

## Installation af skrivebordsikon

Pak zip-filen ud og kør:

```bash
cd ~/Hentet/clientflow_desktop_installer_package
bash setup_clientflow_desktop_icon.sh
```

Derefter ligger der et ikon på skrivebordet:

```text
ClientFlow Installer
```

Hvis Ubuntu markerer ikonet som usikkert, højreklik og vælg:

```text
Tillad start / Allow Launching
```

## Hvad ikonet gør

Det åbner en menu:

```text
1) Installer ClientFlow på frisk Ubuntu
2) Installer client-secret efter godkendelse
3) Verificér installation
4) Vis logs/status
```

## Download-kilde

Installeren henter den aktuelle zip fra:

```text
https://autoinstall.onrender.com/clientflow_clean_ubuntu_installer_v2.zip
```

Backend URL er:

```text
https://kulturskole-infosk-rm.onrender.com
```
