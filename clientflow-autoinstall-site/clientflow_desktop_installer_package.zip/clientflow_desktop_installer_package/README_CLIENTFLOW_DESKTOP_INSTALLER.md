# ClientFlow Desktop Installer v3

Denne pakke opretter et skrivebordsikon til ClientFlow-installation.

V3 bruger kun det nye enrollment/client-secret-flow:

1. Opret en installationskode i ClientFlow admin.
2. Start `ClientFlow Installer` på Ubuntu-klienten.
3. Vælg `Installer ClientFlow med installationskode`.
4. Indtast installationskoden.
5. Installeren claimer koden via backend `/api/enrollment/claim`.
6. Backend returnerer `client_id` og `client_secret`, som gemmes lokalt i `/etc/clientflow/clientflow.env`.
7. Godkend klienten i admin, hvis den står som `pending`.

Den gamle manuelle menu til efterfølgende client-secret-installation er fjernet.
