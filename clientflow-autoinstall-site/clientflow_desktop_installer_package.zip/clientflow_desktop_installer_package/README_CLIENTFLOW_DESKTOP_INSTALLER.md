# ClientFlow Desktop Installer v5.4

Menuen bruger kun enrollment/client-secret-flow. Den gamle manuelle client-secret-installation er fjernet.

Ubuntu on Xorg og automatisk login konfigureres automatisk under installation/geninstallation og vises ikke som separat menupunkt. Reboot kræves efter installation.

Menu:

```text
1) Installer ClientFlow med installationskode
2) Indtast ny installationskode / re-registrer klient
3) Geninstaller/opdater ClientFlow
4) Verificér installation
5) Vis logs/status
0) Afslut
```
