#!/usr/bin/env bash
set -euo pipefail

# Installerer ClientFlow skrivebordsikon på en frisk Ubuntu.
#
# Brug:
#   bash setup_clientflow_desktop_icon.sh

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

mkdir -p "$HOME/.local/bin"

install -m 0755 "$SCRIPT_DIR/clientflow_desktop_installer.sh" "$HOME/.local/bin/clientflow_desktop_installer.sh"
install -m 0755 "$SCRIPT_DIR/clientflow_desktop_launcher.sh" "$HOME/.local/bin/clientflow_desktop_launcher.sh"

DESKTOP_DIR="$(xdg-user-dir DESKTOP 2>/dev/null || true)"
if [[ -z "$DESKTOP_DIR" || ! -d "$DESKTOP_DIR" ]]; then
  if [[ -d "$HOME/Skrivebord" ]]; then
    DESKTOP_DIR="$HOME/Skrivebord"
  else
    DESKTOP_DIR="$HOME/Desktop"
    mkdir -p "$DESKTOP_DIR"
  fi
fi

DESKTOP_FILE="$DESKTOP_DIR/ClientFlow Installer.desktop"

sed "s|__HOME__|$HOME|g" "$SCRIPT_DIR/ClientFlow Installer.desktop.template" > "$DESKTOP_FILE"
chmod +x "$DESKTOP_FILE"

# GNOME kan kræve trusted metadata for at vise launcheren pænt.
gio set "$DESKTOP_FILE" metadata::trusted true 2>/dev/null || true

echo
echo "ClientFlow skrivebordsikon er oprettet:"
echo "  $DESKTOP_FILE"
echo
echo "Hvis Ubuntu viser 'Untrusted launcher', højreklik på ikonet og vælg:"
echo "  Tillad start / Allow Launching"
echo
echo "Dobbeltklik derefter på 'ClientFlow Installer'."
