#!/usr/bin/env bash
set -euo pipefail

# ClientFlow Desktop Installer
# Åbnes fra skrivebordsikonet.
#
# Menu:
# 1) Installer ClientFlow på en frisk Ubuntu
# 2) Installer client-secret efter godkendelse i admin
# 3) Verificér installation
# 4) Vis logs/status

CLIENTFLOW_BASE_URL="${CLIENTFLOW_BASE_URL:-https://kulturskole-infosk-rm.onrender.com}"
INSTALLER_ZIP_URL="${INSTALLER_ZIP_URL:-https://autoinstall.onrender.com/clientflow_clean_ubuntu_installer_v2.zip}"
WORK_DIR="${HOME}/Hentet/clientflow-install"
INSTALL_DIR="${WORK_DIR}/clientflow_clean_ubuntu_installer_v2"
ZIP_PATH="${WORK_DIR}/clientflow_clean_ubuntu_installer_v2.zip"
LOG="${HOME}/ClientFlow-install.log"

mkdir -p "$WORK_DIR"

exec > >(tee -a "$LOG") 2>&1

print_header() {
  clear || true
  echo "============================================================"
  echo " ClientFlow Installer"
  echo "============================================================"
  echo
  echo "Bruger:      $USER"
  echo "Backend:     $CLIENTFLOW_BASE_URL"
  echo "Installer:   $INSTALLER_ZIP_URL"
  echo "Logfil:      $LOG"
  echo
}

download_installer() {
  echo "== Downloader ClientFlow installer =="
  mkdir -p "$WORK_DIR"

  if ! command -v curl >/dev/null 2>&1 || ! command -v unzip >/dev/null 2>&1; then
    echo "Installerer curl/unzip/ca-certificates..."
    sudo apt-get update
    sudo apt-get install -y curl unzip ca-certificates
  fi

  curl -fL "$INSTALLER_ZIP_URL" -o "$ZIP_PATH"

  echo "== Pakker installer ud =="
  rm -rf "$INSTALL_DIR"
  unzip -o "$ZIP_PATH" -d "$INSTALL_DIR"

  if [[ ! -f "$INSTALL_DIR/scripts/install_clientflow_clean_ubuntu.sh" ]]; then
    echo "FEJL: Installer-script mangler efter unzip."
    echo "Indhold:"
    find "$INSTALL_DIR" -maxdepth 3 -type f | sort
    exit 1
  fi
}

install_clientflow() {
  print_header
  echo "Dette installerer ClientFlow på denne Ubuntu-klient."
  echo
  echo "Når installationen er færdig:"
  echo "  1. Klienten dukker op i admin/enrollment"
  echo "  2. Du godkender klienten"
  echo "  3. Du åbner dette ikon igen og vælger punkt 2"
  echo
  read -rp "Tryk Enter for at fortsætte, eller Ctrl+C for at afbryde..."

  download_installer

  echo
  echo "== Kører ClientFlow clean Ubuntu installer =="
  cd "$INSTALL_DIR"
  sudo bash scripts/install_clientflow_clean_ubuntu.sh "$USER" "$CLIENTFLOW_BASE_URL"

  echo
  echo "============================================================"
  echo " Basisinstallation færdig."
  echo "============================================================"
  echo
  echo "Næste:"
  echo "  1. Genstart klienten"
  echo "  2. Godkend klienten i ClientFlow admin"
  echo "  3. Åbn dette ikon igen og vælg punkt 2"
  echo

  read -rp "Vil du genstarte nu? [j/N]: " ans
  case "${ans:-}" in
    j|J|ja|JA|y|Y|yes|YES)
      sudo reboot
      ;;
    *)
      echo "OK. Genstart manuelt senere med: sudo reboot"
      ;;
  esac
}

install_secret() {
  print_header
  echo "Dette installerer/roterer client-secret efter klienten er godkendt i admin."
  echo
  echo "Kør kun dette EFTER at klienten er godkendt i ClientFlow admin."
  echo
  read -rp "Tryk Enter for at fortsætte, eller Ctrl+C for at afbryde..."

  if [[ ! -f "$INSTALL_DIR/scripts/install_client_secret_env.sh" ]]; then
    echo "Installer-mappen mangler. Downloader/pakker installer først."
    download_installer
  fi

  cd "$INSTALL_DIR"
  sudo bash scripts/install_client_secret_env.sh

  echo
  echo "== Genstarter ClientFlow services =="
  sudo systemctl daemon-reload || true
  sudo systemctl restart clientflow_service.service || true
  sudo systemctl restart clientflow_calendar.service || true
  sudo systemctl restart client_terminal_agent.service || true
  sudo systemctl restart client_remote_desktop_agent.service || true
  sudo systemctl restart clientflow_browser_guard.service || true
  sudo systemctl restart clientflow_kiosk_x11_guard.service || true

  echo
  echo "Client-secret installeret. Vælg punkt 3 for verificering."
}

verify_install() {
  print_header

  if [[ ! -f "$INSTALL_DIR/scripts/verify_clientflow_install.sh" ]]; then
    echo "Installer-mappen mangler. Downloader/pakker installer først."
    download_installer
  fi

  cd "$INSTALL_DIR"
  bash scripts/verify_clientflow_install.sh "$USER" || true

  echo
  echo "Ekstra service-status:"
  systemctl is-active \
    clientflow_service.service \
    clientflow_browser_guard.service \
    clientflow_kiosk_x11_guard.service \
    clientflow_calendar.service \
    client_terminal_agent.service \
    client_remote_desktop_agent.service 2>/dev/null || true
}

show_logs() {
  print_header

  echo "== Services =="
  systemctl is-active \
    clientflow_service.service \
    clientflow_browser_guard.service \
    clientflow_kiosk_x11_guard.service \
    clientflow_calendar.service \
    client_terminal_agent.service \
    client_remote_desktop_agent.service 2>/dev/null || true

  echo
  echo "== clientflow_service seneste logs =="
  journalctl -u clientflow_service.service -n 80 --no-pager -l || true

  echo
  echo "== browser_guard seneste logs =="
  journalctl -u clientflow_browser_guard.service -n 60 --no-pager -l || true

  echo
  echo "== First/local install log =="
  tail -120 "$LOG" 2>/dev/null || true
}

while true; do
  print_header
  echo "Vælg handling:"
  echo
  echo "  1) Installer ClientFlow på frisk Ubuntu"
  echo "  2) Installer client-secret efter godkendelse"
  echo "  3) Verificér installation"
  echo "  4) Vis logs/status"
  echo "  0) Afslut"
  echo
  read -rp "Valg: " choice

  case "${choice:-}" in
    1) install_clientflow ;;
    2) install_secret ;;
    3) verify_install ;;
    4) show_logs ;;
    0) exit 0 ;;
    *) echo "Ugyldigt valg."; sleep 1 ;;
  esac

  echo
  read -rp "Tryk Enter for at gå tilbage til menuen..."
done
