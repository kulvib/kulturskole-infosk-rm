#!/usr/bin/env bash
set -euo pipefail

# ClientFlow Desktop Installer v6.5
# Kun enrollment/client-secret-flow.
# Nyheder:
# - Automatisk Ubuntu on Xorg/autologin-konfiguration
# - Re-registrer klient med ny installationskode hvis backend-klient er slettet
# - Geninstaller/opdater ClientFlow uden at skifte client credentials

CLIENTFLOW_BASE_URL="${CLIENTFLOW_BASE_URL:-https://kulturskole-infosk-rm.onrender.com}"
INSTALLER_ZIP_URL="${INSTALLER_ZIP_URL:-https://autoinstall.onrender.com/clientflow_clean_ubuntu_installer_v6.zip}"
WORK_DIR="${HOME}/Hentet/clientflow-install"
INSTALL_DIR="${WORK_DIR}/clientflow_clean_ubuntu_installer_v6"
ZIP_PATH="${WORK_DIR}/clientflow_clean_ubuntu_installer_v6.zip"
LOG="${HOME}/ClientFlow-install.log"

mkdir -p "$WORK_DIR"
exec > >(tee -a "$LOG") 2>&1

print_header() {
  clear || true
  echo "============================================================"
  echo " ClientFlow Installer v6.5"
  echo "============================================================"
  echo
}

download_installer() {
  echo "Klargør installation..."
  mkdir -p "$WORK_DIR"

  if ! command -v curl >/dev/null 2>&1 || ! command -v unzip >/dev/null 2>&1; then
    echo "Installerer nødvendige hjælpeprogrammer..."
    sudo -v
    sudo apt-get update >>"$LOG" 2>&1
    sudo apt-get install -y curl unzip ca-certificates >>"$LOG" 2>&1
  fi

  curl -fsSL "$INSTALLER_ZIP_URL" -o "$ZIP_PATH"

  rm -rf "$INSTALL_DIR"
  mkdir -p "$INSTALL_DIR"
  unzip -oq "$ZIP_PATH" -d "$INSTALL_DIR"

  if [[ ! -f "$INSTALL_DIR/scripts/install_clientflow_clean_ubuntu.sh" ]]; then
    echo "FEJL: Installationspakken kunne ikke klargøres."
    echo "Se logfilen: $LOG"
    exit 1
  fi
}

progress_monitor() {
  # Viser enkle installations-trin uden at vise tekniske fil-lister eller apt-output.
  tail -n0 -F "$LOG" 2>/dev/null | while IFS= read -r line; do
    case "$line" in
      "== Opdaterer Ubuntu"*)
        echo "Trin 1/10: Opdaterer Ubuntu og installerede programmer..."
        echo "Dette kan tage et stykke tid."
        ;;
      "== Installerer Ubuntu-pakker"*)
        echo "Trin 2/10: Installerer nødvendige hjælpefunktioner..."
        ;;
      "== Installerer Google Chrome"*)
        echo "Trin 3/10: Installerer Google Chrome..."
        ;;
      "== Google Chrome findes"*)
        echo "Trin 3/10: Google Chrome er klar..."
        ;;
      "== Opretter Python venv"*)
        echo "Trin 4/10: Klargør Python-miljø..."
        ;;
      "== Python venv findes"*)
        echo "Trin 4/10: Python-miljø er klar..."
        ;;
      "== Installerer Chrome extension"*)
        echo "Trin 5/10: Konfigurerer kiosk-browser..."
        ;;
      "== Konfigurerer automatisk login"*)
        echo "Trin 6/10: Konfigurerer automatisk login og Ubuntu on Xorg..."
        ;;
      "== Konfigurerer kiosk-hardening"*)
        echo "Trin 7/10: Klargør kiosktilstand og slår forstyrrelser fra..."
        ;;
      "== Konfigurerer klient-sikkerhed"*)
        echo "Trin 8/10: Konfigurerer klient-sikkerhed..."
        ;;
      "== Konfigurerer automatisk skjulning af musecursor"*)
        echo "Trin 8/10: Konfigurerer automatisk skjulning af musecursor..."
        ;;
      "== Claimer installationskode"*)
        echo "Trin 10/10: Registrerer klienten i backend..."
        ;;
      "== Bevarer eksisterende client credentials"*)
        echo "Trin 9/10: Bevarer eksisterende klientregistrering..."
        ;;
      "== Enable + start services"*)
        echo "Starter ClientFlow-services..."
        ;;
      "== Installation færdig"*)
        echo "Installationsdelen er færdig..."
        ;;
    esac
  done
}

run_logged() {
  local description="$1"
  shift
  echo "$description"
  echo "Status vises herunder."
  sudo -v

  progress_monitor &
  local monitor_pid=$!

  set +e
  "$@" >>"$LOG" 2>&1 &
  local cmd_pid=$!
  local status=0

  while kill -0 "$cmd_pid" 2>/dev/null; do
    sleep 45
    if kill -0 "$cmd_pid" 2>/dev/null; then
      echo "Arbejder stadig..."
    fi
  done

  wait "$cmd_pid"
  status=$?
  kill "$monitor_pid" 2>/dev/null || true
  wait "$monitor_pid" 2>/dev/null || true
  set -e

  if [[ "$status" -ne 0 ]]; then
    echo "FEJL: Handlingen kunne ikke gennemføres."
    echo "Seneste log:"
    tail -120 "$LOG" 2>/dev/null || true
    return "$status"
  fi
}

ask_enrollment_code() {
  local code
  read -rp "Installationskode (CF-XXXX-XXXX-XXXX): " code
  code="$(echo "${code}" | tr '[:lower:]' '[:upper:]' | xargs)"
  if [[ -z "$code" ]]; then
    echo "FEJL: Installationskode mangler."
    return 1
  fi
  printf '%s' "$code"
}

ask_client_metadata() {
  DEFAULT_NAME="$(hostname 2>/dev/null || echo "$USER")"
  read -rp "Klientnavn [${DEFAULT_NAME}]: " CLIENT_NAME
  CLIENT_NAME="${CLIENT_NAME:-$DEFAULT_NAME}"
  read -rp "Lokalitet/bemærkning [tom]: " LOCALITY
}

ask_reboot_now() {
  echo "Installation færdig."
  read -rp "Vil du genstarte nu? [j/N]: " ans
  case "${ans:-j}" in
    j|J|ja|JA|y|Y|yes|YES) sudo reboot ;;
    *) echo "Maskinen skal genstartes før installationen er helt færdig."; echo "Kør: sudo reboot" ;;
  esac
}

install_with_enrollment() {
  print_header
  echo "Installation af ny ClientFlow-klient."
  echo
  echo "Opret først en installationskode i ClientFlow admin."
  echo
  ENROLLMENT_CODE="$(ask_enrollment_code)" || return 1
  ask_client_metadata
  download_installer

  cd "$INSTALL_DIR"
  run_logged "Installerer ClientFlow. Det kan tage nogle minutter..." \
    sudo \
      CLIENTFLOW_ENROLLMENT_CODE="$ENROLLMENT_CODE" \
      CLIENTFLOW_CLIENT_NAME="$CLIENT_NAME" \
      CLIENTFLOW_LOCALITY="$LOCALITY" \
      CLIENTFLOW_CONFIGURE_XORG_AUTOLOGIN=1 \
      bash scripts/install_clientflow_clean_ubuntu.sh "$USER" "$CLIENTFLOW_BASE_URL" || return 1

  echo
  ask_reboot_now
}

reclaim_with_new_code() {
  print_header
  echo "Bruges hvis denne klient er slettet i ClientFlow admin."
  echo
  echo "Opret først en ny installationskode i ClientFlow admin."
  echo
  ENROLLMENT_CODE="$(ask_enrollment_code)" || return 1
  ask_client_metadata
  download_installer

  echo
  echo "Re-registrerer klienten..."
  sudo -v
  sudo systemctl stop \
    clientflow_service.service \
    clientflow_calendar.service \
    client_terminal_agent.service \
    client_remote_desktop_agent.service \
    clientflow_browser_guard.service >>"$LOG" 2>&1 || true

  cd "$INSTALL_DIR"
  run_logged "Indlæser ny installationskode..." \
    sudo \
      CLIENTFLOW_BASE_URL="$CLIENTFLOW_BASE_URL" \
      CLIENTFLOW_ENROLLMENT_CODE="$ENROLLMENT_CODE" \
      CLIENTFLOW_CLIENT_NAME="$CLIENT_NAME" \
      CLIENTFLOW_LOCALITY="$LOCALITY" \
      CLIENTFLOW_USER="$USER" \
      bash scripts/claim_enrollment_env.sh || return 1

  sudo systemctl daemon-reload >>"$LOG" 2>&1
  sudo systemctl enable \
    clientflow_service.service \
    clientflow_calendar.service \
    client_terminal_agent.service \
    client_remote_desktop_agent.service \
    clientflow_browser_guard.service \
    clientflow_kiosk_x11_guard.service >>"$LOG" 2>&1 || true
  sudo systemctl restart clientflow_kiosk_x11_guard.service >>"$LOG" 2>&1 || true
  sudo systemctl restart clientflow_service.service >>"$LOG" 2>&1 || true
  sudo systemctl restart clientflow_calendar.service >>"$LOG" 2>&1 || true
  sudo systemctl restart client_terminal_agent.service >>"$LOG" 2>&1 || true
  sudo systemctl restart client_remote_desktop_agent.service >>"$LOG" 2>&1 || true
  sudo systemctl restart clientflow_browser_guard.service >>"$LOG" 2>&1 || true

  echo
  echo "Ny installationskode er indlæst."
  echo "Godkend klienten i ClientFlow admin, hvis den står som pending."
}

reinstall_latest() {
  print_header
  echo "Geninstallerer/opdaterer ClientFlow og bevarer klientens registrering."
  echo
  if [[ ! -s /etc/clientflow/clientflow.env ]] || ! sudo grep -q '^CLIENTFLOW_CLIENT_ID=[0-9]' /etc/clientflow/clientflow.env || ! sudo grep -q '^CLIENTFLOW_CLIENT_SECRET=cf_client_' /etc/clientflow/clientflow.env; then
    echo "FEJL: Finder ikke gyldige eksisterende client credentials."
    echo "Brug først 'Installer med installationskode' eller 'Indtast ny installationskode'."
    return 1
  fi
  read -rp "Fortsæt med geninstallation/opdatering? [j/N]: " ans
  case "${ans:-}" in
    j|J|ja|JA|y|Y|yes|YES) ;;
    *) echo "Afbryder."; return 0 ;;
  esac

  download_installer
  cd "$INSTALL_DIR"
  run_logged "Geninstallerer/opdaterer ClientFlow. Det kan tage nogle minutter..." \
    sudo \
      CLIENTFLOW_SKIP_ENROLLMENT=1 \
      CLIENTFLOW_REINSTALL_MODE=1 \
      CLIENTFLOW_CONFIGURE_XORG_AUTOLOGIN=1 \
      bash scripts/install_clientflow_clean_ubuntu.sh "$USER" "$CLIENTFLOW_BASE_URL" || return 1

  echo
  ask_reboot_now
}

configure_xorg_autologin() {
  print_header
  download_installer
  cd "$INSTALL_DIR"
  sudo bash scripts/configure_xorg_autologin.sh "$USER"
  echo
  echo "Xorg/autologin er sat. Reboot kræves for fuld effekt."
}

verify_install() {
  print_header

  if [[ ! -f "$INSTALL_DIR/scripts/verify_clientflow_install.sh" ]]; then
    echo "Klargør verificering..."
    download_installer
  fi

  cd "$INSTALL_DIR"
  bash scripts/verify_clientflow_install.sh "$USER" || true

  echo
  echo "Service-status:"
  systemctl is-enabled \
    clientflow_service.service \
    clientflow_calendar.service \
    clientflow_browser_guard.service \
    client_terminal_agent.service \
    client_remote_desktop_agent.service \
    clientflow_kiosk_x11_guard.service \
    clientflow_hide_cursor.service \
    clientflow_self_update.service \
    clientflow-disable-bluetooth.service 2>/dev/null || true
  echo
  systemctl is-active \
    clientflow_service.service \
    clientflow_calendar.service \
    clientflow_browser_guard.service \
    client_terminal_agent.service \
    client_remote_desktop_agent.service \
    clientflow_kiosk_x11_guard.service \
    clientflow_hide_cursor.service \
    clientflow_self_update.service \
    clientflow-disable-bluetooth.service 2>/dev/null || true
}

show_logs() {
  print_header

  echo "== Services =="
  systemctl is-enabled \
    clientflow_service.service \
    clientflow_calendar.service \
    clientflow_browser_guard.service \
    client_terminal_agent.service \
    client_remote_desktop_agent.service \
    clientflow_kiosk_x11_guard.service \
    clientflow_hide_cursor.service \
    clientflow_self_update.service \
    clientflow-disable-bluetooth.service 2>/dev/null || true
  echo
  systemctl is-active \
    clientflow_service.service \
    clientflow_calendar.service \
    clientflow_browser_guard.service \
    client_terminal_agent.service \
    client_remote_desktop_agent.service \
    clientflow_kiosk_x11_guard.service \
    clientflow_hide_cursor.service \
    clientflow_self_update.service \
    clientflow-disable-bluetooth.service 2>/dev/null || true

  echo
  echo "== clientflow_service seneste logs =="
  journalctl -u clientflow_service.service -n 120 --no-pager -l || true

  echo
  echo "== browser_guard seneste logs =="
  journalctl -u clientflow_browser_guard.service -n 80 --no-pager -l || true

  echo
  echo "== Chrome/port 9222 =="
  ps aux | grep -Ei 'chrome|chromium' | grep -v grep || true
  ss -ltnp | grep 9222 || true

  echo
  echo "== Install log =="
  tail -180 "$LOG" 2>/dev/null || true
}

while true; do
  print_header
  echo "Vælg handling:"
  echo
  echo "  1) Installer ClientFlow med installationskode"
  echo "  2) Indtast ny installationskode / re-registrer klient"
  echo "  3) Geninstaller/opdater ClientFlow"
  echo "  4) Verificér installation"
  echo "  5) Vis logs/status"
  echo "  0) Afslut"
  echo
  read -rp "Valg: " choice

  case "${choice:-}" in
    1) install_with_enrollment ;;
    2) reclaim_with_new_code ;;
    3) reinstall_latest ;;
    4) verify_install ;;
    5) show_logs ;;
    0) exit 0 ;;
    *) echo "Ugyldigt valg."; sleep 1 ;;
  esac

  echo
  read -rp "Tryk Enter for at gå tilbage til menuen..."
done
