#!/usr/bin/env bash
set -euo pipefail

# ClientFlow Desktop Installer v3
# Kun nyt enrollment/client-secret-flow.
#
# Menu:
# 1) Installer ClientFlow med installationskode
# 2) Verificér installation
# 3) Vis logs/status

CLIENTFLOW_BASE_URL="${CLIENTFLOW_BASE_URL:-https://kulturskole-infosk-rm.onrender.com}"
INSTALLER_ZIP_URL="${INSTALLER_ZIP_URL:-https://autoinstall.onrender.com/clientflow_clean_ubuntu_installer_v3.zip}"
WORK_DIR="${HOME}/Hentet/clientflow-install"
INSTALL_DIR="${WORK_DIR}/clientflow_clean_ubuntu_installer_v3"
ZIP_PATH="${WORK_DIR}/clientflow_clean_ubuntu_installer_v3.zip"
LOG="${HOME}/ClientFlow-install.log"

mkdir -p "$WORK_DIR"
exec > >(tee -a "$LOG") 2>&1

print_header() {
  clear || true
  echo "============================================================"
  echo " ClientFlow Installer v3"
  echo "============================================================"
  echo
  echo "Bruger:      $USER"
  echo "Backend:     $CLIENTFLOW_BASE_URL"
  echo "Installer:   $INSTALLER_ZIP_URL"
  echo "Logfil:      $LOG"
  echo
}

download_installer() {
  echo "== Downloader ClientFlow installer v3 =="
  mkdir -p "$WORK_DIR"

  if ! command -v curl >/dev/null 2>&1 || ! command -v unzip >/dev/null 2>&1; then
    echo "Installerer curl/unzip/ca-certificates..."
    sudo apt-get update
    sudo apt-get install -y curl unzip ca-certificates
  fi

  curl -fL "$INSTALLER_ZIP_URL" -o "$ZIP_PATH"

  echo "== Pakker installer ud =="
  rm -rf "$INSTALL_DIR"
  mkdir -p "$INSTALL_DIR"
  unzip -o "$ZIP_PATH" -d "$INSTALL_DIR"

  if [[ ! -f "$INSTALL_DIR/scripts/install_clientflow_clean_ubuntu.sh" ]]; then
    echo "FEJL: Installer-script mangler efter unzip."
    echo "Indhold:"
    find "$INSTALL_DIR" -maxdepth 3 -type f | sort
    exit 1
  fi
}

install_with_enrollment() {
  print_header
  echo "Dette installerer ClientFlow på denne Ubuntu-klient med det nye enrollment-flow."
  echo
  echo "Før du fortsætter, skal der være oprettet en installationskode i ClientFlow admin."
  echo "Koden har format som fx: CF-ABCD-1234-WXYZ"
  echo
  read -rp "Installationskode: " ENROLLMENT_CODE
  ENROLLMENT_CODE="$(echo "${ENROLLMENT_CODE}" | tr '[:lower:]' '[:upper:]' | xargs)"
  if [[ -z "$ENROLLMENT_CODE" ]]; then
    echo "FEJL: Installationskode mangler."
    return 1
  fi

  DEFAULT_NAME="$(hostname 2>/dev/null || echo "$USER")"
  read -rp "Klientnavn [${DEFAULT_NAME}]: " CLIENT_NAME
  CLIENT_NAME="${CLIENT_NAME:-$DEFAULT_NAME}"

  read -rp "Lokalitet/bemærkning [tom]: " LOCALITY

  download_installer

  echo
  echo "== Kører ClientFlow clean Ubuntu installer v3 =="
  cd "$INSTALL_DIR"
  sudo \
    CLIENTFLOW_ENROLLMENT_CODE="$ENROLLMENT_CODE" \
    CLIENTFLOW_CLIENT_NAME="$CLIENT_NAME" \
    CLIENTFLOW_LOCALITY="$LOCALITY" \
    bash scripts/install_clientflow_clean_ubuntu.sh "$USER" "$CLIENTFLOW_BASE_URL"

  echo
  echo "============================================================"
  echo " Installation færdig."
  echo "============================================================"
  echo
  echo "Næste:"
  echo "  1. Godkend klienten i ClientFlow admin, hvis den står som pending"
  echo "  2. Vælg punkt 2 her for verificering"
  echo "  3. Kør reboot-test"
  echo

  read -rp "Vil du genstarte nu? [j/N]: " ans
  case "${ans:-}" in
    j|J|ja|JA|y|Y|yes|YES)
      sudo reboot
      ;;
    *)
      echo "OK. Genstart manuelt senere med: sudo reboot"
      ;;
  esac
}

verify_install() {
  print_header

  if [[ ! -f "$INSTALL_DIR/scripts/verify_clientflow_install.sh" ]]; then
    echo "Installer-mappen mangler. Downloader/pakker installer først."
    download_installer
  fi

  cd "$INSTALL_DIR"
  bash scripts/verify_clientflow_install.sh "$USER" || true

  echo
  echo "Ekstra service-status:"
  systemctl is-active \
    clientflow_service.service \
    clientflow_browser_guard.service \
    clientflow_kiosk_x11_guard.service \
    clientflow_calendar.service \
    client_terminal_agent.service \
    client_remote_desktop_agent.service 2>/dev/null || true
}

show_logs() {
  print_header

  echo "== Services =="
  systemctl is-active \
    clientflow_service.service \
    clientflow_browser_guard.service \
    clientflow_kiosk_x11_guard.service \
    clientflow_calendar.service \
    client_terminal_agent.service \
    client_remote_desktop_agent.service 2>/dev/null || true

  echo
  echo "== clientflow_service seneste logs =="
  journalctl -u clientflow_service.service -n 100 --no-pager -l || true

  echo
  echo "== browser_guard seneste logs =="
  journalctl -u clientflow_browser_guard.service -n 80 --no-pager -l || true

  echo
  echo "== Chrome/port 9222 =="
  ps aux | grep -Ei 'chrome|chromium' | grep -v grep || true
  ss -ltnp | grep 9222 || true

  echo
  echo "== First/local install log =="
  tail -160 "$LOG" 2>/dev/null || true
}

while true; do
  print_header
  echo "Vælg handling:"
  echo
  echo "  1) Installer ClientFlow med installationskode"
  echo "  2) Verificér installation"
  echo "  3) Vis logs/status"
  echo "  0) Afslut"
  echo
  read -rp "Valg: " choice

  case "${choice:-}" in
    1) install_with_enrollment ;;
    2) verify_install ;;
    3) show_logs ;;
    0) exit 0 ;;
    *) echo "Ugyldigt valg."; sleep 1 ;;
  esac

  echo
  read -rp "Tryk Enter for at gå tilbage til menuen..."
done
