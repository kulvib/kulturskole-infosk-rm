#!/usr/bin/env bash
set -euo pipefail

# ClientFlow Desktop Installer v4.1
# Kun enrollment/client-secret-flow.
# Nyheder:
# - Automatisk Ubuntu on Xorg/autologin-konfiguration
# - Re-registrer klient med ny installationskode hvis backend-klient er slettet
# - Geninstaller/opdater ClientFlow fra Render uden at skifte client credentials

CLIENTFLOW_BASE_URL="${CLIENTFLOW_BASE_URL:-https://kulturskole-infosk-rm.onrender.com}"
INSTALLER_ZIP_URL="${INSTALLER_ZIP_URL:-https://autoinstall.onrender.com/clientflow_clean_ubuntu_installer_v4.zip}"
WORK_DIR="${HOME}/Hentet/clientflow-install"
INSTALL_DIR="${WORK_DIR}/clientflow_clean_ubuntu_installer_v4"
ZIP_PATH="${WORK_DIR}/clientflow_clean_ubuntu_installer_v4.zip"
LOG="${HOME}/ClientFlow-install.log"

mkdir -p "$WORK_DIR"
exec > >(tee -a "$LOG") 2>&1

print_header() {
  clear || true
  echo "============================================================"
  echo " ClientFlow Installer v4.1"
  echo "============================================================"
  echo
  echo "Bruger:      $USER"
  echo "Backend:     $CLIENTFLOW_BASE_URL"
  echo "Installer:   $INSTALLER_ZIP_URL"
  echo "Logfil:      $LOG"
  echo
}

download_installer() {
  echo "== Downloader seneste ClientFlow installer v4 fra Render =="
  mkdir -p "$WORK_DIR"

  if ! command -v curl >/dev/null 2>&1 || ! command -v unzip >/dev/null 2>&1; then
    echo "Installerer curl/unzip/ca-certificates..."
    sudo apt-get update
    sudo apt-get install -y curl unzip ca-certificates
  fi

  curl -fL "$INSTALLER_ZIP_URL" -o "$ZIP_PATH"

  echo "== Pakker installer ud =="
  rm -rf "$INSTALL_DIR"
  mkdir -p "$INSTALL_DIR"
  unzip -o "$ZIP_PATH" -d "$INSTALL_DIR"

  if [[ ! -f "$INSTALL_DIR/scripts/install_clientflow_clean_ubuntu.sh" ]]; then
    echo "FEJL: Installer-script mangler efter unzip."
    echo "Indhold:"
    find "$INSTALL_DIR" -maxdepth 3 -type f | sort
    exit 1
  fi
}

ask_enrollment_code() {
  local code
  read -rp "Installationskode (CF-XXXX-XXXX-XXXX): " code
  code="$(echo "${code}" | tr '[:lower:]' '[:upper:]' | xargs)"
  if [[ -z "$code" ]]; then
    echo "FEJL: Installationskode mangler."
    return 1
  fi
  printf '%s' "$code"
}

ask_client_metadata() {
  DEFAULT_NAME="$(hostname 2>/dev/null || echo "$USER")"
  read -rp "Klientnavn [${DEFAULT_NAME}]: " CLIENT_NAME
  CLIENT_NAME="${CLIENT_NAME:-$DEFAULT_NAME}"
  read -rp "Lokalitet/bemærkning [tom]: " LOCALITY
}

install_with_enrollment() {
  print_header
  echo "Dette installerer ClientFlow på denne Ubuntu-klient med enrollment-flow."
  echo "Installeren konfigurerer også automatisk login som Ubuntu on Xorg."
  echo
  echo "Før du fortsætter, skal der være oprettet en installationskode i ClientFlow admin."
  echo
  ENROLLMENT_CODE="$(ask_enrollment_code)" || return 1
  ask_client_metadata
  download_installer

  echo
  echo "== Kører ClientFlow clean Ubuntu installer v4 =="
  cd "$INSTALL_DIR"
  sudo \
    CLIENTFLOW_ENROLLMENT_CODE="$ENROLLMENT_CODE" \
    CLIENTFLOW_CLIENT_NAME="$CLIENT_NAME" \
    CLIENTFLOW_LOCALITY="$LOCALITY" \
    CLIENTFLOW_CONFIGURE_XORG_AUTOLOGIN=1 \
    bash scripts/install_clientflow_clean_ubuntu.sh "$USER" "$CLIENTFLOW_BASE_URL"

  echo
  echo "============================================================"
  echo " Installation færdig."
  echo "============================================================"
  echo
  echo "Næste: Genstart maskinen, så Ubuntu on Xorg og automatisk login aktiveres."
  echo "Derefter: Godkend klienten i ClientFlow admin, hvis den står som pending."
  echo "GUI'en viser Pending indtil godkendelse og Approved efter godkendelse."
  echo
  read -rp "Vil du genstarte nu? [j/N]: " ans
  case "${ans:-}" in
    j|J|ja|JA|y|Y|yes|YES) sudo reboot ;;
    *) echo "OK. Genstart manuelt senere med: sudo reboot" ;;
  esac
}

reclaim_with_new_code() {
  print_header
  echo "Brug denne funktion hvis klienten er slettet i backend, eller hvis den skal have ny backend-identitet."
  echo "Der oprettes en ny klient via /api/enrollment/claim, og /etc/clientflow/clientflow.env overskrives."
  echo
  ENROLLMENT_CODE="$(ask_enrollment_code)" || return 1
  ask_client_metadata
  download_installer

  echo
  echo "== Stopper ClientFlow-services midlertidigt =="
  sudo systemctl stop \
    clientflow_service.service \
    clientflow_calendar.service \
    client_terminal_agent.service \
    client_remote_desktop_agent.service \
    clientflow_browser_guard.service 2>/dev/null || true

  echo "== Claimer ny installationskode og skriver nye credentials =="
  cd "$INSTALL_DIR"
  sudo \
    CLIENTFLOW_BASE_URL="$CLIENTFLOW_BASE_URL" \
    CLIENTFLOW_ENROLLMENT_CODE="$ENROLLMENT_CODE" \
    CLIENTFLOW_CLIENT_NAME="$CLIENT_NAME" \
    CLIENTFLOW_LOCALITY="$LOCALITY" \
    CLIENTFLOW_USER="$USER" \
    bash scripts/claim_enrollment_env.sh

  echo "== Genstarter ClientFlow-services =="
  sudo systemctl daemon-reload
  sudo systemctl enable \
    clientflow_service.service \
    clientflow_calendar.service \
    client_terminal_agent.service \
    client_remote_desktop_agent.service \
    clientflow_browser_guard.service \
    clientflow_kiosk_x11_guard.service 2>/dev/null || true
  sudo systemctl restart clientflow_kiosk_x11_guard.service || true
  sudo systemctl restart clientflow_service.service || true
  sudo systemctl restart clientflow_calendar.service || true
  sudo systemctl restart client_terminal_agent.service || true
  sudo systemctl restart client_remote_desktop_agent.service || true
  sudo systemctl restart clientflow_browser_guard.service || true

  echo
  echo "Ny installationskode er indlæst. Godkend den nye klient i backend, hvis den står som pending."
}

reinstall_latest() {
  print_header
  echo "Dette downloader seneste ClientFlow-filer fra Render, sletter gammel lokal API-version,"
  echo "geninstallerer services/extensions og BEVARER eksisterende client_id/client_secret."
  echo
  if [[ ! -s /etc/clientflow/clientflow.env ]] || ! sudo grep -q '^CLIENTFLOW_CLIENT_ID=[0-9]' /etc/clientflow/clientflow.env || ! sudo grep -q '^CLIENTFLOW_CLIENT_SECRET=cf_client_' /etc/clientflow/clientflow.env; then
    echo "FEJL: Finder ikke gyldige eksisterende client credentials i /etc/clientflow/clientflow.env."
    echo "Brug først 'Installer med installationskode' eller 'Indtast ny installationskode'."
    return 1
  fi
  read -rp "Fortsæt med geninstallation/opdatering? [j/N]: " ans
  case "${ans:-}" in
    j|J|ja|JA|y|Y|yes|YES) ;;
    *) echo "Afbryder."; return 0 ;;
  esac

  download_installer
  cd "$INSTALL_DIR"
  sudo \
    CLIENTFLOW_SKIP_ENROLLMENT=1 \
    CLIENTFLOW_REINSTALL_MODE=1 \
    CLIENTFLOW_CONFIGURE_XORG_AUTOLOGIN=1 \
    bash scripts/install_clientflow_clean_ubuntu.sh "$USER" "$CLIENTFLOW_BASE_URL"

  echo
  echo "Geninstallation/opdatering færdig. Eksisterende client credentials er bevaret."
}

configure_xorg_autologin() {
  print_header
  download_installer
  cd "$INSTALL_DIR"
  sudo bash scripts/configure_xorg_autologin.sh "$USER"
  echo
  echo "Xorg/autologin er sat. Reboot kræves for fuld effekt."
}

verify_install() {
  print_header

  if [[ ! -f "$INSTALL_DIR/scripts/verify_clientflow_install.sh" ]]; then
    echo "Installer-mappen mangler. Downloader/pakker installer først."
    download_installer
  fi

  cd "$INSTALL_DIR"
  bash scripts/verify_clientflow_install.sh "$USER" || true

  echo
  echo "Ekstra service-status:"
  systemctl is-enabled \
    clientflow_service.service \
    clientflow_browser_guard.service \
    clientflow_kiosk_x11_guard.service \
    clientflow_calendar.service \
    client_terminal_agent.service \
    client_remote_desktop_agent.service 2>/dev/null || true
  echo
  systemctl is-active \
    clientflow_service.service \
    clientflow_browser_guard.service \
    clientflow_kiosk_x11_guard.service \
    clientflow_calendar.service \
    client_terminal_agent.service \
    client_remote_desktop_agent.service 2>/dev/null || true
}

show_logs() {
  print_header

  echo "== Services =="
  systemctl is-enabled \
    clientflow_service.service \
    clientflow_browser_guard.service \
    clientflow_kiosk_x11_guard.service \
    clientflow_calendar.service \
    client_terminal_agent.service \
    client_remote_desktop_agent.service 2>/dev/null || true
  echo
  systemctl is-active \
    clientflow_service.service \
    clientflow_browser_guard.service \
    clientflow_kiosk_x11_guard.service \
    clientflow_calendar.service \
    client_terminal_agent.service \
    client_remote_desktop_agent.service 2>/dev/null || true

  echo
  echo "== clientflow_service seneste logs =="
  journalctl -u clientflow_service.service -n 120 --no-pager -l || true

  echo
  echo "== browser_guard seneste logs =="
  journalctl -u clientflow_browser_guard.service -n 80 --no-pager -l || true

  echo
  echo "== Chrome/port 9222 =="
  ps aux | grep -Ei 'chrome|chromium' | grep -v grep || true
  ss -ltnp | grep 9222 || true

  echo
  echo "== Install log =="
  tail -180 "$LOG" 2>/dev/null || true
}

while true; do
  print_header
  echo "Vælg handling:"
  echo
  echo "  1) Installer ClientFlow med installationskode"
  echo "  2) Indtast ny installationskode / re-registrer klient"
  echo "  3) Geninstaller/opdater ClientFlow"
  echo "  4) Verificér installation"
  echo "  5) Vis logs/status"
  echo "  0) Afslut"
  echo
  read -rp "Valg: " choice

  case "${choice:-}" in
    1) install_with_enrollment ;;
    2) reclaim_with_new_code ;;
    3) reinstall_latest ;;
    4) verify_install ;;
    5) show_logs ;;
    0) exit 0 ;;
    *) echo "Ugyldigt valg."; sleep 1 ;;
  esac

  echo
  read -rp "Tryk Enter for at gå tilbage til menuen..."
done
